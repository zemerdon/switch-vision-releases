const PANEL_VERSION = "1.8.0";
const CARD_MODULE_URL = `/api/switch_vision/switch-vision-card.js?v=${PANEL_VERSION}`;

class SwitchVisionPanel extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._hass = null;
    this._panel = null;
    this._cards = [];
    this._loaded = false;
    this._loading = false;
    this._lastModified = null;
    this._lastShowCalibrationButtons = null;
    this._pollTimer = null;
    this._visibilityHandler = () => {
      if (!document.hidden) this._checkForUpdate(true);
      this._schedulePoll();
    };
  }

  set hass(value) {
    this._hass = value;
    for (const card of this._cards) card.hass = value;
    if (this.isConnected && !this._loaded && !this._loading) this._load();
  }

  get hass() { return this._hass; }

  set panel(value) {
    this._panel = value;
    if (this.isConnected && !this._loaded && !this._loading) this._load();
  }

  connectedCallback() {
    this._renderShell();
    document.addEventListener("visibilitychange", this._visibilityHandler);
    window.addEventListener("focus", this._visibilityHandler);
    if (this._hass && !this._loaded && !this._loading) this._load();
    this._schedulePoll();
  }

  disconnectedCallback() {
    document.removeEventListener("visibilitychange", this._visibilityHandler);
    window.removeEventListener("focus", this._visibilityHandler);
    if (this._pollTimer) clearTimeout(this._pollTimer);
    this._pollTimer = null;
  }

  _renderShell() {
    this.shadowRoot.innerHTML = `
      <style>
        :host{display:block;min-height:100%;background:var(--primary-background-color,#11161b);color:var(--primary-text-color,#e8eef3);font-family:var(--paper-font-body1_-_font-family,Arial,sans-serif)}
        .page{max-width:1280px;margin:0 auto;padding:10px 16px 40px}
        .compact-head{display:flex;align-items:center;gap:12px;margin:0 0 10px;min-height:38px}
        .summary{flex:1;min-width:0;border-left:4px solid #3e8fc5;border-radius:8px;padding:9px 12px;background:var(--card-background-color,#1c242b);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .version{font-size:12px;border:1px solid rgba(127,180,220,.45);border-radius:999px;padding:5px 9px;white-space:nowrap}
        button{border:0;border-radius:8px;padding:8px 11px;background:var(--primary-color,#2b8cc4);color:#fff;font-weight:600;cursor:pointer}button.secondary{background:var(--secondary-background-color,#34414a)}button:disabled{opacity:.55;cursor:default}
        .error,.empty{border-radius:8px;padding:10px 13px;margin:0 0 10px;background:var(--card-background-color,#1c242b);box-shadow:var(--ha-card-box-shadow,0 2px 8px rgba(0,0,0,.22))}.error{border-left:4px solid #d26a5c}.empty{border-left:4px solid #d4a64e}
        .cards{display:grid;grid-template-columns:minmax(0,1fr);gap:18px}.card-wrap{min-width:0}
        details{margin-top:16px;background:var(--card-background-color,#1c242b);border-radius:10px;padding:11px 14px}summary{cursor:pointer;font-weight:600}.advanced-actions{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}
        .meta{font-family:monospace;white-space:pre-wrap;word-break:break-word;background:#0d1216;padding:12px;border-radius:8px;max-height:320px;overflow:auto}
        @media(max-width:650px){.page{padding:8px 8px 28px}.compact-head{gap:7px}.summary{font-size:13px;padding:8px 9px}.version{font-size:11px;padding:4px 7px}button{padding:7px 9px}}
      </style>
      <div class="page">
        <div class="compact-head">
          <div id="summary" class="summary">Loading generated switch configuration…</div>
          <button id="refresh" title="Refresh dashboard" aria-label="Refresh dashboard">Refresh</button>
          <span id="version" class="version">v${PANEL_VERSION}</span>
        </div>
        <div id="message"></div>
        <div id="cards" class="cards"></div>
        <details id="details"><summary>Advanced</summary><div class="advanced-actions"><button id="reload" class="secondary">Reload frontend modules</button></div><div id="meta" class="meta">No dashboard details loaded yet.</div></details>
      </div>`;
    this.shadowRoot.getElementById("refresh").addEventListener("click", () => this._load(true));
    this.shadowRoot.getElementById("reload").addEventListener("click", () => window.location.reload());
  }

  async _load(force = false) {
    if (!this._hass || this._loading) return;
    this._loading = true;
    const refreshButton = this.shadowRoot.getElementById("refresh");
    const summary = this.shadowRoot.getElementById("summary");
    const message = this.shadowRoot.getElementById("message");
    const cardsRoot = this.shadowRoot.getElementById("cards");
    refreshButton.disabled = true;
    refreshButton.textContent = "Refreshing…";
    summary.textContent = "Loading generated switch configuration…";
    message.replaceChildren();
    cardsRoot.replaceChildren();
    this._cards = [];
    try {
      if (!customElements.get("switch-vision-3650")) await import(CARD_MODULE_URL);
      const result = await this._hass.callWS({ type: "switch_vision/get_dashboard_panel", refresh: !!force });
      if (!result.exists) {
        message.className = "empty";
        message.innerHTML = `<b>No switches are ready to display yet.</b><br>Run Discovery with dashboard-card generation enabled.`;
        summary.textContent = "No switch cards loaded";
        this._showMeta(result);
        return;
      }
      const runtimeVersion = result.runtime_version || this.panel?.config?.runtime_version || PANEL_VERSION;
      const versionBadge = this.shadowRoot.getElementById("version");
      if (versionBadge) versionBadge.textContent = `v${runtimeVersion}`;
      const configs = Array.isArray(result.cards) ? result.cards : [];
      if (!configs.length) {
        message.className = "empty";
        message.innerHTML = `<b>The generated dashboard contains no Switch Vision cards.</b><br>Run Discovery again or use the generated YAML manually while troubleshooting.`;
        summary.textContent = "No switch cards loaded";
        this._showMeta(result);
        return;
      }
      for (const config of configs) {
        const card = document.createElement("switch-vision-3650");
        card.setConfig({ ...config, type: "custom:switch-vision-3650" });
        card.hass = this._hass;
        const wrap = document.createElement("div");
        wrap.className = "card-wrap";
        wrap.appendChild(card);
        cardsRoot.appendChild(wrap);
        this._cards.push(card);
      }
      const updated = result.modified ? new Date(result.modified * 1000).toLocaleString() : "Unknown";
      summary.innerHTML = `<b>${configs.length} switch card${configs.length === 1 ? "" : "s"} loaded</b> &bull; Last generated ${this._escape(updated)}`;
      message.replaceChildren();
      message.className = "";
      this._lastModified = result.modified || null;
      this._lastShowCalibrationButtons = result.show_calibration_buttons !== false;
      this._loaded = true;
      this._showMeta(result);
    } catch (error) {
      message.className = "error";
      message.innerHTML = `<b>Switch dashboard could not be loaded.</b><br>${this._escape(String(error))}<br><br>The generated dashboard YAML remains available as a manual fallback.`;
      summary.textContent = "Dashboard update failed";
    } finally {
      this._loading = false;
      refreshButton.disabled = false;
      refreshButton.textContent = "Refresh";
      this._schedulePoll();
    }
  }

  _schedulePoll() {
    if (this._pollTimer) clearTimeout(this._pollTimer);
    this._pollTimer = null;
    if (!this.isConnected || document.hidden) return;
    this._pollTimer = setTimeout(() => this._checkForUpdate(false), 5000);
  }

  async _checkForUpdate(forceVisible = false) {
    if (!this._hass || this._loading || document.hidden) {
      this._schedulePoll();
      return;
    }
    try {
      const result = await this._hass.callWS({ type: "switch_vision/get_dashboard_panel", refresh: false });
      const modified = result && result.modified ? Number(result.modified) : null;
      const showCalibrationButtons = result && result.show_calibration_buttons !== false;
      const optionChanged = this._lastShowCalibrationButtons !== null && showCalibrationButtons !== this._lastShowCalibrationButtons;
      if (!this._loaded || optionChanged || (modified && this._lastModified && modified !== this._lastModified) || (modified && !this._lastModified)) {
        await this._load(true);
      } else if (forceVisible && result) {
        this._showMeta(result);
      }
    } catch (error) {
      // Keep the existing dashboard visible; the next poll will retry.
    } finally {
      this._schedulePoll();
    }
  }

  _showMeta(result) {
    const meta = this.shadowRoot.getElementById("meta");
    meta.textContent = JSON.stringify({
      runtime_version: result.runtime_version || this.panel?.config?.runtime_version || PANEL_VERSION,
      asset_revision: result.asset_revision || this.panel?.config?.asset_revision || null,
      source: result.path,
      modified: result.modified ? new Date(result.modified * 1000).toISOString() : null,
      card_count: result.card_count,
      warnings: result.warnings || [],
      show_calibration_buttons: result.show_calibration_buttons !== false,
      manual_yaml_fallback: true
    }, null, 2);
  }

  _escape(value) {
    return String(value).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
  }
}

if (!customElements.get("switch-vision-panel")) customElements.define("switch-vision-panel", SwitchVisionPanel);
