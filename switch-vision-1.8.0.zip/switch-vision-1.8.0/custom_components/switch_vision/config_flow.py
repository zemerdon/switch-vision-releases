"""Config and options flow for Switch Vision."""
from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigFlow, ConfigFlowResult, OptionsFlowWithReload

from . import (
    CONF_SHOW_CALIBRATION_BUTTONS,
    CONF_SHOW_PANEL_IN_SIDEBAR,
    DEFAULT_DASHBOARD_CONFIG_PATH,
    DOMAIN,
)


class SwitchVisionConfigFlow(ConfigFlow, domain=DOMAIN):
    """Create the single local Switch Vision integration entry."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Set up Switch Vision from the integrations page."""
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        if user_input is not None:
            return self.async_create_entry(
                title="Switch Vision",
                data={"dashboard_config_path": DEFAULT_DASHBOARD_CONFIG_PATH},
            )
        return self.async_show_form(step_id="user")

    async def async_step_import(
        self, import_data: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Import an existing YAML-based installation."""
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        return self.async_create_entry(
            title="Switch Vision",
            data={
                "dashboard_config_path": str(
                    (import_data or {}).get(
                        "dashboard_config_path", DEFAULT_DASHBOARD_CONFIG_PATH
                    )
                )
            },
        )

    @staticmethod
    def async_get_options_flow(config_entry):
        """Return the Switch Vision options flow."""
        return SwitchVisionOptionsFlow()


class SwitchVisionOptionsFlow(OptionsFlowWithReload):
    """Manage Switch Vision presentation options."""

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Show integration options."""
        if user_input is not None:
            return self.async_create_entry(data=user_input)

        schema = vol.Schema(
            {
                vol.Required(
                    CONF_SHOW_PANEL_IN_SIDEBAR,
                    default=self.config_entry.options.get(
                        CONF_SHOW_PANEL_IN_SIDEBAR, True
                    ),
                ): bool,
                vol.Required(
                    CONF_SHOW_CALIBRATION_BUTTONS,
                    default=self.config_entry.options.get(
                        CONF_SHOW_CALIBRATION_BUTTONS, True
                    ),
                ): bool,
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema)
