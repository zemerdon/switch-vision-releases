const SV_VERSION = "1.8.0";
const calibration = {"schema":"switch-vision-interactive-calibration-v1","model":"cisco-3650-48p-4-uplink","generated_by":`Switch Vision v${SV_VERSION}`,"image":{"file":"faceplates/sv-dark.png","width":2048,"height":448,"master":"switch-master-v4.0","alpha_min":0,"alpha_max":255},"ports":{"1":{"center":[176,245],"number":[176,181],"led_left":[154,221],"led_right":[199,221],"hitbox":[34,56]},"2":{"center":[177,338],"number":[176,409],"led_left":[153,365],"led_right":[200,365],"hitbox":[34,56]},"3":{"center":[236,245],"number":[237,181],"led_left":[213,221],"led_right":[259,221],"hitbox":[34,56]},"4":{"center":[237,337],"number":[237,409],"led_left":[213,365],"led_right":[259,365],"hitbox":[34,56]},"5":{"center":[294,245],"number":[296,181],"led_left":[273,221],"led_right":[319,221],"hitbox":[34,56]},"6":{"center":[297,337],"number":[297,409],"led_left":[273,365],"led_right":[319,365],"hitbox":[34,56]},"7":{"center":[355,245],"number":[356,181],"led_left":[333,221],"led_right":[379,221],"hitbox":[34,56]},"8":{"center":[357,337],"number":[357,409],"led_left":[333,365],"led_right":[379,365],"hitbox":[34,56]},"9":{"center":[414,245],"number":[415,181],"led_left":[393,221],"led_right":[440,221],"hitbox":[34,56]},"10":{"center":[416,337],"number":[415,409],"led_left":[393,365],"led_right":[439,365],"hitbox":[34,56]},"11":{"center":[474,245],"number":[475,181],"led_left":[453,221],"led_right":[499,221],"hitbox":[34,56]},"12":{"center":[476,336],"number":[476,409],"led_left":[453,365],"led_right":[499,365],"hitbox":[34,56]},"13":{"center":[550,245],"number":[551,181],"led_left":[524,221],"led_right":[570,221],"hitbox":[34,56]},"14":{"center":[549,337],"number":[551,409],"led_left":[524,365],"led_right":[571,365],"hitbox":[34,56]},"15":{"center":[610,245],"number":[611,181],"led_left":[584,221],"led_right":[631,221],"hitbox":[34,56]},"16":{"center":[608,336],"number":[612,409],"led_left":[584,365],"led_right":[631,365],"hitbox":[34,56]},"17":{"center":[669,245],"number":[670,181],"led_left":[644,221],"led_right":[690,221],"hitbox":[34,56]},"18":{"center":[668,337],"number":[670,409],"led_left":[644,365],"led_right":[690,365],"hitbox":[34,56]},"19":{"center":[729,245],"number":[729,181],"led_left":[704,221],"led_right":[750,221],"hitbox":[34,56]},"20":{"center":[728,337],"number":[729,409],"led_left":[704,365],"led_right":[750,365],"hitbox":[34,56]},"21":{"center":[788,245],"number":[790,181],"led_left":[764,221],"led_right":[810,221],"hitbox":[34,56]},"22":{"center":[788,337],"number":[790,409],"led_left":[764,365],"led_right":[810,365],"hitbox":[34,56]},"23":{"center":[848,245],"number":[849,181],"led_left":[824,221],"led_right":[870,221],"hitbox":[34,56]},"24":{"center":[850,337],"number":[849,409],"led_left":[824,365],"led_right":[870,365],"hitbox":[34,56]},"25":{"center":[923,245],"number":[925,181],"led_left":[904,221],"led_right":[949,221],"hitbox":[34,56]},"26":{"center":[925,336],"number":[925,409],"led_left":[903,365],"led_right":[950,365],"hitbox":[34,56]},"27":{"center":[983,245],"number":[985,181],"led_left":[963,221],"led_right":[1009,221],"hitbox":[34,56]},"28":{"center":[984,336],"number":[985,409],"led_left":[963,365],"led_right":[1009,365],"hitbox":[34,56]},"29":{"center":[1043,245],"number":[1043,181],"led_left":[1023,221],"led_right":[1069,221],"hitbox":[34,56]},"30":{"center":[1045,337],"number":[1043,409],"led_left":[1023,365],"led_right":[1069,365],"hitbox":[34,56]},"31":{"center":[1105,245],"number":[1104,181],"led_left":[1083,221],"led_right":[1129,221],"hitbox":[34,56]},"32":{"center":[1104,337],"number":[1104,409],"led_left":[1083,365],"led_right":[1129,365],"hitbox":[34,56]},"33":{"center":[1162,245],"number":[1163,181],"led_left":[1143,221],"led_right":[1189,221],"hitbox":[34,56]},"34":{"center":[1164,337],"number":[1163,409],"led_left":[1143,365],"led_right":[1189,365],"hitbox":[34,56]},"35":{"center":[1225,245],"number":[1221,181],"led_left":[1203,221],"led_right":[1249,221],"hitbox":[34,56]},"36":{"center":[1223,337],"number":[1221,409],"led_left":[1203,365],"led_right":[1249,365],"hitbox":[34,56]},"37":{"center":[1297,245],"number":[1298,181],"led_left":[1273,221],"led_right":[1319,221],"hitbox":[34,56]},"38":{"center":[1298,337],"number":[1298,409],"led_left":[1273,365],"led_right":[1318,365],"hitbox":[34,56]},"39":{"center":[1355,245],"number":[1357,181],"led_left":[1333,221],"led_right":[1379,221],"hitbox":[34,56]},"40":{"center":[1358,337],"number":[1357,409],"led_left":[1332,365],"led_right":[1379,365],"hitbox":[34,56]},"41":{"center":[1416,245],"number":[1418,181],"led_left":[1393,221],"led_right":[1439,221],"hitbox":[34,56]},"42":{"center":[1417,337],"number":[1418,409],"led_left":[1393,365],"led_right":[1438,365],"hitbox":[34,56]},"43":{"center":[1475,245],"number":[1476,181],"led_left":[1453,221],"led_right":[1499,221],"hitbox":[34,56]},"44":{"center":[1477,336],"number":[1476,409],"led_left":[1453,365],"led_right":[1499,365],"hitbox":[34,56]},"45":{"center":[1534,245],"number":[1535,181],"led_left":[1513,221],"led_right":[1559,221],"hitbox":[34,56]},"46":{"center":[1537,337],"number":[1535,409],"led_left":[1513,365],"led_right":[1559,365],"hitbox":[34,56]},"47":{"center":[1594,245],"number":[1595,181],"led_left":[1573,221],"led_right":[1618,221],"hitbox":[34,56]},"48":{"center":[1596,337],"number":[1595,409],"led_left":[1572,365],"led_right":[1618,365],"hitbox":[34,56]}},"sfp":{"G1":{"center":[1710,246],"hitbox":[94,48]},"G2":{"center":[1835,246],"hitbox":[94,48]},"G3/TE3":{"center":[1711,341],"hitbox":[94,48]},"G4/TE4":{"center":[1836,341],"hitbox":[94,48]}},"status_leds":{"STAT":[674,84],"SYST":[674,149],"DUPLX":[852,84],"ACTV":[852,149],"SPEED":[1026,84],"STACK":[1204,84],"PoE":[1369,84]},"ui":{"logo":{"show":true,"file":"sv-logo.png","source":"default","x":143,"y":-1,"width":187,"height":188},"status_panel":{"show":true,"x":338,"y":30,"width":313,"height":132,"font_family":"SwitchVisionCustom, Arial, Helvetica, sans-serif","font_size":16,"title_font_size":16,"font_weight":"bold","text_color":"#ffffff","label_color":"#eef2f4","title_color":"#f4f6f7","background_color":"rgba(0,0,0,.06)","border_color":"rgba(245,248,250,.75)","border_show":true,"field_order":{"switch":["model","ip","cpu","temp","poe","uptime","vendor","os","firmware","serial","stack","fans","psu"],"port":["vlan","desc","link","rx","tx"],"sfp":["vlan","desc","link","rx","tx"]},"hidden_fields":{"switch":["vendor","os","firmware","serial","stack","fans","psu"],"port":[],"sfp":[]},"fields":{"title":[152.5,18],"row1_key":[19,39],"row1_value":[107,39],"row2_key":[19,58],"row2_value":[107,58],"row3_key":[19,78],"row3_value":[107,78],"row4_key":[19,97],"row4_value":[107,97],"row5_key":[19,116],"row5_value":[107,116]}},"faceplate":{"show":true,"file":"__default__","fit":"fill","opacity":1},"calibration_button":{"show":true,"x":1888,"y":14,"width":138,"height":34,"anchor":"top_right"},"status_panel_2":{"show":true,"x":1605,"y":25,"width":278,"height":55,"font_family":"SwitchVisionCustom, Arial, Helvetica, sans-serif","font_size":16,"title_font_size":16,"font_weight":"bold","text_color":"#ffffff","label_color":"#eef2f4","title_color":"#f4f6f7","background_color":"rgba(0,0,0,.06)","border_color":"rgba(245,248,250,.75)","border_show":true,"title_mode":"custom","title_field":"model","custom_title":"","field_order":{"switch":["model","ip","cpu","temp","poe","uptime","vendor","os","firmware","serial","stack","fans","psu"],"port":["vlan","desc","link","rx","tx"],"sfp":["vlan","desc","link","rx","tx"]},"hidden_fields":{"switch":["model","ip","cpu","temp","poe","uptime","vendor","os","firmware","serial","stack","fans","psu"],"port":[],"sfp":[]},"fields":{"title":[152.5,23],"row1_key":[24,55],"row1_value":[112,55],"row2_key":[24,72],"row2_value":[112,72],"row3_key":[24,89],"row3_value":[112,89],"row4_key":[24,106],"row4_value":[112,106],"row5_key":[24,123],"row5_value":[112,123]}}},"stack":{"enabled":false,"stack_id":"","uptime_source":"","members":{"SW5":{"member_number":1,"uptime_mode":"standalone","uptime_source":""}}},"management":{"switch_ip":"192.168.1.102"},"profile":"default_cisco_48_port"};
const layout = {"schema":"switch-vision-layout","version":"source-0.1","logo":{"file":"sv-logo.png","x":143,"y":-1,"width":187,"height":188,"fallback_text":"SV","fallback_x":72,"fallback_y":99},"model_text":{"text":"Catalyst 3650 48 PoE+ 2X10G","x":1742,"y":48,"anchor":"middle"},"status":{"radius":6.3,"mode_radius":7.2,"labels":{"MODE":{"dx":-34,"dy":0,"anchor":"end"},"STAT":{"dx":24,"dy":0,"anchor":"start"},"SYST":{"dx":24,"dy":0,"anchor":"start"},"DUPLX":{"dx":24,"dy":0,"anchor":"start"},"ACTV":{"dx":24,"dy":0,"anchor":"start"},"SPEED":{"dx":24,"dy":0,"anchor":"start"},"STACK":{"dx":24,"dy":0,"anchor":"start"},"PoE":{"dx":24,"dy":0,"anchor":"start"}}},"ports":{"odd":7,"even":-7,"r":3.1},"sfp":{"r":3.3,"labels":{"G1":{"x":1709,"y":188,"text":"G1"},"G2":{"x":1838,"y":188,"text":"G2"},"G3/TE3":{"x":1710,"y":402,"text":"G3 / TE3"},"G4/TE4":{"x":1839,"y":402,"text":"G4 / TE4"}}}};
function e(name) {
  return document.createElementNS("http://www.w3.org/2000/svg", name);
}

function circle(svg, x, y, r, cls) {
  const el = e("circle");
  el.setAttribute("class", cls);
  el.setAttribute("cx", x);
  el.setAttribute("cy", y);
  el.setAttribute("r", r);
  svg.appendChild(el);
  return el;
}

function text(svg, x, y, value, cls, anchor = "middle") {
  const el = e("text");
  el.setAttribute("class", cls);
  el.setAttribute("x", x);
  el.setAttribute("y", y);
  el.setAttribute("text-anchor", anchor);
  el.textContent = value;
  svg.appendChild(el);
  return el;
}

function image(svg, x, y, w, h, href, cls = "cv-logo-img") {
  const el = e("image");
  el.setAttribute("class", cls);
  el.setAttribute("x", x);
  el.setAttribute("y", y);
  el.setAttribute("width", w);
  el.setAttribute("height", h);
  el.setAttribute("href", href);
  el.setAttribute("preserveAspectRatio", "xMidYMid meet");
  svg.appendChild(el);
  return el;
}


function rect(svg, x, y, w, h, rx, cls) {
  const el = e("rect");
  el.setAttribute("class", cls);
  el.setAttribute("x", x);
  el.setAttribute("y", y);
  el.setAttribute("width", w);
  el.setAttribute("height", h);
  el.setAttribute("rx", rx);
  el.setAttribute("ry", rx);
  svg.appendChild(el);
  return el;
}

function line(svg, x1, y1, x2, y2, cls) {
  const el = e("line");
  el.setAttribute("class", cls);
  el.setAttribute("x1", x1);
  el.setAttribute("y1", y1);
  el.setAttribute("x2", x2);
  el.setAttribute("y2", y2);
  svg.appendChild(el);
  return el;
}

function applySvgStyle(el, styles = {}) {
  if (!el) return el;
  for (const [key, value] of Object.entries(styles || {})) {
    if (value !== null && value !== undefined && value !== "") el.style[key] = value;
  }
  return el;
}

function entityState(hass, entityId) {
  const entity = hass && entityId ? hass.states[entityId] : undefined;
  return entity ? String(entity.state).toLowerCase().trim() : null;
}

function rawEntityState(hass, entityId) {
  const entity = hass && entityId ? hass.states[entityId] : undefined;
  return entity ? String(entity.state).trim() : null;
}

function portRange(port) {
  const n = Number(port);
  if (n >= 1 && n <= 24) return "1_24";
  if (n >= 25 && n <= 48) return "25_48";
  return "";
}

function templateEntity(template, port) {
  const portKey = String(port);
  return String(template)
    .replaceAll("{port}", portKey)
    .replaceAll("{range}", portRange(port))
    .replaceAll("{range_dash}", portRange(port).replace("_", "-"));
}

function mappedPortNumber(config, port) {
  const n = Number(port);
  const offset = Number(config?.port_entity_offset || 0);
  return Number.isFinite(n) && Number.isFinite(offset) ? n + offset : port;
}

function displayedPortNumber(config, port) {
  const n = Number(port);
  const offset = Number(config?.port_label_offset || 0);
  return Number.isFinite(n) && Number.isFinite(offset) ? n + offset : port;
}

function portLabelIsRemapped(config) {
  const offset = Number(config?.port_label_offset || 0);
  return Number.isFinite(offset) && offset !== 0;
}

function portEntity(config, port, type = "status") {
  const key = `${type}_entity`;
  const mappedPort = mappedPortNumber(config, port);
  const portKey = String(mappedPort);

  if (config.ports?.[portKey]?.[key]) {
    return config.ports[portKey][key];
  }

  const templateKey = `${type}_entity_template`;
  if (config[templateKey]) {
    return templateEntity(config[templateKey], mappedPort);
  }

  const prefix = config[`${type}_entity_prefix`];
  const suffix = config[`${type}_entity_suffix`];

  if (prefix !== undefined && suffix !== undefined) {
    return `${prefix}${portKey}${suffix}`;
  }

  if (type === "speed" && config.auto_speed_entity !== false) {
    const member = String(config.member || "sw1").toLowerCase();
    return `sensor.${member}_port_${portKey}_speed_mbps`;
  }

  return null;
}

function listFromConfig(value, fallback) {
  if (Array.isArray(value)) return value.map(v => String(v).toLowerCase().trim());
  if (typeof value === "string") return value.split(",").map(v => v.toLowerCase().trim()).filter(Boolean);
  return fallback;
}

function portIsUp(hass, config, port) {
  if (config.demo) return true;

  const state = entityState(hass, portEntity(config, port, "status"));

  const upValues = listFromConfig(config.status_up_values, [
    "up", "on", "1", "true", "connected", "active", "online", "linkup", "link_up"
  ]);

  const downValues = listFromConfig(config.status_down_values, [
    "down", "off", "0", "2", "false", "disconnected", "inactive", "offline", "unavailable", "unknown", "linkdown", "link_down"
  ]);

  if (state === null) return false;
  if (downValues.includes(state)) return false;
  if (upValues.includes(state)) return true;

  return config.unknown_is_up === true;
}

function portSpeed(hass, config, port) {
  if (config.demo) {
    const n = Number(port);
    if ([7, 8, 31].includes(n)) return "10";
    if ([14, 27, 33].includes(n)) return "100";
    return "1000";
  }

  const raw = rawEntityState(hass, portEntity(config, port, "speed"));

  if (!raw || ["unknown", "unavailable", "none", "null"].includes(raw.toLowerCase())) {
    return "";
  }

  return raw;
}


function sfpEntity(config, member, port) {
  const m = String(member).toLowerCase();
  return `sensor.${m}_sfp_10g_${port}_status`;
}

function sfpStatusEntities(config, member, port) {
  const m = String(member).toLowerCase();
  const n = Number(port);

  // Prefer clean Switch Vision / SNMP2MQTT entity IDs.
  // Keep older entity IDs as fallbacks for existing dashboards.
  if (n === 1 || n === 2) {
    return [
      `sensor.${m}_sfp_10g_${n}_status`,
      `sensor.${m}_uplink_${n}_status`,
      `sensor.cisco_3650_${m}_uplinks_${m}_uplink_${n}_status`,
      `sensor.cisco_3650_${m}_uplink_${n}_status`
    ];
  }

  return [
    `sensor.${m}_sfp_10g_${n}_status`,
    `sensor.cisco_3650_${m}_sfp_10g_${n}_status`,
    `sensor.cisco_3650_${m}_uplinks_${m}_sfp_10g_${n}_status`,
    `sensor.cisco_3650_${m}_sfp_10g_${n}_${m}_sfp_10g_${n}_status`
  ];
}

function sfpIsUp(hass, config, port) {
  if (config.demo) return true;

  for (const entityId of sfpStatusEntities(config, config.member || "sw1", port)) {
    const state = entityState(hass, entityId);
    if (state === "1" || state === "up" || state === "on" || state === "true") return true;
    if (state === "2" || state === "down" || state === "off" || state === "false") return false;
  }

  return false;
}


function normalizePanelMember(config) {
  return String(config.member || "sw1").toLowerCase();
}

function usableValue(value) {
  if (value === null || value === undefined) return null;
  const raw = String(value).trim();
  if (!raw) return null;
  const low = raw.toLowerCase();
  if (["unknown", "unavailable", "none", "null", "nan"].includes(low)) return null;
  return raw;
}


function explicitConfigValue(config, keys) {
  const raw = config?.__raw_config && typeof config.__raw_config === "object" ? config.__raw_config : config;
  for (const key of keys) {
    if (!Object.prototype.hasOwnProperty.call(raw || {}, key)) continue;
    const value = usableValue(raw[key]);
    if (value !== null) return value;
  }
  return null;
}

function managementIpFromCalibration(cal) {
  const management = cal?.management && typeof cal.management === "object" ? cal.management : {};
  return usableValue(
    management.switch_ip ??
    management.management_ip ??
    management.mgmt_ip ??
    management.host_ip ??
    cal?.switch_ip ??
    cal?.management_ip
  );
}

function firstEntityValue(hass, entityIds) {
  for (const entityId of entityIds.filter(Boolean)) {
    const value = usableValue(rawEntityState(hass, entityId));
    if (value !== null) return value;
  }
  return null;
}

function configuredEntity(config, port, type) {
  const key = `${type}_entity`;
  const mappedPort = mappedPortNumber(config, port);
  const portKey = String(mappedPort);

  if (config.ports?.[portKey]?.[key]) return config.ports[portKey][key];

  const templateKey = `${type}_entity_template`;
  if (config[templateKey]) return templateEntity(config[templateKey], mappedPort);

  return null;
}

function switchConfiguredEntity(config, type) {
  const key = `${type}_entity`;
  return config[key] || null;
}

function trimText(value, max = 24) {
  const v = usableValue(value) || "—";
  return v.length > max ? `${v.slice(0, max - 1)}…` : v;
}

function speedLabel(raw, up = true) {
  const value = usableValue(raw);
  if (!up) return "Down";
  if (!value) return "—";

  const n = Number(String(value).replace(/[^0-9.]/g, ""));
  if (Number.isFinite(n) && n > 0) {
    if (n >= 10000) return `${Math.round(n / 1000)}G Full`;
    if (n >= 1000) return `${Math.round(n / 1000)}G Full`;
    return `${Math.round(n)}M Full`;
  }

  return value;
}

function formatBps(bps) {
  if (bps === null || bps === undefined) return "—";
  const n = Number(bps);
  if (!Number.isFinite(n)) return "—";

  // Traffic counters arrive as byte counters, then updateRateState converts the
  // delta to bits/sec for LED scaling. For the status window, display user-facing
  // throughput as bytes/sec instead of bits/sec.
  const bytesPerSecond = n / 8;

  if (bytesPerSecond <= 0) return "0 B/s";
  if (bytesPerSecond >= 1000000000) return `${(bytesPerSecond / 1000000000).toFixed(bytesPerSecond >= 10000000000 ? 0 : 2)} GB/s`;
  if (bytesPerSecond >= 1000000) return `${(bytesPerSecond / 1000000).toFixed(bytesPerSecond >= 100000000 ? 0 : 1)} MB/s`;
  if (bytesPerSecond >= 1000) return `${(bytesPerSecond / 1000).toFixed(bytesPerSecond >= 100000 ? 0 : 1)} KB/s`;
  return `${Math.round(bytesPerSecond)} B/s`;
}


function cleanVlanValue(value) {
  const raw = usableValue(value);
  if (!raw) return null;
  const up = raw.toUpperCase();

  // Trunk ports can report TRUNK directly from the VLAN ID sensor.
  if (up.includes("TRUNK")) return "TRUNK";

  // Access ports can report either a plain number or a VLAN-labelled string.
  const vlanMatch = raw.match(/\bVLAN\s*([0-9]{1,4})\b/i) || raw.match(/\bVID\s*([0-9]{1,4})\b/i);
  if (vlanMatch) return vlanMatch[1];

  if (/^[0-9]{1,4}$/.test(raw)) return raw;

  return null;
}

function cleanVlanList(value) {
  const raw = usableValue(value);
  if (!raw) return [];
  const numbers = String(raw).match(/\b\d{1,4}\b/g) || [];
  return [...new Set(numbers.map((item) => String(Number(item))).filter((item) => Number(item) >= 1 && Number(item) <= 4094))]
    .sort((a, b) => Number(a) - Number(b));
}

function isJuniperPortPresentation(hass, config) {
  const member = normalizePanelMember(config).toLowerCase();
  const configured = [
    config?.switch_model,
    config?.detected_switch_model,
    config?.exact_model,
    config?.model,
    config?.vendor,
    config?.manufacturer,
    config?.os,
  ].filter(Boolean).join(" ");
  if (/Juniper|JUNOS|EX3300/i.test(configured)) return true;

  const discovered = firstEntityValue(hass, [
    `sensor.${member}_vendor`,
    `sensor.${member}_manufacturer`,
    `sensor.${member}_model`,
    `sensor.${member}_system_description`,
    `sensor.${member}_sysdescr`,
  ]);
  return /Juniper|JUNOS|EX3300/i.test(String(discovered || ""));
}

function cleanTrunkStatus(value) {
  const raw = usableValue(value);
  if (!raw) return null;
  const up = raw.toUpperCase().replace(/[\s_-]+/g, "");

  // CISCO-VTP-MIB::vlanTrunkPortDynamicStatus
  // 1 = trunking, 2 = notTrunking. This is now the authority for trunk detection.
  if (raw === "1" || up === "TRUNK" || up === "TRUNKING") return true;
  if (raw === "2" || up === "NOTTRUNK" || up === "NOTTRUNKING" || up === "ACCESS" || up === "STATIC") return false;

  return null;
}

function deriveVlan(vlanCandidate, trunkStatusCandidate = null) {
  const trunk = cleanTrunkStatus(trunkStatusCandidate);
  if (trunk === true) return "TRUNK";

  const vlan = cleanVlanValue(vlanCandidate);
  if (vlan) return vlan;

  return "—";
}

function normalizeDescription(value) {
  const raw = usableValue(value);
  if (!raw) return "—";
  return raw;
}

function selectedPortDetails(hass, config, port) {
  const internalPort = Number(port);
  const n = Number(mappedPortNumber(config, internalPort));
  const member = normalizePanelMember(config);
  const range = portRange(n);

  // Prefer the mapped entity port, while retaining the internal calibration
  // position as a compatibility fallback for older hand-written cards.
  const staticPort = config.ports?.[String(n)] || config.ports?.[String(internalPort)] || {};

  const modeCandidate = usableValue(staticPort.mode) || firstEntityValue(hass, [
    configuredEntity(config, internalPort, "mode"),
    `sensor.${member}_port_${n}_mode`
  ]);

  const vlanCandidate = usableValue(staticPort.native_vlan) || usableValue(staticPort.vlan) || firstEntityValue(hass, [
    // v0.4.51 real VLAN sensors. Prefer these before any alias/description guessing.
    configuredEntity(config, internalPort, "vlan_id"),
    configuredEntity(config, internalPort, "vlan"),
    `sensor.${member}_port_${n}_vlan_id`,
    `sensor.${member}_port_${n}_vlan`,

    // Legacy compatibility fallbacks.
    `sensor.cisco_3650_${member}_ports_${range}_${member}_port_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_ports_${range}_${member}_port_${n}_vlan`,
    `sensor.cisco_3650_${member}_port_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_port_${n}_vlan`
  ]);

  const allowedVlansCandidate = usableValue(staticPort.allowed_vlans) || usableValue(staticPort.vlans) || firstEntityValue(hass, [
    configuredEntity(config, internalPort, "allowed_vlans"),
    configuredEntity(config, internalPort, "vlans"),
    `sensor.${member}_port_${n}_allowed_vlans`,
    `sensor.${member}_port_${n}_vlans`
  ]);

  const trunkStatusCandidate = usableValue(staticPort.trunk_status) || modeCandidate || firstEntityValue(hass, [
    // CISCO-VTP-MIB::vlanTrunkPortDynamicStatus. 1 = trunking, 2 = notTrunking.
    configuredEntity(config, internalPort, "trunk_status"),
    `sensor.${member}_port_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_ports_${range}_${member}_port_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_port_${n}_trunk_status`
  ]);

  const descriptionRaw =
    usableValue(staticPort.alias) ||
    usableValue(staticPort.description) ||
    usableValue(staticPort.name) ||
    firstEntityValue(hass, [
      // Alias first.
      configuredEntity(config, internalPort, "alias"),
      `sensor.${member}_port_${n}_alias`,
      `sensor.cisco_3650_${member}_port_${n}_alias`,

      // Description second.
      configuredEntity(config, internalPort, "description"),
      `sensor.${member}_port_${n}_description`,
      `sensor.${member}_port_${n}_desc`,
      `sensor.cisco_3650_${member}_port_${n}_description`,
      `sensor.cisco_3650_${member}_port_${n}_desc`,

      // Name last.
      configuredEntity(config, internalPort, "name"),
      `sensor.${member}_port_${n}_name`,
      `sensor.cisco_3650_${member}_port_${n}_name`
    ]);

  const speed = portSpeed(hass, config, internalPort);
  const up = portIsUp(hass, config, internalPort);

  const trunk = cleanTrunkStatus(trunkStatusCandidate) === true;
  const nativeVlan = cleanVlanValue(vlanCandidate);
  const isJuniper = isJuniperPortPresentation(hass, config);
  const allowedVlans = cleanVlanList(allowedVlansCandidate);
  const juniperVlans = allowedVlans.length ? allowedVlans : (nativeVlan ? [nativeVlan] : []);

  return {
    isJuniper,
    mode: trunk ? "TRUNK" : "ACCESS",
    vlanLabel: isJuniper && juniperVlans.length > 1 ? "VLANS" : "VLAN",
    vlan: isJuniper
      ? trimText(juniperVlans.length ? juniperVlans.join(", ") : (trunk ? "TRUNK" : "—"), 20)
      : trimText(deriveVlan(vlanCandidate, trunkStatusCandidate), 12),
    description: trimText(normalizeDescription(descriptionRaw), 22),
    link: speedLabel(speed, up)
  };
}

function selectedSfpDetails(hass, config, port) {
  const n = Number(port);
  const member = normalizePanelMember(config);
  const up = sfpIsUp(hass, config, n);
  const staticSfp = config.sfp?.[String(n)] || {};

  const vlanCandidate = usableValue(staticSfp.vlan) || firstEntityValue(hass, [
    configuredEntity(config, n, "sfp_vlan_id"),
    configuredEntity(config, n, "sfp_vlan"),
    `sensor.${member}_sfp_10g_${n}_vlan_id`,
    `sensor.${member}_sfp_10g_${n}_vlan`,
    `sensor.${member}_uplink_${n}_vlan_id`,
    `sensor.${member}_uplink_${n}_vlan`,
    `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_vlan`,
    `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_vlan`,
    `sensor.cisco_3650_${member}_sfp_10g_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_sfp_10g_${n}_vlan`,
    `sensor.cisco_3650_${member}_uplink_${n}_vlan_id`,
    `sensor.cisco_3650_${member}_uplink_${n}_vlan`
  ]);

  const trunkStatusCandidate = usableValue(staticSfp.trunk_status) || firstEntityValue(hass, [
    // CISCO-VTP-MIB::vlanTrunkPortDynamicStatus. 1 = trunking, 2 = notTrunking.
    configuredEntity(config, n, "sfp_trunk_status"),
    configuredEntity(config, n, "trunk_status"),
    `sensor.${member}_sfp_10g_${n}_trunk_status`,
    `sensor.${member}_uplink_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_sfp_10g_${n}_trunk_status`,
    `sensor.cisco_3650_${member}_uplink_${n}_trunk_status`
  ]);

  const descriptionRaw =
    usableValue(staticSfp.alias) ||
    usableValue(staticSfp.description) ||
    usableValue(staticSfp.name) ||
    firstEntityValue(hass, [
      // Alias first.
      configuredEntity(config, n, "sfp_alias"),
      `sensor.${member}_sfp_10g_${n}_alias`,
      `sensor.${member}_uplink_${n}_alias`,
      `sensor.cisco_3650_${member}_sfp_10g_${n}_alias`,
      `sensor.cisco_3650_${member}_uplink_${n}_alias`,
      `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_alias`,
      `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_alias`,

      // Description second.
      configuredEntity(config, n, "sfp_description"),
      `sensor.${member}_sfp_10g_${n}_description`,
      `sensor.${member}_uplink_${n}_description`,
      `sensor.cisco_3650_${member}_sfp_10g_${n}_description`,
      `sensor.cisco_3650_${member}_uplink_${n}_description`,
      `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_description`,
      `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_description`,

      // Name last.
      configuredEntity(config, n, "sfp_name"),
      `sensor.${member}_sfp_10g_${n}_name`,
      `sensor.${member}_uplink_${n}_name`,
      `sensor.cisco_3650_${member}_sfp_10g_${n}_name`,
      `sensor.cisco_3650_${member}_uplink_${n}_name`,
      `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_name`,
      `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_name`
    ]);

  const sfpVlan = deriveVlan(vlanCandidate, trunkStatusCandidate);

  return {
    vlan: trimText(sfpVlan, 10),
    description: trimText(normalizeDescription(descriptionRaw), 22),
    link: up ? "10G Full" : "Down"
  };
}

function switchPoeActive(hass, config) {
  const member = normalizePanelMember(config).toLowerCase();
  const poeUsed = firstEntityValue(hass, [
    `sensor.${member}_poe_used_mw`,
    `sensor.${member}_poe_used`,
    `sensor.cisco_3650_${member}_poe_used_mw`,
    `sensor.cisco_3650_${member}_poe_used`
  ]);

  if (!poeUsed) return false;

  const numeric = Number(String(poeUsed).replace(/[^0-9.]/g, ""));
  return Number.isFinite(numeric) && numeric > 0;
}

function formatPercent(value) {
  const raw = usableValue(value);
  if (!raw) return "—";
  const text = String(raw).trim();
  if (text.includes("%")) return text;
  const n = Number(text.replace(/[^0-9.-]/g, ""));
  if (!Number.isFinite(n)) return text;
  return `${Math.round(n)}%`;
}

function formatTemperature(value) {
  const raw = usableValue(value);
  if (!raw) return "—";
  const text = String(raw).trim();
  if (/°|c|f/i.test(text)) return text;
  const n = Number(text.replace(/[^0-9.-]/g, ""));
  if (!Number.isFinite(n)) return text;
  return `${Math.round(n)}°C`;
}

function formatUptime(value) {
  const raw = usableValue(value);
  if (!raw) return "—";
  const text = String(raw).trim();

  // Net-SNMP often returns Timeticks as: "(123456789) 14 days, 6:56:07.89".
  const daysMatch = text.match(/(\d+)\s+days?,\s*(\d+):(\d+):(\d+)/i);
  if (daysMatch) return `${daysMatch[1]}d ${daysMatch[2]}h ${daysMatch[3]}m`;

  const timeMatch = text.match(/(?:(\d+)\s+days?,\s*)?(\d+):(\d+):(\d+)/i);
  if (timeMatch) {
    const d = Number(timeMatch[1] || 0);
    const h = Number(timeMatch[2] || 0);
    const m = Number(timeMatch[3] || 0);
    return d > 0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m`;
  }

  // Raw SNMP Timeticks are hundredths of a second.
  const n = Number(text.replace(/[^0-9.]/g, ""));
  if (Number.isFinite(n) && n > 0) {
    let seconds = Math.floor(n / 100);
    const days = Math.floor(seconds / 86400);
    seconds %= 86400;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    return days > 0 ? `${days}d ${hours}h ${minutes}m` : `${hours}h ${minutes}m`;
  }

  return text;
}

function defaultStackProfile() {
  return {
    enabled: false,
    stack_id: "",
    uptime_source: "",
    members: {}
  };
}

function normaliseStackUptimeMode(value) {
  const mode = String(value || "standalone").trim().toLowerCase().replace(/[\s-]+/g, "_");
  if (["inherit", "inherited", "inherit_stack", "inherited_from_stack", "stack_inherit", "shared"].includes(mode)) return "inherit_stack";
  if (["stack_source", "source", "primary", "shared_source"].includes(mode)) return "stack_source";
  return "standalone";
}

function ensureCalibrationStack(cal) {
  if (!cal) return cal;
  const defaults = defaultStackProfile();
  const stack = cal.stack && typeof cal.stack === "object" && !Array.isArray(cal.stack) ? cal.stack : {};
  stack.enabled = stack.enabled === true;
  stack.stack_id = String(stack.stack_id || stack.id || defaults.stack_id || "");
  stack.uptime_source = String(stack.uptime_source || defaults.uptime_source || "");
  stack.members = stack.members && typeof stack.members === "object" && !Array.isArray(stack.members) ? stack.members : {};

  for (const [key, value] of Object.entries(stack.members)) {
    const member = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    member.member_number = Number(member.member_number ?? member.number ?? "") || Number(String(key).replace(/[^0-9]/g, "")) || "";
    member.uptime_mode = normaliseStackUptimeMode(member.uptime_mode || member.mode);
    member.uptime_source = String(member.uptime_source || "");
    stack.members[String(key).toUpperCase()] = member;
    if (String(key).toUpperCase() !== key) delete stack.members[key];
  }

  cal.stack = stack;
  return cal;
}

function stackFromCalibration(cal) {
  return ensureCalibrationStack(cal)?.stack || defaultStackProfile();
}

function configuredStackProfile(config, cal) {
  const calStack = stackFromCalibration(cal);
  const cfgStack = config?.stack && typeof config.stack === "object" && !Array.isArray(config.stack) ? config.stack : {};
  const stack = {
    ...calStack,
    ...cfgStack,
    members: { ...(calStack.members || {}), ...(cfgStack.members || {}), ...(config?.stack_members || {}) }
  };
  if (config?.stack_enabled !== undefined) stack.enabled = config.stack_enabled === true;
  if (config?.stack_id !== undefined) stack.stack_id = String(config.stack_id || "");
  if (config?.stack_uptime_source !== undefined) stack.uptime_source = String(config.stack_uptime_source || "");
  if (config?.stack_member_number !== undefined || config?.stack_uptime_mode !== undefined || config?.stack_member_uptime_source !== undefined) {
    const member = String(normalizePanelMember(config)).toUpperCase();
    stack.members[member] = {
      ...(stack.members[member] || {}),
      member_number: Number(config.stack_member_number || stack.members[member]?.member_number || "") || "",
      uptime_mode: normaliseStackUptimeMode(config.stack_uptime_mode || stack.members[member]?.uptime_mode),
      uptime_source: String(config.stack_member_uptime_source || stack.members[member]?.uptime_source || "")
    };
  }
  return stack;
}

function stackMemberSettings(config, cal, memberName = normalizePanelMember(config)) {
  const stack = configuredStackProfile(config, cal);
  const key = String(memberName || "").toUpperCase();
  const raw = stack.members?.[key] || {};
  const memberNumber = Number(raw.member_number ?? raw.number ?? "") || Number(key.replace(/[^0-9]/g, "")) || "";
  return {
    stack,
    member: {
      ...raw,
      member_number: memberNumber,
      uptime_mode: normaliseStackUptimeMode(raw.uptime_mode || raw.mode),
      uptime_source: String(raw.uptime_source || "")
    }
  };
}

function entityIdsFromValue(value) {
  if (value === null || value === undefined || value === false) return [];
  if (Array.isArray(value)) return value.flatMap(entityIdsFromValue);
  return String(value).split(/[\s,]+/).map((v) => v.trim()).filter(Boolean);
}

function switchUptimeCandidates(config, cal, memberName) {
  const member = String(memberName || normalizePanelMember(config)).toUpperCase();
  const m = member.toLowerCase();
  const { stack, member: stackMember } = stackMemberSettings(config, cal, member);
  const mode = normaliseStackUptimeMode(stackMember.uptime_mode);
  const inheritedSource = stackMember.uptime_source || stack.uptime_source;
  const explicit = [switchConfiguredEntity(config, "uptime")].filter(Boolean);

  if (mode === "inherit_stack" || mode === "stack_source") {
    explicit.push(...entityIdsFromValue(inheritedSource));
  }

  return [
    ...explicit,
    `sensor.${m}_uptime`,
    `sensor.${m}_system_uptime`
  ];
}

function switchStackLabel(config, cal, memberName) {
  const { stack, member } = stackMemberSettings(config, cal, memberName);
  if (!stack.enabled) return "Healthy";
  const rawNumber = Number(member.member_number || 0);
  const derivedNumber = Number(String(memberName || "").replace(/[^0-9]/g, "")) || 0;
  const n = rawNumber >= 1 && rawNumber <= 16 ? rawNumber : (derivedNumber >= 1 && derivedNumber <= 16 ? derivedNumber : "");
  const mode = normaliseStackUptimeMode(member.uptime_mode);
  if (mode === "inherit_stack") return n ? `Member ${n}` : "Stack member";
  if (mode === "stack_source") return n ? `Member ${n} source` : "Stack source";
  return n ? `Member ${n}` : "Stacked";
}

function firstEntityRecord(hass, candidates) {
  for (const entityId of candidates.filter(Boolean)) {
    const entity = hass?.states?.[entityId];
    if (entity && usableValue(entity.state) !== null) return { entityId, entity };
  }
  return null;
}

function poeWatts(hass, candidates) {
  const record = firstEntityRecord(hass, candidates);
  if (!record) return null;
  const text = String(record.entity.state ?? "").trim();
  const numeric = Number(text.replace(/[^0-9.-]/g, ""));
  if (!Number.isFinite(numeric)) return null;
  const unit = String(record.entity.attributes?.unit_of_measurement || "").trim().toLowerCase();
  const id = record.entityId.toLowerCase();
  if (unit === "mw" || id.endsWith("_mw")) return numeric / 1000;
  if (unit === "kw" || id.endsWith("_kw")) return numeric * 1000;
  if (unit === "w" || id.endsWith("_w")) return numeric;
  // Legacy generated entities sometimes had no unit attribute. Cisco 2960
  // aggregate PoE values are watts; 3650 aggregate values are milliwatts.
  return numeric >= 10000 ? numeric / 1000 : numeric;
}

function parseSystemDescription(value) {
  const raw = usableValue(value);
  if (!raw) return { vendor: null, os: null, firmware: null };
  const text = String(raw).trim();

  if (/Juniper Networks|\bJUNOS\b|\bEX3300\b/i.test(text)) {
    const version = text.match(/\bJUNOS\s+([^,\s]+)/i);
    return {
      vendor: "Juniper",
      os: "Junos OS",
      firmware: version ? version[1].trim() : null
    };
  }

  const vendor = /Cisco|Catalyst/i.test(text) ? "Cisco Systems" : null;
  let os = null;
  if (/IOS XE/i.test(text) || /\[Gibraltar\]|\[Amsterdam\]|CAT3K/i.test(text)) os = "Cisco IOS XE";
  else if (/Cisco IOS Software/i.test(text)) os = "Cisco IOS";
  const version = text.match(/\bVersion\s+([^,]+)/i);
  return { vendor, os, firmware: version ? version[1].trim() : null };
}

function formatJuniperOperatingState(value) {
  const raw = usableValue(value);
  if (!raw) return "—";
  const numeric = Number(String(raw).replace(/[^0-9.-]/g, ""));
  if (!Number.isFinite(numeric)) return raw;
  const labels = {
    1: "Unknown",
    2: "Healthy",
    3: "Ready",
    4: "Resetting",
    5: "Healthy",
    6: "Down",
    7: "Standby"
  };
  return labels[numeric] || raw;
}

function switchStatusValues(hass, config, cal = calibration) {
  const member = normalizePanelMember(config).toUpperCase();
  const m = member.toLowerCase();

  const cpu = firstEntityValue(hass, [
    switchConfiguredEntity(config, "cpu"),
    switchConfiguredEntity(config, "cpu_5min"),
    `sensor.${m}_cpu_5min`,
    `sensor.${m}_cpu_1min`,
    `sensor.${m}_cpu_5sec`,
    `sensor.cisco_3650_${m}_cpu_5min`,
    `sensor.cisco_3650_${m}_cpu_1min`,
    `sensor.cisco_3650_${m}_cpu_5sec`
  ]);

  const uptime = firstEntityValue(hass, switchUptimeCandidates(config, cal, member));

  const temp = firstEntityValue(hass, [
    switchConfiguredEntity(config, "temperature"),
    switchConfiguredEntity(config, "temp"),
    `sensor.${m}_temperature`,
    `sensor.${m}_temp`,
    `sensor.${m}_switch_temperature`,
    `sensor.${m}_system_temperature`,
    `sensor.cisco_3650_${m}_temperature`,
    `sensor.cisco_3650_${m}_temp`,
    `sensor.cisco_3650_${m}_switch_temperature`,
    `sensor.cisco_3650_${m}_system_temperature`
  ]);

  const fans = firstEntityValue(hass, [
    switchConfiguredEntity(config, "fans"),
    `sensor.${m}_fans`,
    `sensor.${m}_fan_status`,
    `sensor.cisco_3650_${m}_fans`,
    `sensor.cisco_3650_${m}_fan_status`
  ]) || "OK";

  const psu = firstEntityValue(hass, [
    switchConfiguredEntity(config, "psu"),
    `sensor.${m}_psu`,
    `sensor.${m}_psu_status`,
    `sensor.cisco_3650_${m}_psu`,
    `sensor.cisco_3650_${m}_psu_status`
  ]) || "OK";

  const poeUsed = poeWatts(hass, [
    switchConfiguredEntity(config, "poe_used"),
    switchConfiguredEntity(config, "poe_used_mw"),
    `sensor.${m}_poe_used`,
    `sensor.${m}_poe_used_w`,
    `sensor.${m}_poe_used_mw`,
    `sensor.cisco_3650_${m}_poe_used`,
    `sensor.cisco_3650_${m}_poe_used_w`,
    `sensor.cisco_3650_${m}_poe_used_mw`
  ]);
  const poeBudget = poeWatts(hass, [
    switchConfiguredEntity(config, "poe_budget"),
    switchConfiguredEntity(config, "poe_budget_mw"),
    `sensor.${m}_poe_budget`,
    `sensor.${m}_poe_budget_w`,
    `sensor.${m}_poe_budget_mw`,
    `sensor.cisco_3650_${m}_poe_budget`,
    `sensor.cisco_3650_${m}_poe_budget_w`,
    `sensor.cisco_3650_${m}_poe_budget_mw`
  ]);

  const poeAvailable = poeUsed !== null && poeBudget !== null;
  const poe = poeAvailable
    ? `${Math.round(poeUsed)} / ${Math.round(poeBudget)} W`
    : "—";

  const ip = explicitConfigValue(config, ["switch_ip", "management_ip", "mgmt_ip", "host_ip", "snmp_host"]) ||
    managementIpFromCalibration(cal) ||
    firstEntityValue(hass, [
      switchConfiguredEntity(config, "ip"),
      switchConfiguredEntity(config, "switch_ip"),
      switchConfiguredEntity(config, "management_ip"),
      `sensor.${m}_ip`,
      `sensor.${m}_switch_ip`,
      `sensor.${m}_management_ip`,
      `sensor.${m}_mgmt_ip`,
      `sensor.cisco_3650_${m}_ip`,
      `sensor.cisco_3650_${m}_management_ip`
    ]) || "—";

  const identityValue = (key, fallbacks = []) => explicitConfigValue(config, [key, `switch_${key}`]) || firstEntityValue(hass, [
    switchConfiguredEntity(config, key),
    `sensor.${m}_${key}`,
    ...fallbacks
  ]) || "—";
  const model = identityValue("model", [`sensor.${m}_model_text`, `sensor.${m}_model_name`]);
  const systemDescription = firstEntityValue(hass, [
    switchConfiguredEntity(config, "system_description"),
    `sensor.${m}_system_description`,
    `sensor.${m}_sysdescr`
  ]);
  const parsedIdentity = parseSystemDescription(systemDescription);
  const vendor = explicitConfigValue(config, ["vendor", "switch_vendor"]) || firstEntityValue(hass, [
    switchConfiguredEntity(config, "vendor"),
    `sensor.${m}_vendor`,
    `sensor.${m}_manufacturer`
  ]) || parsedIdentity.vendor || "—";
  const osName = explicitConfigValue(config, ["os", "switch_os"]) || firstEntityValue(hass, [
    switchConfiguredEntity(config, "os"),
    `sensor.${m}_os`,
    `sensor.${m}_platform`,
    `sensor.${m}_operating_system`
  ]) || parsedIdentity.os || "—";
  const firmware = explicitConfigValue(config, ["firmware", "switch_firmware"]) || firstEntityValue(hass, [
    switchConfiguredEntity(config, "firmware"),
    `sensor.${m}_firmware`,
    `sensor.${m}_software_version`,
    `sensor.${m}_ios_version`
  ]) || parsedIdentity.firmware || "—";
  const serial = identityValue("serial", [`sensor.${m}_serial_number`]);

  const isJuniper = /Juniper/i.test(String(model || "")) || /Juniper/i.test(String(vendor || "")) || /JUNOS/i.test(String(systemDescription || ""));

  return {
    member,
    model, vendor, os: osName, firmware, serial,
    stack: isJuniper && !configuredStackProfile(config, cal).enabled ? "Standalone" : switchStackLabel(config, cal, member),
    cpu: formatPercent(cpu),
    temp: formatTemperature(temp),
    uptime: formatUptime(uptime),
    fans: isJuniper ? formatJuniperOperatingState(fans) : fans,
    psu: isJuniper ? formatJuniperOperatingState(psu) : psu,
    poe,
    poeAvailable,
    ip
  };
}

function makeRows(values, fields, labels) {
  return fields.map((field) => [labels[field] || field.toUpperCase(), values[field] ?? "—"]);
}

const STATUS_PANEL_ROW_DEFS = {
  switch: {
    defaults: ["model", "ip", "cpu", "temp", "poe", "uptime", "vendor", "os", "firmware", "serial", "stack", "fans", "psu"],
    hidden: ["vendor", "os", "firmware", "serial", "stack", "fans", "psu"],
    labels: { model: "MODEL", vendor: "VENDOR", os: "OS", firmware: "FIRMWARE", serial: "SERIAL", stack: "STACK", cpu: "CPU", temp: "TEMP", uptime: "UPTIME", fans: "FANS", psu: "PSU", poe: "POE", ip: "IP" }
  },
  port: {
    defaults: ["vlan", "desc", "link", "rx", "tx"],
    hidden: [],
    labels: { vlan: "VLAN", desc: "DESC", link: "LINK", rx: "RX", tx: "TX" }
  },
  sfp: {
    defaults: ["vlan", "desc", "link", "rx", "tx"],
    hidden: [],
    labels: { vlan: "VLAN", desc: "DESC", link: "LINK", rx: "RX", tx: "TX" }
  }
};

function normalStatusPanelRowType(type) {
  const t = String(type || "switch").toLowerCase();
  return t === "port" || t === "sfp" ? t : "switch";
}

function fieldListFromValue(value) {
  if (value === null || value === undefined || value === false) return null;
  if (Array.isArray(value)) return value.map((v) => String(v).trim().toLowerCase()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((v) => v.trim().toLowerCase()).filter(Boolean);
  return null;
}

function normaliseStatusPanelFieldOrder(value, type) {
  type = normalStatusPanelRowType(type);
  const defs = STATUS_PANEL_ROW_DEFS[type]?.defaults || STATUS_PANEL_ROW_DEFS.switch.defaults;
  const seen = new Set();
  const out = [];
  for (const field of (fieldListFromValue(value) || defs)) {
    if (!defs.includes(field) || seen.has(field)) continue;
    seen.add(field);
    out.push(field);
  }
  for (const field of defs) {
    if (!seen.has(field)) out.push(field);
  }
  return out;
}

function ensureStatusPanelFieldState(panel) {
  if (!panel || typeof panel !== "object") return panel;
  panel.field_order = panel.field_order && typeof panel.field_order === "object" && !Array.isArray(panel.field_order) ? panel.field_order : {};
  panel.hidden_fields = panel.hidden_fields && typeof panel.hidden_fields === "object" && !Array.isArray(panel.hidden_fields) ? panel.hidden_fields : {};

  for (const type of Object.keys(STATUS_PANEL_ROW_DEFS)) {
    panel.field_order[type] = normaliseStatusPanelFieldOrder(panel.field_order[type], type);
    const defs = STATUS_PANEL_ROW_DEFS[type].defaults;
    const fallbackHidden = STATUS_PANEL_ROW_DEFS[type].hidden || [];
    const hidden = fieldListFromValue(panel.hidden_fields[type]);
    panel.hidden_fields[type] = (hidden || fallbackHidden).filter((field, idx, arr) => defs.includes(field) && arr.indexOf(field) === idx);
  }
  return panel;
}

function statusPanelRowTypeForConfig(config, panelNumber = 1) {
  // Status Box 2 is always a switch-summary box. Port and SFP selection
  // details belong exclusively to Status Box 1.
  const selected = panelNumber === 2 ? null : selectedInterface(config);
  if (selected?.type === "port") return "port";
  if (selected?.type === "sfp") return "sfp";
  return "switch";
}

function statusPanelFieldSelection(config, type, cal, panelNumber = 1) {
  type = normalStatusPanelRowType(type);
  const defaults = STATUS_PANEL_ROW_DEFS[type]?.defaults || STATUS_PANEL_ROW_DEFS.switch.defaults;
  const panel = ensureStatusPanelFieldState(uiFromCalibration(cal)[panelNumber === 2 ? "status_panel_2" : "status_panel"]);

  // Status Box 2 must remain fully independent from Status Box 1. Earlier builds
  // reused the unsuffixed card-level field keys for both boxes, which could hide
  // Box 2 rows even after they were unhidden and saved in its calibration profile.
  const prefix = panelNumber === 2 ? "status_panel_2" : "status_panel";
  const scopedKey = `${prefix}_${type}_fields`;
  const hiddenKey = `${prefix}_${type}_hidden_fields`;
  const genericFieldsKey = `${prefix}_fields`;
  const genericHiddenKey = `${prefix}_hidden_fields`;

  let selected = fieldListFromValue(config[scopedKey]);

  if (!selected && config[genericFieldsKey] && typeof config[genericFieldsKey] === "object" && !Array.isArray(config[genericFieldsKey])) {
    selected = fieldListFromValue(config[genericFieldsKey][type]);
  }

  if (!selected) selected = fieldListFromValue(config[genericFieldsKey]);

  // Preserve compatibility with old manual YAML only for Status Box 1. Box 2
  // must never inherit Box 1 visibility overrides.
  if (panelNumber === 1) {
    if (!selected && config.status_panel_fields && typeof config.status_panel_fields === "object" && !Array.isArray(config.status_panel_fields)) {
      selected = fieldListFromValue(config.status_panel_fields[type]);
    }
    if (!selected) selected = fieldListFromValue(config.status_panel_fields);
  }

  if (!selected) selected = panel?.field_order?.[type];
  selected = normaliseStatusPanelFieldOrder(selected, type);

  const hidden = new Set([
    ...(fieldListFromValue(panel?.hidden_fields?.[type]) || []),
    ...(fieldListFromValue(config[genericHiddenKey]) || []),
    ...(fieldListFromValue(config[hiddenKey]) || [])
  ]);

  if (panelNumber === 1) {
    for (const field of fieldListFromValue(config.status_panel_hidden_fields) || []) hidden.add(field);
    for (const field of fieldListFromValue(config[`status_panel_${type}_hidden_fields`]) || []) hidden.add(field);
  }

  return selected.filter((field) => defaults.includes(field) && !hidden.has(field));
}

function switchSummaryDetails(hass, config, cal, panelNumber = 1) {
  const values = switchStatusValues(hass, config, cal);
  let fields = statusPanelFieldSelection(config, "switch", cal, panelNumber);
  if (!values.poeAvailable) fields = fields.filter((field) => field !== "poe");
  const labels = STATUS_PANEL_ROW_DEFS.switch.labels;

  return {
    member: values.member,
    rows: makeRows(values, fields, labels)
  };
}

function speedClass(speed, up = true) {
  if (!up) return "cv-led-off";

  const s = String(speed || "").toLowerCase().replace(/\s+/g, "");
  const numeric = Number(s.replace(/[^0-9.]/g, ""));

  if (numeric >= 10000 || s.includes("10g") || s.includes("10gb")) return "cv-led-blue";
  if (numeric >= 1000 || s.includes("1g") || s.includes("gigabit")) return "cv-led-green";
  if (numeric >= 100 || s.includes("100m") || s.includes("fast")) return "cv-led-amber";
  if (numeric >= 10 || s.includes("10m")) return "cv-led-red";

  return "cv-led-green";
}

function activityClass(config, up = true) {
  if (!up) return "cv-led-off";
  return config.activity_led_class || "cv-led-amber";
}

function statusLedClass(name, demo = true, options = {}) {
  const poeActive = options.poeActive === true;
  const stackActive = options.stackActive === true;

  // STACK is intentionally vendor-neutral and configuration-driven. It is blue
  // only when this switch is explicitly confirmed as a stack member; otherwise
  // the LED remains off, including demo mode and standalone/unknown devices.
  if (name === "STACK") return stackActive ? "cv-led-blue" : "cv-led-off";

  if (demo) {
    if (name === "DUPLX") return "cv-led-off";
    if (name === "PoE") return poeActive ? "cv-led-poe" : "cv-led-off";
    return "cv-led-green";
  }

  if (["MODE", "STAT", "SYST", "ACTV"].includes(name)) return "cv-led-green";

  if (name === "PoE") return poeActive ? "cv-led-poe" : "cv-led-off";

  return "cv-led-off";
}

const portActivityState = new Map();
const sfpActivityState = new Map();

function normalizeMember(config) {
  return String(config.member || "sw1").toLowerCase();
}

function readCounter(hass, entityId) {
  const raw = rawEntityState(hass, entityId);
  if (raw === null) return null;

  const n = Number(String(raw).replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

function readFirstCounter(hass, entityIds) {
  for (const entityId of entityIds) {
    const value = readCounter(hass, entityId);
    if (value !== null) return value;
  }
  return null;
}

function portByteEntity(config, port, direction) {
  const member = normalizeMember(config);
  const mappedPort = mappedPortNumber(config, port);

  // Clean Switch Vision / SNMP2MQTT entity IDs. Always use the mapped entity
  // number so zero-based models such as the Juniper EX3300 line bind their
  // traffic counters to the same port used by link status.
  return `sensor.${member}_port_${mappedPort}_${direction}_bytes`;
}

function sfpByteEntities(config, port, direction) {
  const member = normalizeMember(config);
  const n = Number(port);

  // Prefer clean Switch Vision / SNMP2MQTT entity IDs.
  // Keep older entity IDs as fallbacks for existing dashboards.
  if (n === 1 || n === 2) {
    return [
      `sensor.${member}_sfp_10g_${n}_${direction}_bytes`,
      `sensor.${member}_uplink_${n}_${direction}_bytes`,
      `sensor.cisco_3650_${member}_uplinks_${member}_uplink_${n}_${direction}_bytes`,
      `sensor.cisco_3650_${member}_uplink_${n}_${direction}_bytes`
    ];
  }

  return [
    `sensor.${member}_sfp_10g_${n}_${direction}_bytes`,
    `sensor.cisco_3650_${member}_sfp_10g_${n}_${direction}_bytes`,
    `sensor.cisco_3650_${member}_uplinks_${member}_sfp_10g_${n}_${direction}_bytes`,
    `sensor.cisco_3650_${member}_sfp_10g_${n}_${member}_sfp_10g_${n}_${direction}_bytes`
  ];
}

function activityLevel(delta) {
  if (!Number.isFinite(delta) || delta <= 0) return 0;

  // Deterministic scaling from measured byte delta only.
  // No randomness: identical traffic produces identical LED behaviour.
  const scaled = Math.log10(delta + 1);
  return Math.max(0.15, Math.min(1, scaled / 9));
}

function periodMs(config, level) {
  const slow = Number(config.activity_slow_period_ms ?? 750);
  const medium = Number(config.activity_medium_period_ms ?? 350);
  const fast = Number(config.activity_fast_period_ms ?? 180);
  const clamped = Math.max(0, Math.min(1, level));

  if (clamped <= 0.5) {
    const t = clamped / 0.5;
    return Math.round(slow - ((slow - medium) * t));
  }

  const t = (clamped - 0.5) / 0.5;
  return Math.round(medium - ((medium - fast) * t));
}

function dutyCycle(level) {
  // Higher traffic stays lit for more of each blink period.
  return Math.max(0.18, Math.min(0.72, 0.18 + (level * 0.54)));
}

function configuredActivityHoldMs(config) {
  const seconds = Number(
    config.activity_hold_seconds ??
    config.activity_poll_seconds ??
    config.traffic_poll_seconds ??
    config.traffic_scan_interval ??
    0
  );

  if (Number.isFinite(seconds) && seconds > 0) {
    return Math.max(500, seconds * 1000);
  }

  return null;
}

function defaultActivityHoldMs(config) {
  const windowMs = Number(config.activity_window_ms ?? 6500);
  const bridgeMs = Number(config.activity_bridge_ms ?? 3500);
  const decayMs = Number(config.activity_decay_ms ?? 3000);
  return Math.max(500, windowMs, bridgeMs + decayMs);
}

function activityHoldMs(config) {
  return configuredActivityHoldMs(config) ?? defaultActivityHoldMs(config);
}

function smoothedActivityLevel(config, state, now) {
  if (!state || !state.lastDetectedAt || state.level <= 0) return 0;

  const configuredHoldMs = configuredActivityHoldMs(config);
  const bridgeMs = Math.max(0, Number(config.activity_bridge_ms ?? 3500));
  const decayMs = Math.max(0, Number(config.activity_decay_ms ?? 3000));
  const age = Math.max(0, now - state.lastDetectedAt);

  // When activity_hold_seconds is configured, keep the last detected activity
  // alive across the expected SNMP traffic poll gap. This prevents activity LEDs
  // from stopping before the next slower/chunked traffic poll arrives.
  if (configuredHoldMs !== null && age <= configuredHoldMs) return state.level;

  // Legacy/default smoothing for dashboards without an explicit poll-aware hold.
  if (age <= bridgeMs) return state.level;

  if (decayMs <= 0) return 0;

  const decayAge = age - bridgeMs;
  if (decayAge >= decayMs) return 0;

  const remaining = 1 - (decayAge / decayMs);
  return Math.max(0, state.level * remaining);
}

function updateActivityState(stateMap, key, rx, tx, config) {
  const now = Date.now();

  let state = stateMap.get(key);
  if (!state) {
    state = {
      rx,
      tx,
      activeUntil: 0,
      level: 0,
      startedAt: 0,
      lastDetectedAt: 0
    };
    stateMap.set(key, state);
    return false;
  }

  const rxDelta = rx !== null && state.rx !== null ? Math.max(0, rx - state.rx) : 0;
  const txDelta = tx !== null && state.tx !== null ? Math.max(0, tx - state.tx) : 0;
  const delta = rxDelta + txDelta;

  if (delta > 0) {
    const holdMs = activityHoldMs(config);
    const wasInactive = state.activeUntil <= now || state.level <= 0;

    state.activeUntil = now + holdMs;
    state.level = activityLevel(delta);
    state.lastDetectedAt = now;

    // Only restart the blink phase when a port newly becomes active.
    // Keeping the phase continuous between SNMP samples avoids visible hiccups.
    if (wasInactive || !state.startedAt) state.startedAt = now;
  }

  if (rx !== null) state.rx = rx;
  if (tx !== null) state.tx = tx;

  const displayLevel = smoothedActivityLevel(config, state, now);
  if (state.activeUntil <= now || displayLevel <= 0) return false;

  const period = Math.max(120, periodMs(config, displayLevel));
  const elapsed = Math.max(0, now - state.startedAt);
  const phase = elapsed % period;

  return phase < (period * dutyCycle(displayLevel));
}

function testPortActivity(hass, config, port) {
  if (config.demo) return true;

  const member = normalizeMember(config);
  const mappedPort = mappedPortNumber(config, port);
  const key = `${member}:port:${mappedPort}`;
  const rx = readCounter(hass, portByteEntity(config, port, "rx"));
  const tx = readCounter(hass, portByteEntity(config, port, "tx"));

  return updateActivityState(portActivityState, key, rx, tx, config);
}

function updateRateState(stateMap, key, rx, tx, config) {
  const now = Date.now();
  const staleMs = Number(config.traffic_rate_stale_ms ?? 7000);

  let state = stateMap.get(key);
  if (!state) {
    state = { rx, tx, ts: now, rxBps: null, txBps: null, rateTs: 0 };
    stateMap.set(key, state);
    return { rxBps: null, txBps: null };
  }

  const elapsed = Math.max(0.25, (now - state.ts) / 1000);
  let changed = false;

  if (rx !== null && state.rx !== null) {
    const delta = Math.max(0, rx - state.rx);
    if (delta > 0) {
      state.rxBps = (delta * 8) / elapsed;
      state.rateTs = now;
      changed = true;
    }
  }

  if (tx !== null && state.tx !== null) {
    const delta = Math.max(0, tx - state.tx);
    if (delta > 0) {
      state.txBps = (delta * 8) / elapsed;
      state.rateTs = now;
      changed = true;
    }
  }

  if (rx !== null) state.rx = rx;
  if (tx !== null) state.tx = tx;
  state.ts = now;

  if (!changed && state.rateTs && (now - state.rateTs) > staleMs) {
    state.rxBps = 0;
    state.txBps = 0;
  }

  return { rxBps: state.rxBps, txBps: state.txBps };
}

const portRateState = new Map();
const sfpRateState = new Map();

function portTrafficRates(hass, config, port) {
  if (config.demo) return { rxBps: 1420000000, txBps: 438000000 };

  const member = normalizeMember(config);
  const mappedPort = mappedPortNumber(config, port);
  const key = `${member}:port:${mappedPort}`;
  const rx = readCounter(hass, portByteEntity(config, port, "rx"));
  const tx = readCounter(hass, portByteEntity(config, port, "tx"));

  return updateRateState(portRateState, key, rx, tx, config);
}

function sfpTrafficRates(hass, config, port) {
  if (config.demo) return { rxBps: 6200000000, txBps: 2100000000 };

  const member = normalizeMember(config);
  const key = `${member}:sfp:${port}`;
  const rx = readFirstCounter(hass, sfpByteEntities(config, port, "rx"));
  const tx = readFirstCounter(hass, sfpByteEntities(config, port, "tx"));

  return updateRateState(sfpRateState, key, rx, tx, config);
}

function testSfpActivity(hass, config, port) {
  if (config.demo) return true;

  const member = normalizeMember(config);
  const key = `${member}:sfp:${port}`;
  const rx = readFirstCounter(hass, sfpByteEntities(config, port, "rx"));
  const tx = readFirstCounter(hass, sfpByteEntities(config, port, "tx"));

  return updateActivityState(sfpActivityState, key, rx, tx, config);
}



const STATUS_PANEL_FIELD_DEFS = [
  ["row1_key", "Row 1 label", [24, 55], "start"], ["row1_value", "Row 1 value", [112, 55], "start"],
  ["row2_key", "Row 2 label", [24, 72], "start"], ["row2_value", "Row 2 value", [112, 72], "start"],
  ["row3_key", "Row 3 label", [24, 89], "start"], ["row3_value", "Row 3 value", [112, 89], "start"],
  ["row4_key", "Row 4 label", [24, 106], "start"], ["row4_value", "Row 4 value", [112, 106], "start"],
  ["row5_key", "Row 5 label", [24, 123], "start"], ["row5_value", "Row 5 value", [112, 123], "start"],
  ["row6_key", "Row 6 label", [24, 140], "start"], ["row6_value", "Row 6 value", [112, 140], "start"]
];

const STATUS_PANEL_1_FIELD_DEFAULTS = {
  row1_key: [19, 39], row1_value: [107, 39],
  row2_key: [19, 58], row2_value: [107, 58],
  row3_key: [19, 78], row3_value: [107, 78],
  row4_key: [19, 97], row4_value: [107, 97],
  row5_key: [19, 116], row5_value: [107, 116],
  row6_key: [19, 135], row6_value: [107, 135]
};

function statusPanelFieldReference(key, panelNumber = 1, fallback = [24, 55]) {
  if (panelNumber === 1 && STATUS_PANEL_1_FIELD_DEFAULTS[key]) return STATUS_PANEL_1_FIELD_DEFAULTS[key];
  const found = STATUS_PANEL_FIELD_DEFS.find(([id]) => id === key);
  return found?.[2] || fallback;
}

function statusFieldLabel(key) {
  const found = STATUS_PANEL_FIELD_DEFS.find(([id]) => id === key);
  return found ? found[1] : key;
}

function defaultUiLayout() {
  const fields = {};
  const fields2 = {};
  for (const [key, _label, xy] of STATUS_PANEL_FIELD_DEFS) {
    const panel1xy = statusPanelFieldReference(key, 1, xy);
    fields[key] = [panel1xy[0], panel1xy[1]];
    fields2[key] = [xy[0], xy[1]];
  }
  return {
    logo: {
      show: true,
      file: layout.logo?.file || "sv-logo.png",
      source: "default",
      x: Number(layout.logo?.x ?? 150),
      y: Number(layout.logo?.y ?? 60),
      width: Number(layout.logo?.width ?? 145),
      height: Number(layout.logo?.height ?? 79)
    },
    faceplate: {
      show: true,
      file: "__default__",
      fit: "fill",
      opacity: 1
    },
    calibration_button: { show: true, x: 1888, y: 14, width: 138, height: 34, anchor: "top_right" },
    status_panel: {
      show: true,
      x: 345,
      y: 47,
      width: 305,
      height: 132,
      font_family: "SwitchVisionCustom, Arial, Helvetica, sans-serif",
      font_size: 16,
      title_font_size: 16,
      font_weight: "bold",
      text_color: "#ffffff",
      label_color: "#eef2f4",
      title_color: "#f4f6f7",
      background_color: "transparent",
      border_color: "rgba(245,248,250,.75)",
      border_show: true,
      field_order: {
        switch: [...STATUS_PANEL_ROW_DEFS.switch.defaults],
        port: [...STATUS_PANEL_ROW_DEFS.port.defaults],
        sfp: [...STATUS_PANEL_ROW_DEFS.sfp.defaults]
      },
      hidden_fields: {
        switch: [...STATUS_PANEL_ROW_DEFS.switch.hidden],
        port: [...STATUS_PANEL_ROW_DEFS.port.hidden],
        sfp: [...STATUS_PANEL_ROW_DEFS.sfp.hidden]
      },
      fields
    },
    status_panel_2: {
      show: true,
      x: 1605,
      y: 20,
      width: 278,
      height: 55,
      font_family: "SwitchVisionCustom, Arial, Helvetica, sans-serif",
      font_size: 16,
      title_font_size: 16,
      font_weight: "bold",
      text_color: "#ffffff",
      label_color: "#eef2f4",
      title_color: "#f4f6f7",
      background_color: "transparent",
      border_color: "rgba(245,248,250,.75)",
      border_show: true,
      title_mode: "custom",
      title_field: "model",
      custom_title: "",
      field_order: { switch: ["vendor", "uptime", ...STATUS_PANEL_ROW_DEFS.switch.defaults.filter((field) => !["vendor", "uptime"].includes(field))], port: [...STATUS_PANEL_ROW_DEFS.port.defaults], sfp: [...STATUS_PANEL_ROW_DEFS.sfp.defaults] },
      hidden_fields: {
        switch: STATUS_PANEL_ROW_DEFS.switch.defaults.filter((field) => !["vendor", "uptime"].includes(field)),
        port: [...STATUS_PANEL_ROW_DEFS.port.hidden],
        sfp: [...STATUS_PANEL_ROW_DEFS.sfp.hidden]
      },
      fields: Object.fromEntries(Object.entries(fields2).map(([key, value]) => [key, [...value]]))
    }
  };
}

function ensureCalibrationUi(cal) {
  if (!cal) return cal;
  ensureCalibrationStack(cal);
  ensureCalibrationManagement(cal);
  const defaults = defaultUiLayout();
  cal.ui = cal.ui || {};
  cal.ui.logo = { ...defaults.logo, ...(cal.ui.logo || {}) };
  cal.ui.faceplate = { ...defaults.faceplate, ...(cal.ui.faceplate || {}) };
  cal.ui.calibration_button = { ...defaults.calibration_button, ...(cal.ui.calibration_button || {}) };
  cal.ui.status_panel = { ...defaults.status_panel, ...(cal.ui.status_panel || {}) };
  cal.ui.status_panel.fields = { ...defaults.status_panel.fields, ...(cal.ui.status_panel.fields || {}) };
  delete cal.ui.status_panel.fields.title;
  ensureStatusPanelFieldState(cal.ui.status_panel);
  cal.ui.status_panel_2 = { ...defaults.status_panel_2, ...(cal.ui.status_panel_2 || {}) };
  cal.ui.status_panel_2.fields = { ...defaults.status_panel_2.fields, ...(cal.ui.status_panel_2.fields || {}) };
  delete cal.ui.status_panel_2.fields.title;
  ensureStatusPanelFieldState(cal.ui.status_panel_2);
  return cal;
}

function uiFromCalibration(cal) {
  return ensureCalibrationUi(cal)?.ui || defaultUiLayout();
}

function applyConfigToCalibrationForEdit(cal, config = {}) {
  cal = ensureCalibrationUi(cloneCalibrationData(cal || calibration));
  const ui = uiFromCalibration(cal);

  // Start interactive calibration from the same UI currently being rendered.
  // Saved profile values are the base, then explicit Lovelace/card YAML overrides
  // are folded in once when calibration starts. Reset remains the fresh/default path.
  if (config.logo_show !== undefined) ui.logo.show = config.logo_show !== false;
  if (config.logo_file !== undefined) ui.logo.file = String(config.logo_file || ui.logo.file || "sv-logo.png");
  if (config.logo_x !== undefined) ui.logo.x = Number(config.logo_x);
  if (config.logo_y !== undefined) ui.logo.y = Number(config.logo_y);
  if (config.logo_width !== undefined) ui.logo.width = Number(config.logo_width);
  if (config.logo_height !== undefined) ui.logo.height = Number(config.logo_height);
  if (config.logo_source !== undefined) ui.logo.source = String(config.logo_source || ui.logo.source || "default");

  const faceplateAsset = ui.faceplate;
  if (config.faceplate_show !== undefined) faceplateAsset.show = config.faceplate_show !== false;
  if (config.faceplate_file !== undefined) faceplateAsset.file = String(config.faceplate_file || "__default__");
  if (config.faceplate_fit !== undefined) faceplateAsset.fit = String(config.faceplate_fit || "fill");
  if (config.faceplate_opacity !== undefined) faceplateAsset.opacity = Number(config.faceplate_opacity);


  const panel = ui.status_panel;
  if (config.show_status_panel !== undefined) panel.show = config.show_status_panel !== false;
  if (config.status_panel_x !== undefined) panel.x = Number(config.status_panel_x);
  if (config.status_panel_y !== undefined) panel.y = Number(config.status_panel_y);
  if (config.status_panel_width !== undefined) panel.width = Number(config.status_panel_width);
  if (config.status_panel_height !== undefined) panel.height = Number(config.status_panel_height);
  if (config.status_panel_font_family !== undefined) panel.font_family = String(config.status_panel_font_family);
  if (config.status_panel_font_size !== undefined) panel.font_size = Number(config.status_panel_font_size);
  if (config.status_panel_title_font_size !== undefined) panel.title_font_size = Number(config.status_panel_title_font_size);
  if (config.status_panel_font_weight !== undefined) panel.font_weight = String(config.status_panel_font_weight);
  if (config.status_panel_background_color !== undefined) panel.background_color = String(config.status_panel_background_color);
  if (config.status_panel_border_color !== undefined) panel.border_color = String(config.status_panel_border_color);
  if (config.status_panel_text_color !== undefined) panel.text_color = String(config.status_panel_text_color);
  if (config.status_panel_label_color !== undefined) panel.label_color = String(config.status_panel_label_color);
  if (config.status_panel_title_color !== undefined) panel.title_color = String(config.status_panel_title_color);

  ensureStatusPanelFieldState(panel);
  for (const type of Object.keys(STATUS_PANEL_ROW_DEFS)) {
    const scopedKey = `status_panel_${type}_fields`;
    const hiddenKey = `status_panel_${type}_hidden_fields`;
    let fields = fieldListFromValue(config[scopedKey]);
    if (!fields && config.status_panel_fields && typeof config.status_panel_fields === "object" && !Array.isArray(config.status_panel_fields)) {
      fields = fieldListFromValue(config.status_panel_fields[type]);
    }
    if (!fields && type === "switch") fields = fieldListFromValue(config.status_panel_fields);
    if (fields) panel.field_order[type] = normaliseStatusPanelFieldOrder(fields, type);

    const hidden = fieldListFromValue(config[hiddenKey]) || (type === "switch" ? fieldListFromValue(config.status_panel_hidden_fields) : null);
    if (hidden) {
      const defs = STATUS_PANEL_ROW_DEFS[type].defaults;
      panel.hidden_fields[type] = hidden.filter((field, idx, arr) => defs.includes(field) && arr.indexOf(field) === idx);
    }
  }

  const stack = configuredStackProfile(config, cal);
  cal.stack = stack;

  const switchIp = explicitConfigValue(config, ["switch_ip", "management_ip", "mgmt_ip", "host_ip", "snmp_host"]) ||
    managementIpFromCalibration(cal) ||
    "";
  ensureCalibrationManagement(cal);
  cal.management.switch_ip = String(switchIp || "").trim();

  return ensureCalibrationUi(cal);
}

function statusPanelUi(config, cal, panelNumber = 1) {
  const suffix = panelNumber === 2 ? "_2" : "";
  const ui = uiFromCalibration(cal)[panelNumber === 2 ? "status_panel_2" : "status_panel"];
  return {
    ...ui,
    show: config[`show_status_panel${suffix}`] !== false && ui.show !== false,
    x: Number(config[`status_panel${suffix}_x`] ?? ui.x),
    y: Number(config[`status_panel${suffix}_y`] ?? ui.y),
    width: Number(config[`status_panel${suffix}_width`] ?? ui.width),
    height: Number(config[`status_panel${suffix}_height`] ?? ui.height),
    font_family: String(config[`status_panel${suffix}_font_family`] ?? ui.font_family),
    font_size: Number(config[`status_panel${suffix}_font_size`] ?? ui.font_size),
    title_font_size: Number(config[`status_panel${suffix}_title_font_size`] ?? ui.title_font_size),
    font_weight: String(config[`status_panel${suffix}_font_weight`] ?? ui.font_weight ?? "normal"),
    background_color: String(config[`status_panel${suffix}_background_color`] ?? ui.background_color),
    border_color: String(
      panelNumber === 2 && calibrationControlsEnabled(config)
        ? ui.border_color
        : (config[`status_panel${suffix}_border_color`] ?? ui.border_color)
    ),
    border_show: panelNumber === 2 && calibrationControlsEnabled(config)
      ? ui.border_show !== false
      : (config[`status_panel${suffix}_border_show`] === undefined
        ? ui.border_show !== false
        : config[`status_panel${suffix}_border_show`] !== false),
    text_color: String(config[`status_panel${suffix}_text_color`] ?? ui.text_color),
    label_color: String(config[`status_panel${suffix}_label_color`] ?? ui.label_color),
    title_color: String(config[`status_panel${suffix}_title_color`] ?? ui.title_color),
    title_mode: String(config[`status_panel${suffix}_title_mode`] ?? ui.title_mode ?? "default"),
    title_field: String(config[`status_panel${suffix}_title_field`] ?? ui.title_field ?? "model"),
    custom_title: String(config[`status_panel${suffix}_custom_title`] ?? (ui.custom_title || (panelNumber === 2 ? (config.title || config.member || "Switch") : "")))
  };
}

function statusFieldPosition(panel, key, fallback) {
  const xy = panel.fields?.[key] || fallback;
  return [panel.x + Number(xy[0]), panel.y + Number(xy[1])];
}

function statusFieldDisplayPosition(panel, key, fallback, panelNumber = 1) {
  const reference = statusPanelFieldReference(key, panelNumber, fallback);
  const saved = panel.fields?.[key] || reference;
  const rowMatch = /^row(\d+)_(key|value)$/.exec(String(key));
  if (!rowMatch) return statusFieldPosition(panel, key, fallback);

  const rowIndex = Math.max(0, Number(rowMatch[1]) - 1);
  const kind = rowMatch[2];
  const fontSize = Math.max(8, Number(panel.font_size) || 16);
  const rowSpacing = Math.max(17, fontSize + 2);
  const horizontalShift = panelNumber === 2 ? 15 : 5;
  const panelLeft = Number(panel.x) + 4;
  const panelRight = Number(panel.x) + Number(panel.width) - 4;

  const defaultLabelX = Math.max(panelLeft + 4, Math.min(panelRight - 96, Number(panel.x) + Number(fallback[0]) - horizontalShift));
  // Move the shared value column another 10 px left while preserving
  // independent per-field nudging.
  const defaultValueX = Math.min(panelRight - 24, defaultLabelX + 33);
  const defaultX = kind === "key" ? defaultLabelX : defaultValueX;
  const x = defaultX + (Number(saved[0]) - Number(reference[0]));

  const compactBaseline = Number(panel.y) + 4 + fontSize + (rowIndex * rowSpacing);
  const y = compactBaseline + (Number(saved[1]) - Number(reference[1]));
  return [x, y];
}


function estimatedSvgTextWidth(value, fontSize) {
  const text = String(value ?? "");
  const size = Number(fontSize) || 14;
  let units = 0;
  for (const ch of text) {
    if (ch === " " || ch === "." || ch === ":" || ch === "/" || ch === "-") units += 0.32;
    else if (ch === "i" || ch === "l" || ch === "I" || ch === "1" || ch === "|") units += 0.34;
    else if (ch === "W" || ch === "M" || ch === "@" || ch === "#") units += 0.92;
    else if (/[A-Z]/.test(ch)) units += 0.68;
    else units += 0.56;
  }
  return units * size;
}

function truncateSvgText(value, fontSize, maxWidth) {
  const raw = usableValue(value) || "—";
  const limit = Number(maxWidth);
  if (!Number.isFinite(limit) || limit <= 0) return raw;
  if (estimatedSvgTextWidth(raw, fontSize) <= limit) return raw;

  const ellipsis = "…";
  let out = raw;
  while (out.length > 1 && estimatedSvgTextWidth(`${out}${ellipsis}`, fontSize) > limit) {
    out = out.slice(0, -1);
  }
  return `${out.trimEnd()}${ellipsis}`;
}

function addSvgTitle(el, value) {
  const raw = usableValue(value);
  if (!el || !raw) return el;
  const title = e("title");
  title.textContent = raw;
  el.appendChild(title);
  return el;
}

function stylePanelText(el, panel, kind = "value") {
  const fill = kind === "title" ? panel.title_color : (kind === "key" ? panel.label_color : panel.text_color);
  const fontSize = kind === "title" ? panel.title_font_size : panel.font_size;
  return applySvgStyle(el, {
    fontFamily: panel.font_family,
    fontSize: `${fontSize}px`,
    fontWeight: panel.font_weight || "normal",
    fill
  });
}

function drawStatusPanel(svg, hass, config, cal = calibration, panelNumber = 1) {
  const panel = statusPanelUi(config, cal, panelNumber);
  if (!panel.show) return;

  const x = Number(panel.x);
  const y = Number(panel.y);
  const w = Number(panel.width);
  const h = Number(panel.height);
  // Status Box 2 is a permanent switch-summary panel. It must never inherit
  // selected port or SFP details from Status Box 1. Its calibrated dimensions
  // are authoritative: showing or hiding fields changes only the content and
  // never resizes the box at runtime.
  const selected = panelNumber === 2 ? null : selectedInterface(config);

  const panelRect = rect(svg, x, y, w, h, 0, "cv-status-panel-bg");
  const panelStroke = panel.border_show ? String(panel.border_color || "rgba(245,248,250,.75)") : "none";
  const panelStrokeWidth = panel.border_show ? "1.5" : "0";
  // Keep the background and the user-controlled border as separate SVG elements.
  // This prevents the calibration selection overlay and the shared background CSS
  // class from masking Status Box 2 border enable/colour changes.
  const rawPanelBackground = String(panel.background_color || "transparent");
  const panelBackground = rawPanelBackground;
  panelRect.setAttribute("fill", panelBackground);
  panelRect.setAttribute("stroke", "none");
  panelRect.setAttribute("stroke-width", "0");
  applySvgStyle(panelRect, {
    fill: panelBackground,
    stroke: "none",
    strokeWidth: "0"
  });
  if (panel.border_show) {
    const borderRect = rect(svg, x, y, w, h, 0, "cv-status-panel-border");
    borderRect.setAttribute("fill", "none");
    borderRect.setAttribute("stroke", panelStroke);
    borderRect.setAttribute("stroke-width", panelStrokeWidth);
    borderRect.setAttribute("vector-effect", "non-scaling-stroke");
    applySvgStyle(borderRect, {
      fill: "none",
      stroke: panelStroke,
      strokeWidth: panelStrokeWidth
    });
  }

  // Both status boxes are intentionally title-free. Legacy title settings remain
  // readable in saved calibration profiles for compatibility, but are ignored at
  // runtime so every enabled status row can use the freed vertical space.

  let rows;
  if (selected?.type === "port") {
    const details = selectedPortDetails(hass, config, selected.id);
    const rates = portTrafficRates(hass, config, selected.id);
    const values = {
      vlan: details.vlan,
      desc: details.description,
      link: details.link,
      rx: formatBps(rates.rxBps),
      tx: formatBps(rates.txBps)
    };
    let fields = statusPanelFieldSelection(config, "port", cal, panelNumber);
    // Juniper trunk/access state is inferred from VLAN membership. Present the
    // useful VLAN list directly and suppress the separate mode row. Cisco keeps
    // its existing explicit VLAN/TRUNK presentation unchanged.
    if (details.isJuniper) fields = fields.filter((field) => field !== "mode");
    const labels = { ...STATUS_PANEL_ROW_DEFS.port.labels, vlan: details.vlanLabel || "VLAN" };
    rows = makeRows(values, fields, labels);
  } else if (selected?.type === "sfp") {
    const details = selectedSfpDetails(hass, config, selected.id);
    const rates = sfpTrafficRates(hass, config, selected.id);
    const values = {
      vlan: details.vlan,
      desc: details.description,
      link: details.link,
      rx: formatBps(rates.rxBps),
      tx: formatBps(rates.txBps)
    };
    const fields = statusPanelFieldSelection(config, "sfp", cal, panelNumber);
    rows = makeRows(values, fields, STATUS_PANEL_ROW_DEFS.sfp.labels);
  } else {
    rows = switchSummaryDetails(hass, config, cal, panelNumber).rows;
  }

  const visibleRows = Math.min(13, rows.length);
  const panelLeft = x + 4;
  const panelRight = x + w - 4;
  const panelTop = y + 4;
  const panelBottom = y + h - 4;
  const rowFontSize = Math.max(8, Number(panel.font_size) || 16);

  for (let i = 0; i < visibleRows; i++) {
    const row = rows[i] || ["", ""];
    const key = `row${i + 1}_key`;
    const val = `row${i + 1}_value`;
    // Resolve each field target through the same coordinate transform used by
    // the calibration overlay. This keeps the compact row grid as the default
    // while allowing every label and value target to be nudged independently.
    const keyDef = STATUS_PANEL_FIELD_DEFS.find(([id]) => id === key);
    const valDef = STATUS_PANEL_FIELD_DEFS.find(([id]) => id === val);
    const [kx, ky] = statusFieldDisplayPosition(panel, key, keyDef?.[2] || [24, 55], panelNumber);
    const [vx, vy] = statusFieldDisplayPosition(panel, val, valDef?.[2] || [281, 55], panelNumber);

    // Safety rule: never render a status row outside the calibrated status box.
    // This prevents identity or telemetry fields from overlapping ports or other faceplate elements.
    const rowInsidePanel =
      Number.isFinite(kx) && Number.isFinite(ky) && Number.isFinite(vx) && Number.isFinite(vy) &&
      kx >= panelLeft && kx <= panelRight &&
      vx >= panelLeft && vx <= panelRight &&
      (ky - (rowFontSize * 0.7)) >= panelTop && (ky + (rowFontSize * 0.35)) <= panelBottom &&
      (vy - (rowFontSize * 0.7)) >= panelTop && (vy + (rowFontSize * 0.35)) <= panelBottom;
    if (!rowInsidePanel) continue;

    const labelMaxWidth = Math.max(40, vx - kx - 10);
    const fullLabel = usableValue(row[0]) || "";
    const displayLabel = truncateSvgText(fullLabel, panel.font_size, labelMaxWidth);
    const labelEl = stylePanelText(text(svg, kx, ky, displayLabel, "cv-panel-key", "start"), panel, "key");
    if (displayLabel !== fullLabel) addSvgTitle(labelEl, fullLabel);

    // All values begin at the same fixed X coordinate and are left aligned. This
    // makes short and long values visually line up instead of appearing indented
    // according to their text width. Long values are truncated at the box edge.
    const valueMaxWidth = Math.max(18, panelRight - vx);
    const fullValue = usableValue(row[1]) || "—";
    const displayValue = truncateSvgText(fullValue, panel.font_size, valueMaxWidth);
    const valueEl = stylePanelText(text(svg, vx, vy, displayValue, "cv-panel-value", "start"), panel, "value");
    if (displayValue !== fullValue) addSvgTitle(valueEl, fullValue);
  }
}

function selectedInterface(config) {
  const selected = config.selected_interface || null;
  if (selected && selected.type) return selected;

  if (config.selected_port) {
    return { type: "port", id: Number(config.selected_port) };
  }

  return null;
}

function isSelected(config, type, id) {
  const selected = selectedInterface(config);
  return selected?.type === type && Number(selected.id) === Number(id);
}

function sfpPortNumber(name) {
  const nums = String(name).match(/\d+/g) || [];
  return Number(nums[nums.length - 1] || 0);
}


function calibrationEnabled(config) {
  return config.calibration_mode === true || config.calibration === true;
}

function calibrationTarget(config) {
  const target = config.calibration_target ?? config.calibration_item ?? "all";

  if (target === null || target === undefined || target === "") return "all";
  if (typeof target === "number") return { type: "port", id: Number(target) };

  if (typeof target === "object") {
    const type = String(target.type || "").toLowerCase();
    const id = target.id ?? target.name ?? target.port ?? target.led;
    return { type, id: String(id) };
  }

  const raw = String(target).trim();
  const low = raw.toLowerCase();
  if (["all", "ports", "sfp", "sfps", "uplinks", "status", "status_leds", "leds", "logo", "status_box", "status_fields"].includes(low)) return low;
  if (low.startsWith("status_field:")) return { type: "status_field", id: raw.split(":").slice(1).join(":") };

  const match = low.match(/^(port|p|sfp|status|led)[:\-_ ]?(.+)$/);
  if (match) {
    const type = match[1] === "p" ? "port" : (match[1] === "led" ? "status" : match[1]);
    return { type, id: match[2].toUpperCase() };
  }

  if (/^\d+$/.test(low)) return { type: "port", id: Number(low) };

  return { type: "status", id: raw.toUpperCase() };
}

function calibrationRawTarget(config) {
  return String(config?.calibration_target ?? config?.calibration_item ?? "all").trim().toLowerCase();
}


function parseCalibrationPortSelection(value, cal = null) {
  const raw = Array.isArray(value) ? value.join(",") : String(value || "");
  const values = new Set();
  const invalid = [];

  for (const tokenValue of raw.split(",")) {
    const token = String(tokenValue || "").trim();
    if (!token) continue;

    const range = token.match(/^(\d+)\s*-\s*(\d+)$/);
    if (range) {
      const a = Number(range[1]);
      const b = Number(range[2]);
      const start = Math.min(a, b);
      const end = Math.max(a, b);
      if (!Number.isFinite(start) || !Number.isFinite(end) || start < 1) {
        invalid.push(token);
        continue;
      }
      for (let n = start; n <= end; n += 1) values.add(String(n));
      continue;
    }

    if (/^\d+$/.test(token) && Number(token) >= 1) {
      values.add(String(Number(token)));
      continue;
    }

    invalid.push(token);
  }

  let keys = [...values].sort((a, b) => Number(a) - Number(b));
  const missing = [];
  if (cal?.ports) {
    keys = keys.filter((key) => {
      const exists = Boolean(cal.ports?.[key]);
      if (!exists) missing.push(key);
      return exists;
    });
  }

  return { keys, invalid, missing, normalised: keys.join(",") };
}

function calibrationSelectedPortKeys(config, cal = null) {
  return parseCalibrationPortSelection(config?.calibration_port_selection, cal).keys;
}

function calibrationPortIsSelected(config, portNumber, cal = null) {
  return calibrationSelectedPortKeys(config, cal).includes(String(Number(portNumber)));
}

function calibrationMatches(config, type, id, cal = null) {
  const target = normalCalibrationTarget(config);
  const targetType = String(target?.type || "").toLowerCase();
  const itemType = String(type || "").toLowerCase();
  const itemId = String(id || "").toUpperCase();

  if (targetType === "ports" && itemType === "port") {
    if (target.selection === "custom" || target.id === "custom") return calibrationPortIsSelected(config, id, cal);
    if (target.parity === "odd" || target.id === "odd") return Number(id) % 2 === 1;
    if (target.parity === "even" || target.id === "even") return Number(id) % 2 === 0;
    return true;
  }
  if (targetType === "sfps" && itemType === "sfp") return true;
  if (targetType === "status_leds" && itemType === "status") return true;
  if (!target || typeof target !== "object") return false;

  return targetType === itemType && String(target.id || "").toUpperCase() === itemId;
}

function calibrationPortPartMatches(config, portNumber, part, cal = null) {
  const partName = String(part || "").toLowerCase();
  const target = normalCalibrationTarget(config);
  const targetType = String(target?.type || "").toLowerCase();
  const targetPart = String(target?.part || config?.calibration_part || "center").toLowerCase();

  if (targetType === "ports") {
    if (targetPart !== partName) return false;
    if (target.selection === "custom" || target.id === "custom") return calibrationPortIsSelected(config, portNumber, cal);
    if (target.parity === "odd" || target.id === "odd") return Number(portNumber) % 2 === 1;
    if (target.parity === "even" || target.id === "even") return Number(portNumber) % 2 === 0;
    return true;
  }
  if (targetType !== "port") return false;
  return String(target.id) === String(portNumber) && targetPart === partName;
}

function calibrationState(config) {
  const period = Math.max(250, Number(config.calibration_blink_ms || 700));
  return Math.floor(Date.now() / period) % 2 === 0;
}

function calibrationInfoText(config) {
  const target = calibrationTarget(config);
  if (target === "all") return "ALL";
  if (typeof target === "string") return target.toUpperCase();
  const type = String(target.type || "").toUpperCase();
  return `${type} ${String(target.id || "")}`.trim();
}

function visualHitboxSize(type, hitbox) {
  const [baseW, baseH] = hitbox || [0, 0];
  const w = type === "port" ? Number(baseW) + 18 : Number(baseW) + 12;
  const h = type === "port" ? Number(baseH) + 4 : Number(baseH) + 16;
  return [Math.max(8, w), Math.max(8, h)];
}

function drawCalibrationOverlay(svg, { config, calibration }) {
  if (!calibrationEnabled(config)) return;

  const blinkOn = config.calibration_blink === false ? true : calibrationState(config);
  const showHitboxes = config.calibration_show_hitboxes !== false;
  const showLabels = config.calibration_show_labels !== false;
  const showLedRings = config.calibration_show_led_rings !== false;

  text(svg, 24, 28, `CALIBRATION · ${calibrationInfoText(config)}`, "cv-calibration-title", "start");

  const drawRing = (x, y, r, active) => {
    const ring = e("circle");
    ring.setAttribute("class", active && blinkOn ? "cv-calibration-ring cv-calibration-active" : "cv-calibration-ring");
    ring.setAttribute("cx", x);
    ring.setAttribute("cy", y);
    ring.setAttribute("r", r);
    svg.appendChild(ring);
  };

  const drawHitbox = (type, id, center, hitbox, label) => {
    const [cx, cy] = center;
    const [w, h] = visualHitboxSize(type, hitbox);
    const active = type === "port" ? calibrationPortPartMatches(config, id, "center", calibration) : calibrationMatches(config, type, id, calibration);

    if (showHitboxes) {
      const r = e("rect");
      r.setAttribute("class", active && blinkOn ? "cv-calibration-hitbox cv-calibration-active" : "cv-calibration-hitbox");
      r.setAttribute("x", cx - (w / 2));
      r.setAttribute("y", cy - (h / 2));
      r.setAttribute("width", w);
      r.setAttribute("height", h);
      r.setAttribute("rx", 4);
      r.setAttribute("ry", 4);
      svg.appendChild(r);
    }

    if (showLabels) {
      text(svg, cx, cy + 4, label, active && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
    }
  };

  for (const [num, port] of Object.entries(calibration.ports || {})) {
    const n = Number(num);
    drawHitbox("port", n, port.center, port.hitbox, `P${num}`);

    if (showLedRings) {
      const active = calibrationMatches(config, "port", n, calibration);
      const activeLeft = active || calibrationPortPartMatches(config, n, "led_left", calibration);
      const activeRight = active || calibrationPortPartMatches(config, n, "led_right", calibration);
      if (port.led_left) drawRing(port.led_left[0], port.led_left[1], 7.5, activeLeft);
      if (port.led_right) drawRing(port.led_right[0], port.led_right[1], 7.5, activeRight);
    }
  }

  for (const [name, sfp] of Object.entries(calibration.sfp || {})) {
    const sfpPort = sfpPortNumber(name);
    drawHitbox("sfp", sfpPort, sfp.center, sfp.hitbox, name);

    if (showLedRings) {
      const [x, y] = sfp.center;
      const active = calibrationMatches(config, "sfp", sfpPort, calibration);
      drawRing(x - 24, y - 31, 8, active);
      drawRing(x + 24, y - 31, 8, active);
    }
  }

  for (const [name, xy] of Object.entries(calibration.status_leds || {})) {
    if (String(name).toUpperCase() === "MODE") continue;
    const [x, y] = xy;
    const active = calibrationMatches(config, "status", name, calibration);
    if (showLedRings) drawRing(x, y, 10, active);
    if (showLabels) text(svg, x, y - 16, name, active && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
  }


  const ui = uiFromCalibration(calibration);
  const logoUi = ui.logo;
  const panel = statusPanelUi(config, calibration);
  const raw = calibrationRawTarget(config);
  const target = normalCalibrationTarget(config);

  if (logoUi?.show !== false) {
    const active = raw === "logo";
    if (showHitboxes) {
      const r = rect(svg, logoUi.x, logoUi.y, logoUi.width, logoUi.height, 4, active && blinkOn ? "cv-calibration-hitbox cv-calibration-active" : "cv-calibration-hitbox");
    }
    if (showLabels) text(svg, logoUi.x + (logoUi.width / 2), logoUi.y - 12, "LOGO", active && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
  }

  if (panel?.show !== false) {
    const boxActive = raw === "status_box" || raw === "status_box_1";
    // Draw the calibration outline outside the real box border so users can see
    // border visibility and colour changes while the box remains selected.
    if (showHitboxes) rect(svg, panel.x - 5, panel.y - 5, panel.width + 10, panel.height + 10, 4, boxActive && blinkOn ? "cv-calibration-hitbox cv-calibration-active" : "cv-calibration-hitbox");
    if (showLabels) text(svg, panel.x + (panel.width / 2), panel.y - 12, "STATUS BOX", boxActive && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");

    const allFieldsActive = raw === "status_fields";
    for (const [key, label, fallback] of STATUS_PANEL_FIELD_DEFS) {
      const [fx, fy] = statusFieldDisplayPosition(panel, key, fallback, 1);
      const active = allFieldsActive || (target?.type === "status_field" && String(target.id) === key);
      if (showLedRings) drawRing(fx, fy, 7, active);
      if (showLabels && active) text(svg, fx, fy - 12, label, blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
    }
  }

  const buttonUi = ui.calibration_button;
  if (buttonUi?.show !== false) {
    const active = raw === "calibration_button";
    if (showHitboxes) rect(svg, buttonUi.x, buttonUi.y, buttonUi.width, buttonUi.height, 4, active && blinkOn ? "cv-calibration-hitbox cv-calibration-active" : "cv-calibration-hitbox");
    if (showLabels) text(svg, buttonUi.x + (buttonUi.width / 2), buttonUi.y - 8, "CALIBRATION BUTTON", active && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
  }

  const panel2 = statusPanelUi(config, calibration, 2);
  if (panel2?.show !== false) {
    const boxActive = raw === "status_box_2";
    // Keep the calibration outline outside Status Box 2. Previously it sat on top
    // of the user border, making border re-enable and colour changes look broken.
    if (showHitboxes) rect(svg, panel2.x - 5, panel2.y - 5, panel2.width + 10, panel2.height + 10, 4, boxActive && blinkOn ? "cv-calibration-hitbox cv-calibration-active" : "cv-calibration-hitbox");
    if (showLabels) text(svg, panel2.x + (panel2.width / 2), panel2.y - 12, "STATUS BOX 2", boxActive && blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");

    const allFieldsActive = raw === "status_fields_2";
    for (const [key, label, fallback] of STATUS_PANEL_FIELD_DEFS) {
      const [fx, fy] = statusFieldDisplayPosition(panel2, key, fallback, 2);
      const active = allFieldsActive || (target?.type === "status_field_2" && String(target.id) === key);
      if (showLedRings) drawRing(fx, fy, 7, active);
      if (showLabels && active) text(svg, fx, fy - 12, label, blinkOn ? "cv-calibration-label cv-calibration-active-text" : "cv-calibration-label");
    }
  }

}


function drawPanel(svg, { hass, config, calibration, layout }) {
  if (config.show_labels) {
    const ui = uiFromCalibration(calibration);
    const logoUi = ui.logo || layout.logo;
    if (logoUi?.show !== false && logoUi?.file) {
      image(
        svg,
        logoUi.x,
        logoUi.y,
        logoUi.width,
        logoUi.height,
        assetUrl("logos", logoUi.file, config.version || "dev"),
        "cv-logo-img"
      );
    } else if (logoUi?.show !== false && layout.logo) {
      text(svg, layout.logo.fallback_x, layout.logo.fallback_y, layout.logo.fallback_text, "cv-logo-word", "start");
    }

  }

  if (config.show_status_leds) {
    const poeActive = switchPoeActive(hass, config);
    // A generated card's explicit member number is itself confirmation that the
    // card belongs to a discovered stack. Keep calibration-driven stacks working
    // as before, while ensuring every generated member (including member 1) gets
    // the same blue STACK LED.
    const explicitStackMember = Number(config?.stack_member_number || 0);
    const stackActive = configuredStackProfile(config, calibration).enabled === true
      || (explicitStackMember >= 1 && explicitStackMember <= 16);

    for (const [name, xy] of Object.entries(calibration.status_leds)) {
      if (name === "MODE" && config.show_status_panel !== false) continue;

      const [x, y] = xy;
      const r = name === "MODE" ? layout.status.mode_radius : layout.status.radius;

      circle(svg, x, y, r, statusLedClass(name, config.demo, { poeActive, stackActive }));

      if (config.show_labels) {
        const label = layout.status.labels[name];
        if (label) {
          text(svg, x + label.dx, y + label.dy, name, "cv-status-label", label.anchor);
        }
      }
    }
  }

  for (const [num, port] of Object.entries(calibration.ports)) {
    const n = Number(num);
    const up = portIsUp(hass, config, n);
    const speed = portSpeed(hass, config, n);

    if (config.show_port_leds) {
      circle(svg, port.led_left[0], port.led_left[1], layout.ports.r, speedClass(speed, up));

      circle(svg, port.led_right[0], port.led_right[1], layout.ports.r, activityClass(config, up && testPortActivity(hass, config, n)));
    }

    if (config.show_numbers) {
      const [nx, ny] = port.number;
      const numberY = ny + (n % 2 === 1 ? layout.ports.odd : layout.ports.even);
      const numberCalActive = calibrationEnabled(config) && calibrationPortPartMatches(config, n, "number", calibration) && (config.calibration_blink === false || calibrationState(config));
      const cls = numberCalActive ? "cv-port-num cv-calibration-active-text" : (isSelected(config, "port", n) ? "cv-port-num cv-port-num-selected" : "cv-port-num");

      // Apply the optional vendor/model-specific label offset when drawing
      // the white port-number overlay. This keeps calibration slots shared
      // while allowing zero-based faceplates such as Juniper EX3300.
      const visiblePort = displayedPortNumber(config, n);
      text(svg, nx, numberY, String(visiblePort), cls);
    }
  }

  for (const [name, sfp] of Object.entries(calibration.sfp)) {
    const [x, y] = sfp.center;
    const label = layout.sfp.labels[name];

    const sfpNumbers = String(name).match(/\d+/g) || [];
    const sfpPort = Number(sfpNumbers[sfpNumbers.length - 1] || 0);

    if (config.show_labels && label) {
      const cls = isSelected(config, "sfp", sfpPort) ? "cv-sfp-label cv-sfp-label-selected" : "cv-sfp-label";
      text(svg, label.x, label.y, label.text, cls);
    }

    const up = sfpIsUp(hass, config, sfpPort);
    circle(svg, x - 24, y - 31, layout.sfp.r, speedClass("10000", up));
    circle(svg, x + 24, y - 31, layout.sfp.r, activityClass(config, up && testSfpActivity(hass, config, sfpPort)));
  }

  // Draw both status boxes last so their expanded backgrounds, borders and text
  // remain above port numbers, LEDs, vents and uplink decorations. This is
  // especially important for Status Box 2 when it grows beyond its title-only
  // height after rows are enabled.
  drawStatusPanel(svg, hass, config, calibration, 1);
  drawStatusPanel(svg, hass, config, calibration, 2);
}


function cloneCalibrationData(source = calibration) {
  return ensureCalibrationUi(JSON.parse(JSON.stringify(source)));
}

function calibrationControlsEnabled(config) {
  return calibrationEnabled(config) && config.calibration_controls === true;
}


async function copyTextToClipboard(text) {
  const value = String(text ?? "");

  if (navigator?.clipboard?.writeText && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch (err) {
      // Continue to the legacy fallback below.
    }
  }

  const textarea = document.createElement("textarea");
  textarea.value = value;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  textarea.style.top = "0";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);

  const selection = document.getSelection();
  const previousRange = selection && selection.rangeCount ? selection.getRangeAt(0) : null;

  textarea.focus();
  textarea.select();
  textarea.setSelectionRange(0, textarea.value.length);

  let copied = false;
  try {
    copied = Boolean(document.execCommand("copy"));
  } catch (err) {
    copied = false;
  }

  textarea.remove();

  if (selection) {
    selection.removeAllRanges();
    if (previousRange) selection.addRange(previousRange);
  }

  return copied;
}


function safeDownloadName(value, fallback = "switch-vision-profile") {
  const cleaned = String(value || "")
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[-_.]+|[-_.]+$/g, "");
  return cleaned || fallback;
}

function downloadJsonFile(filename, payload) {
  const blob = new Blob([JSON.stringify(payload, null, 2) + "\n"], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function calibrationCoordinateValid(value) {
  return Array.isArray(value) && value.length === 2 && value.every((item) => Number.isFinite(Number(item)));
}

function validateImportedCalibration(raw, currentCal = null) {
  const errors = [];
  const warnings = [];
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { valid: false, errors: ["The imported file must contain one JSON object."], warnings, calibration: null, summary: null };
  }

  const schemaVersion = Number(raw.schema_version ?? 0);
  if (schemaVersion && schemaVersion !== 1) errors.push(`Unsupported schema_version ${schemaVersion}; this release supports schema version 1.`);
  if (!schemaVersion) warnings.push("Legacy profile: schema_version is missing and will be added when saved or exported.");
  if (raw.schema && raw.schema !== "switch-vision-interactive-calibration-v1") warnings.push(`Unexpected schema label: ${raw.schema}`);

  for (const field of ["ports", "sfp", "status_leds"]) {
    if (!raw[field] || typeof raw[field] !== "object" || Array.isArray(raw[field])) errors.push(`Missing or invalid ${field} object.`);
  }
  if (!raw.image || typeof raw.image !== "object" || Array.isArray(raw.image)) errors.push("Missing or invalid image object.");

  const width = Number(raw.image?.width);
  const height = Number(raw.image?.height);
  if (!Number.isFinite(width) || width <= 0 || !Number.isFinite(height) || height <= 0) errors.push("Profile image width and height must be positive numbers.");

  const validateEntries = (entries, type) => {
    for (const [key, item] of Object.entries(entries || {})) {
      if (!item || typeof item !== "object") { errors.push(`${type} ${key} is not an object.`); continue; }
      if (type === "Port") {
        for (const part of ["center", "number", "led_left", "led_right", "hitbox"]) {
          if (!calibrationCoordinateValid(item[part])) errors.push(`Port ${key} has an invalid ${part} coordinate.`);
        }
      } else if (!calibrationCoordinateValid(item.center)) {
        errors.push(`${type} ${key} has an invalid center coordinate.`);
      }
    }
  };
  validateEntries(raw.ports, "Port");
  validateEntries(raw.sfp, "SFP");
  for (const [key, point] of Object.entries(raw.status_leds || {})) {
    if (!calibrationCoordinateValid(point)) errors.push(`Status LED ${key} has an invalid coordinate.`);
  }

  const currentWidth = Number(currentCal?.image?.width);
  const currentHeight = Number(currentCal?.image?.height);
  if (Number.isFinite(currentWidth) && Number.isFinite(currentHeight) && (width !== currentWidth || height !== currentHeight)) {
    warnings.push(`Canvas mismatch: imported profile is ${width} × ${height}; current faceplate profile is ${currentWidth} × ${currentHeight}.`);
  }

  const portCount = Object.keys(raw.ports || {}).length;
  const sfpCount = Object.keys(raw.sfp || {}).length;
  const statusCount = Object.keys(raw.status_leds || {}).filter((key) => String(key).toUpperCase() !== "MODE").length;
  if (!portCount) errors.push("The profile contains no RJ45 port positions.");

  let calibration = null;
  if (!errors.length) {
    calibration = cloneCalibrationData({
      ...raw,
      schema_version: 1,
      schema: "switch-vision-interactive-calibration-v1"
    });
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    calibration,
    summary: {
      schemaVersion: schemaVersion || "legacy",
      model: String(raw.model || "unspecified"),
      profileName: String(raw.profile_name || ""),
      imageFile: String(raw.image?.file || "unspecified"),
      width,
      height,
      portCount,
      sfpCount,
      statusCount
    }
  };
}

function htmlEscape(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function sfpEntryForTarget(cal, id) {
  const wanted = Number(id);
  for (const [name, item] of Object.entries(cal.sfp || {})) {
    if (sfpPortNumber(name) === wanted) return { key: name, item };
  }
  return null;
}

function statusKeyForTarget(cal, id) {
  const wanted = String(id || "").toUpperCase();
  for (const key of Object.keys(cal.status_leds || {})) {
    if (String(key).toUpperCase() === wanted) return key;
  }
  return null;
}

function normalCalibrationTarget(config) {
  // v0.5.11: handle exact quick-select group tokens before the generic
  // calibrationTarget() parser. Without this, values such as "ports_led_left"
  // were parsed as port:S_LED_LEFT, so the All link/speed, All activity, and
  // All numbers quick buttons selected a non-existent individual port.
  const rawTarget = String(config?.calibration_target ?? config?.calibration_item ?? "all").trim().toLowerCase();
  if (["ports_led_left", "link_leds", "speed_leds"].includes(rawTarget)) return { type: "ports", id: "all", part: "led_left" };
  if (["ports_led_right", "activity_leds"].includes(rawTarget)) return { type: "ports", id: "all", part: "led_right" };
  if (["ports_numbers", "port_numbers", "number_labels"].includes(rawTarget)) return { type: "ports", id: "all", part: "number" };
  if (rawTarget === "ports_custom") return { type: "ports", id: "custom", selection: "custom", part: String(config?.calibration_part || "center").toLowerCase() };
  const parityMatch = rawTarget.match(/^ports_(odd|even)(?:_(led_left|led_right|numbers|center))?$/);
  if (parityMatch) {
    const partMap = { led_left: "led_left", led_right: "led_right", numbers: "number", center: "center" };
    return { type: "ports", id: parityMatch[1], parity: parityMatch[1], part: partMap[parityMatch[2]] || "center" };
  }
  if (rawTarget === "logo") return { type: "logo", id: "logo", part: "box" };
  if (rawTarget === "calibration_button") return { type: "calibration_button", id: "calibration_button", part: "box" };
  if (rawTarget === "status_box" || rawTarget === "status_box_1") return { type: "status_box", id: "status_box_1", part: "box" };
  if (rawTarget === "status_box_2") return { type: "status_box_2", id: "status_box_2", part: "box" };
  if (rawTarget === "status_fields") return { type: "status_fields", id: "all", part: "field" };
  if (rawTarget === "status_fields_2") return { type: "status_fields_2", id: "all", part: "field" };
  if (rawTarget.startsWith("status_field_2:")) return { type: "status_field_2", id: rawTarget.split(":").slice(1).join(":"), part: "field" };
  if (rawTarget.startsWith("status_field:")) return { type: "status_field", id: rawTarget.split(":").slice(1).join(":"), part: "field" };

  const target = calibrationTarget(config);
  if (target === "ports") return { type: "ports", id: "all" };
  if (["sfp", "sfps", "uplinks"].includes(target)) return { type: "sfps", id: "all" };
  if (target === "status" || target === "status_leds" || target === "leds") return { type: "status_leds", id: "all" };
  if (target && typeof target === "object") return target;
  return { type: "port", id: 1 };
}

function targetLabelForConfig(config) {
  const target = normalCalibrationTarget(config);
  const type = String(target.type || "").toLowerCase();
  if (type === "ports" && target.part === "led_left") return "ports_led_left";
  if (type === "ports" && target.part === "led_right") return "ports_led_right";
  if (type === "ports" && target.part === "number") return "ports_numbers";
  if (type === "ports" && (target.selection === "custom" || target.id === "custom")) return "ports_custom";
  if (type === "ports" && target.parity) {
    const suffix = target.part === "led_left" ? "led_left" : (target.part === "led_right" ? "led_right" : (target.part === "number" ? "numbers" : "center"));
    return `ports_${target.parity}_${suffix}`;
  }
  if (type === "logo") return "logo";
  if (type === "calibration_button") return "calibration_button";
  if (type === "status_box") return "status_box";
  if (type === "status_box_2") return "status_box_2";
  if (type === "status_fields") return "status_fields";
  if (type === "status_fields_2") return "status_fields_2";
  if (type === "status_field_2") return `status_field_2:${target.id}`;
  if (type === "status_field") return `status_field:${target.id}`;
  if (type === "ports") return "ports";
  if (type === "sfps") return "sfps";
  if (type === "status_leds") return "status_leds";
  return `${target.type}:${target.id}`;
}

function getEditableCalibrationTarget(cal, config) {
  const target = normalCalibrationTarget(config);
  const type = String(target.type || "port").toLowerCase();
  const rawId = target.id;
  let part = String(target.part || config.calibration_part || "center").toLowerCase();

  ensureCalibrationUi(cal);

  if (type === "logo") {
    const item = cal.ui.logo;
    return { type, id: "logo", key: "logo", item, part: "box", point: [item.x, item.y], hitbox: [item.width, item.height], ui: true };
  }

  if (type === "calibration_button") {
    const item = cal.ui.calibration_button;
    return { type, id: "calibration_button", key: "calibration_button", item, part: "box", point: [item.x, item.y], hitbox: [item.width, item.height], ui: true };
  }

  if (type === "status_box") {
    const item = cal.ui.status_panel;
    return { type, id: "status_box_1", key: "status_box_1", item, part: "box", point: [item.x, item.y], hitbox: [item.width, item.height], ui: true };
  }

  if (type === "status_box_2") {
    const item = cal.ui.status_panel_2;
    return { type, id: "status_box_2", key: "status_box_2", item, part: "box", point: [item.x, item.y], hitbox: [item.width, item.height], ui: true };
  }

  if (type === "status_fields") {
    return { type, id: "all", key: "status_fields", item: cal.ui.status_panel, part: "field", point: ["all", "all"], group: true };
  }
  if (type === "status_fields_2") {
    return { type, id: "all", key: "status_fields_2", item: cal.ui.status_panel_2, part: "field", point: ["all", "all"], group: true };
  }

  if (type === "status_field_2") {
    const key = String(rawId || "row1_key").toLowerCase();
    const item = cal.ui.status_panel_2.fields;
    if (!item[key]) return null;
    return { type, id: key, key, item, part: "field", point: item[key] };
  }

  if (type === "status_field") {
    const key = String(rawId || "row1_key").toLowerCase();
    const item = cal.ui.status_panel.fields;
    if (!item[key]) return null;
    return { type, id: key, key, item, part: "field", point: item[key] };
  }

  if (type === "ports") {
    const allowed = ["center", "led_left", "led_right", "number"];
    if (!allowed.includes(part)) part = "center";
    const custom = target.selection === "custom" || String(rawId) === "custom";
    const parity = custom ? "custom" : (target.parity || (["odd", "even"].includes(String(rawId)) ? String(rawId) : "all"));
    const keys = custom ? calibrationSelectedPortKeys(config, cal) : calibrationPortKeysByParity(cal, parity);
    return { type, id: parity, key: `ports_${parity}`, parity, keys, custom, item: { hitbox: part === "center" ? [34, 56] : null }, part, point: null, group: true };
  }

  if (type === "sfps") {
    part = "center";
    return { type, id: "all", key: "sfps", item: { hitbox: [78, 58] }, part, point: null, group: true };
  }

  if (type === "status_leds") {
    part = "center";
    return { type, id: "all", key: "status_leds", item: {}, part, point: null, group: true };
  }

  if (type === "port" || type === "ports") {
    const id = String(Number(rawId));
    const item = cal.ports?.[id];
    if (!item) return null;
    const allowed = ["center", "led_left", "led_right", "number"];
    if (!allowed.includes(part)) part = "center";
    return { type, id, key: id, item, part, point: item[part] };
  }

  if (type === "sfp") {
    const found = sfpEntryForTarget(cal, rawId);
    if (!found) return null;
    part = "center";
    return { type, id: String(sfpPortNumber(found.key)), key: found.key, item: found.item, part, point: found.item.center };
  }

  if (type === "status") {
    const key = statusKeyForTarget(cal, rawId);
    if (!key) return null;
    part = "center";
    return { type, id: key, key, item: cal.status_leds, part, point: cal.status_leds[key] };
  }

  return null;
}

function movePoint(point, dx, dy) {
  if (!Array.isArray(point)) return;
  point[0] = Math.round((Number(point[0]) + dx) * 10) / 10;
  point[1] = Math.round((Number(point[1]) + dy) * 10) / 10;
}

function sortedCalibrationPortKeys(cal) {
  return Object.keys(cal?.ports || {}).sort((a, b) => Number(a) - Number(b));
}

function calibrationPortKeysByParity(cal, parity = "all") {
  const keys = sortedCalibrationPortKeys(cal);
  if (parity === "odd") return keys.filter((key) => Number(key) % 2 === 1);
  if (parity === "even") return keys.filter((key) => Number(key) % 2 === 0);
  return keys;
}

function calibrationPortKeysForEditable(cal, editable) {
  if (Array.isArray(editable?.keys)) return editable.keys;
  return calibrationPortKeysByParity(cal, editable?.parity || "all");
}

function nextCalibrationPortNumber(cal) {
  const nums = sortedCalibrationPortKeys(cal).map(Number).filter(Number.isFinite);
  return nums.length ? Math.max(...nums) + 1 : 1;
}

function cloneCalibrationPort(cal, sourceKey, newKey, offsetX = 12, offsetY = 0) {
  cal.ports = cal.ports && typeof cal.ports === "object" ? cal.ports : {};
  const source = cal.ports?.[String(sourceKey)] || Object.values(cal.ports)[0] || {
    center: [177, 243], number: [176, 181], led_left: [158, 230], led_right: [195, 230], hitbox: [34, 56]
  };
  const copy = JSON.parse(JSON.stringify(source));
  for (const part of ["center", "number", "led_left", "led_right"]) {
    if (Array.isArray(copy[part])) {
      copy[part][0] = Math.round((Number(copy[part][0]) + offsetX) * 10) / 10;
      copy[part][1] = Math.round((Number(copy[part][1]) + offsetY) * 10) / 10;
    }
  }
  cal.ports[String(newKey)] = copy;
  return copy;
}

function targetOptionsHtml(cal, selected) {
  const selectedValue = String(selected || "port:1").toLowerCase();
  const option = (value, label) => `<option value="${htmlEscape(value)}" ${String(value).toLowerCase() === selectedValue ? "selected" : ""}>${htmlEscape(label)}</option>`;
  const opts = [];
  opts.push(option("logo", "Logo"));
  opts.push(option("status_box", "Status Box 1"));
  opts.push(option("status_box_2", "Status Box 2"));
  opts.push(option("calibration_button", "Calibration button"));
  opts.push(option("status_fields", "All Status Box 1 fields"));
  opts.push(option("status_fields_2", "All Status Box 2 fields"));
  opts.push(`<optgroup label="Status Box 1 fields">`);
  for (const [key, label] of STATUS_PANEL_FIELD_DEFS) opts.push(option(`status_field:${key}`, label));
  opts.push(`</optgroup>`);
  opts.push(`<optgroup label="Status Box 2 fields">`);
  for (const [key, label] of STATUS_PANEL_FIELD_DEFS) opts.push(option(`status_field_2:${key}`, label));
  opts.push(`</optgroup>`);
  opts.push(option("ports", "All RJ45 ports"));
  opts.push(option("ports_led_left", "All RJ45 link/speed LEDs"));
  opts.push(option("ports_led_right", "All RJ45 activity LEDs"));
  opts.push(option("ports_numbers", "All RJ45 number labels"));
  opts.push(`<optgroup label="RJ45 ports">`);
  for (const key of sortedCalibrationPortKeys(cal)) opts.push(option(`port:${key}`, `Port ${key}`));
  opts.push(`</optgroup>`);
  opts.push(option("sfps", "All SFP / uplinks"));
  opts.push(`<optgroup label="SFP / uplinks">`);
  for (const name of Object.keys(cal.sfp || {})) opts.push(option(`sfp:${sfpPortNumber(name)}`, name));
  opts.push(`</optgroup>`);
  opts.push(option("status_leds", "All status LEDs"));
  opts.push(`<optgroup label="Status LEDs">`);
  for (const name of Object.keys(cal.status_leds || {})) {
    if (String(name).toUpperCase() === "MODE") continue;
    opts.push(option(`status:${name}`, name));
  }
  opts.push(`</optgroup>`);
  return opts.join("");
}

function calibrationPartOptionsHtml(target, selectedPart) {
  const type = String(target?.type || "port").toLowerCase();
  const part = String(selectedPart || "center").toLowerCase();
  const option = (value, label) => `<option value="${htmlEscape(value)}" ${value === part ? "selected" : ""}>${htmlEscape(label)}</option>`;
  if (["logo", "status_box", "status_box_2", "calibration_button"].includes(type)) return option("box", "Box / size");
  if (["status_fields", "status_fields_2", "status_field", "status_field_2"].includes(type)) return option("field", "Field position");
  if (type === "port" || type === "ports") {
    return [
      option("center", "Hitbox centre"),
      option("led_left", "Link/speed LED"),
      option("led_right", "Activity LED"),
      option("number", "Number label")
    ].join("");
  }
  if (type === "sfp" || type === "sfps") return option("center", type === "sfps" ? "All SFP centres" : "SFP centre");
  if (type === "status_leds") return option("center", "All status LED centres");
  return option("center", "LED centre");
}

function ensureCalibrationManagement(cal) {
  if (!cal) return cal;
  cal.management = cal.management && typeof cal.management === "object" && !Array.isArray(cal.management) ? cal.management : {};
  cal.management.switch_ip = String(cal.management.switch_ip || cal.management.management_ip || cal.management.host_ip || "").trim();
  return cal;
}

function managementFromCalibration(cal) {
  const management = ensureCalibrationManagement(cal)?.management || {};
  const switchIp = String(management.switch_ip || "").trim();
  return switchIp ? { switch_ip: switchIp } : {};
}

function calibrationExportData(cal) {
  const statusLeds = {};
  for (const [name, xy] of Object.entries(cal.status_leds || {})) {
    if (String(name).toUpperCase() === "MODE") continue;
    statusLeds[name] = xy;
  }
  return {
    schema_version: 1,
    schema: "switch-vision-interactive-calibration-v1",
    profile_name: "",
    model: cal.model || "cisco-3650-48p-2x10g",
    generated_by: `Switch Vision v${SV_VERSION}`,
    image: cal.image,
    ports: cal.ports,
    sfp: cal.sfp,
    status_leds: statusLeds,
    ui: uiFromCalibration(cal),
    stack: stackFromCalibration(cal),
    management: managementFromCalibration(cal)
  };
}


const SV_DEVICE_VISUAL_RECOMMENDATIONS = [{"model":"WS-C3650-48PD-E","status":"confirmed","family":"Catalyst 3650","rj45":48,"uplinks":4,"visual_status":"confirmed","faceplate":"faceplates/sv-dark.png","optional_faceplates":["faceplates/sv-light.png"],"profile":"default_cisco_48_port","canvas":{"width":2048,"height":448}},{"model":"WS-C3650-48PD-L","status":"confirmed","family":"Catalyst 3650","rj45":48,"uplinks":4,"visual_status":"confirmed","faceplate":"faceplates/sv-dark.png","optional_faceplates":["faceplates/sv-light.png"],"profile":"default_cisco_48_port","canvas":{"width":2048,"height":448}},{"model":"WS-C2960X-48FPD-L","status":"experimental","family":"Catalyst 2960X","rj45":48,"uplinks":4,"visual_status":"pending_faceplate","faceplate":"","optional_faceplates":[],"profile":"","canvas":null},{"model":"WS-C2960X-24PS-L","status":"experimental","family":"Catalyst 2960X","rj45":24,"uplinks":4,"visual_status":"pending_faceplate","faceplate":"","optional_faceplates":[],"profile":"","canvas":null},{"model":"WS-C2960S-48FPD-L","status":"experimental","family":"Catalyst 2960S","rj45":48,"uplinks":4,"visual_status":"pending_faceplate","faceplate":"","optional_faceplates":[],"profile":"","canvas":null}];

function exactModelVisualRecommendation(model) {
  const exact = String(model || "").trim().toUpperCase();
  if (!exact) return null;
  return SV_DEVICE_VISUAL_RECOMMENDATIONS.find((item) => String(item.model || "").toUpperCase() === exact) || null;
}

const SV_ASSET_DEFAULT = "__default__";
const SV_ASSET_NONE = "__none__";

function safeAssetFilename(value) {
  const file = String(value || "").trim();
  if (!file || file.includes("/") || file.includes("\\") || file === "." || file === "..") return "";
  return file;
}

function assetUrl(kind, file, version = SV_VERSION) {
  const safe = safeAssetFilename(file);
  if (!safe) return "";
  return `/local/switch-vision/${kind}/${encodeURIComponent(safe)}?v=${encodeURIComponent(version)}`;
}

function assetDisplayLabel(kind, file) {
  const shippedLabels = {
    faceplates: {
      "sv-dark.png": "Switch Vision 48 Port — Dark",
      "sv-light.png": "Switch Vision 48 Port — Light"
    }
  };
  if (shippedLabels[kind]?.[file]) return shippedLabels[kind][file];
  return String(file || "")
    .replace(/\.[^.]+$/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function assetOptionsHtml(kind, files, selected, defaultLabel) {
  const selectedValue = String(selected || SV_ASSET_DEFAULT);
  const option = (value, label, disabled = false) => `<option value="${htmlEscape(value)}" ${value === selectedValue ? "selected" : ""} ${disabled ? "disabled" : ""}>${htmlEscape(label)}</option>`;
  const rows = [option(SV_ASSET_DEFAULT, defaultLabel), option(SV_ASSET_NONE, "None")];
  const safeFiles = Array.isArray(files) ? files.map(safeAssetFilename).filter(Boolean) : [];
  if (safeFiles.length) {
    for (const file of safeFiles) rows.push(option(file, assetDisplayLabel(kind, file)));
  } else {
    rows.push(option("__empty__", `No custom ${kind} found`, true));
  }
  if (![SV_ASSET_DEFAULT, SV_ASSET_NONE].includes(selectedValue) && !safeFiles.includes(selectedValue)) {
    rows.push(option(selectedValue, `${assetDisplayLabel(kind, selectedValue)} (missing)`));
  }
  return rows.join("");
}


const SV_TYPE = "switch-vision-3650";

class SwitchVision3650 extends HTMLElement {
  connectedCallback() {
    if (!this._boundCalibrationSavedHandler) {
      this._boundCalibrationSavedHandler = (event) => this.handleLocalCalibrationSaved(event);
    }
    window.addEventListener("switch-vision-calibration-saved", this._boundCalibrationSavedHandler);
  }

  disconnectedCallback() {
    if (this._boundCalibrationSavedHandler) {
      window.removeEventListener("switch-vision-calibration-saved", this._boundCalibrationSavedHandler);
    }
    clearInterval(this._activityRenderTimer);
    clearTimeout(this._activityStopTimer);
  }

  handleLocalCalibrationSaved(event) {
    const detail = event?.detail || {};
    const profile = String(detail.profile || "").trim();
    const mine = this.calibrationProfileName();
    if (profile && profile !== mine) return;
    const saved = detail.calibration;
    if (!saved || typeof saved !== "object") return;
    this._profileCalibration = cloneCalibrationData(saved);
    this._profileLoadedProfile = mine;
    this._profileLoadRequested = mine;
    this._profileLoadInfo = {
      ...(this._profileLoadInfo || {}),
      profile: mine,
      exists: true,
      source: "saved Home Assistant profile",
      storage_key: "switch_vision_calibrations",
      storage_path: ".storage/switch_vision_calibrations",
      profile_path: `.storage/switch_vision_calibrations → profiles.${mine}`,
    };
    if (calibrationControlsEnabled(this.config)) {
      if (this._calibrationDirty !== true) {
        this._calibrationWorking = cloneCalibrationData(applyConfigToCalibrationForEdit(this._profileCalibration, this.config));
      }
      this.render();
    } else {
      this._calibrationWorking = null;
      this.render();
    }
  }

  setConfig(config) {
    this._rawConfig = { ...(config || {}) };
    this.config = {
      title: "Cisco 3650 Server Stack",
      member: "SW1",
      stack_enabled: false,
      stack_id: "",
      stack_member_number: null,
      stack_uptime_mode: null,
      stack_uptime_source: "",
      stack_member_uptime_source: "",
      demo: false,
      show_numbers: true,
      port_label_offset: 0,
      port_entity_offset: 0,
      show_port_leds: true,
      show_status_leds: true,
      show_status_panel: true,
      show_labels: true,
      show_legend: false,
      calibration_button: true,
      calibration_profile: null,
      selected_switch: null,
      discovery_selected_switch: null,
      calibration_profile_load: true,
      calibration_profile_auto_load: true,
      calibration_profile_auto_create: true,
      selected_interface: null,
      selected_port: null,
      calibration_mode: false,
      calibration_target: "all",
      calibration_blink: true,
      calibration_blink_ms: 700,
      calibration_show_hitboxes: true,
      calibration_show_labels: true,
      calibration_show_led_rings: true,
      calibration_controls: false,
      calibration_part: "center",
      calibration_step: 1,
      unknown_is_up: false,
      auto_speed_entity: true,
      activity_led_class: "cv-led-amber",
      activity_flash_ms: 800,
      activity_window_ms: 6500,
      activity_bridge_ms: 3500,
      activity_decay_ms: 3000,
      activity_slot_ms: 220,
      activity_heavy_slot_ms: 120,
      activity_animation_refresh_ms: 150,
      activity_slow_period_ms: 750,
      activity_medium_period_ms: 350,
      activity_fast_period_ms: 180,
      status_up_values: ["up", "on", "1", "true", "connected", "active", "online", "linkup", "link_up"],
      status_down_values: ["down", "off", "0", "2", "false", "disconnected", "inactive", "offline", "unavailable", "unknown", "linkdown", "link_down"],
      version: SV_VERSION,
      __raw_config: this._rawConfig,
      ...config
    };

    const nextProfile = this.calibrationProfileName();
    if (this._lastConfiguredProfile && this._lastConfiguredProfile !== nextProfile) {
      this._profileLoadRequested = null;
      this._profileLoadedProfile = null;
      this._profileLoadInfo = null;
      this._profileLoadError = null;
      this._profileAutoCreateRequested = null;
      this._calibrationWorking = null;
      this._calibrationDirty = false;
    }
    this._lastConfiguredProfile = nextProfile;
  }

  set hass(hass) {
    this._hass = hass;
    this.subscribeCalibrationUpdates();
    this.maybeLoadCalibrationProfile();
    this.maybeLoadAssetLibrary();

    clearInterval(this._activityRenderTimer);
    clearTimeout(this._activityStopTimer);
    this._activityRenderTimer = null;
    this._activityStopTimer = null;

    // v0.5.3: Home Assistant can call set hass repeatedly, and the normal
    // activity refresh timer re-rendered the whole shadow DOM every ~120ms.
    // That destroyed open <select> menus, making dropdowns appear to instantly close.
    // In interactive calibration mode, render only when controls change or when
    // no calibration control currently has focus.
    const controlsActive = calibrationControlsEnabled(this.config);
    const controlFocused = this.isCalibrationControlFocused();

    if (!this.shadowRoot || !this.shadowRoot.getElementById("s")) {
      this.render();
    } else if (!controlFocused) {
      this.redrawSwitchSvg();
    }

    if (controlsActive) return;

    const refreshMs = Number(this.config?.activity_animation_refresh_ms ?? 150);
    const windowMs = Number(this.config?.activity_window_ms ?? 6500);
    const holdMs = activityHoldMs(this.config || {});

    // v0.5.50: refresh only the SVG overlay in live mode. Rebuilding the full
    // shadow DOM repeatedly also recreated the switch <img>, which could cause
    // visible image flicker once the on-card calibration button was added.
    // v0.6.8: when activity_hold_seconds is configured, keep the redraw timer
    // alive for the full poll-aware hold window. The previous stop timer still
    // used activity_window_ms (~6.5s), so blinking could stop before the next
    // 30s traffic poll even though the activity state was still held active.
    this._activityRenderTimer = setInterval(() => this.redrawSwitchSvg(), Math.max(80, refreshMs));
    this._activityStopTimer = setTimeout(() => {
      clearInterval(this._activityRenderTimer);
      this._activityRenderTimer = null;
      this.redrawSwitchSvg();
    }, Math.max(500, windowMs + 300, holdMs + 1000));
  }

  isCalibrationControlFocused() {
    if (!this.shadowRoot || !calibrationControlsEnabled(this.config)) return false;
    const active = this.shadowRoot.activeElement;
    if (!active) return false;
    return Boolean(active.closest?.('.cv-cal-tools'));
  }

  getCardSize() {
    return 2;
  }

  legend() {
    if (!this.config.show_legend) return "";

    return `<div class="cv-legend"><div class="cv-legend-row">
      <span class="cv-legend-item"><span class="cv-legend-dot" style="color:#222;background:#222"></span>Link Down</span>
      <span class="cv-legend-item"><span class="cv-legend-dot" style="color:#ffb321;background:#ffb321"></span>100 Mbps / PoE</span>
      <span class="cv-legend-item"><span class="cv-legend-dot" style="color:#76ff33;background:#76ff33"></span>1 Gbps</span>
      <span class="cv-legend-item"><span class="cv-legend-dot" style="color:#29a8ff;background:#29a8ff"></span>10G / SFP</span>
    </div></div>`;
  }

  calibrationButton() {
    if (this.config.calibration_button === false) return "";
    const active = calibrationControlsEnabled(this.config);
    const label = active ? "Done" : "Calibrate";
    const title = active ? "Exit Switch Vision calibration mode" : "Enable Switch Vision calibration mode";
    const ui = uiFromCalibration(this.calibrationData()).calibration_button || {};
    if (ui.show === false) return "";
    const designWidth = 2048;
    const designHeight = 448;
    const width = Math.max(8, Math.min(designWidth, Number(ui.width) || 138));
    const height = Math.max(8, Math.min(designHeight, Number(ui.height) || 34));
    const x = Math.max(0, Math.min(designWidth - width, Number(ui.x) || (designWidth - width - 22)));
    const y = Math.max(0, Math.min(designHeight - height, Number(ui.y) || 14));
    const style = [
      `left:${(x / designWidth) * 100}%`,
      `top:${(y / designHeight) * 100}%`,
      `width:${(width / designWidth) * 100}%`,
      `height:${(height / designHeight) * 100}%`,
      "right:auto"
    ].join(";");
    return `<button type="button" class="cv-cal-toggle ${active ? "is-active" : ""}" style="${style}" data-cv-action="toggle-calibration" title="${title}">${label}</button>`;
  }

  attachCalibrationButtonHandler() {
    if (!this.shadowRoot) return;
    const button = this.shadowRoot.querySelector('[data-cv-action="toggle-calibration"]');
    if (!button) return;
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const active = calibrationControlsEnabled(this.config);
      if (!active) {
        this._calibrationDirty = false;
        this._calibrationWorking = applyConfigToCalibrationForEdit(this.baseCalibrationData(), this.config);
      } else {
        const working = this.calibrationData();
        const validation = validateImportedCalibration(calibrationExportData(working), working);
        if (!validation.valid) {
          this.setCalibrationSaveStatus(`Cannot finish: ${validation.errors[0] || "calibration validation failed"}`, true);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }
        try {
          const profile = await this.saveCalibrationProfile(working);
          this._calibrationDirty = false;
          this.setCalibrationSaveStatus(`Profile saved: ${profile}`, false);
        } catch (err) {
          console.error("Switch Vision automatic Done save failed", err);
          this.setCalibrationSaveStatus("Could not save profile — calibration remains open", true);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }
      }
      this.config = {
        ...this.config,
        calibration_mode: !active,
        calibration_controls: !active,
        calibration_target: this.config.calibration_target || "all",
        calibration_part: this.config.calibration_part || "center"
      };
      // Each new calibration session starts clean and compact. Section open
      // state is intentionally session-only and is not carried across closes.
      if (!active) this._calibrationSectionState = {};
      this.render();
      if (!active && this._profileLoadedProfile !== this.calibrationProfileName()) {
        this.loadCalibrationProfile(true, { applyToWorking: true });
      }
    });
  }

  baseCalibrationData() {
    return ensureCalibrationUi(this._profileCalibration || calibration);
  }

  calibrationData() {
    const base = this.baseCalibrationData();
    if (!calibrationControlsEnabled(this.config)) return base;
    if (!this._calibrationWorking) this._calibrationWorking = applyConfigToCalibrationForEdit(base, this.config);
    return ensureCalibrationUi(this._calibrationWorking);
  }

  canLoadCalibrationProfile() {
    return this.config?.calibration_profile_load !== false && Boolean(this._hass?.callWS);
  }

  async loadCalibrationProfile(force = false, options = {}) {
    if (!this.canLoadCalibrationProfile()) return null;
    const profile = this.calibrationProfileName();
    if (!profile) return null;
    const applyToWorking = options.applyToWorking === true;
    if (!force && !applyToWorking && this._profileLoadRequested === profile) return this._profileLoadInfo || null;

    this._profileLoadRequested = profile;
    this._profileLoadError = null;
    this._profileLoading = true;
    if (applyToWorking) {
      this.setCalibrationSaveStatus(`Loading profile: ${profile}`, false);
      this.render();
    }

    try {
      const result = await this._hass.callWS({
        type: "switch_vision/get_calibration",
        profile
      });
      if (this.calibrationProfileName() !== profile) return null;

      this._profileLoadInfo = {
        profile,
        exists: Boolean(result?.exists),
        source: result?.source || (result?.exists ? "Home Assistant storage" : "current card config / baked defaults"),
        storage_key: result?.storage_key || "switch_vision_calibrations",
        storage_path: result?.storage_path || ".storage/switch_vision_calibrations",
        profile_path: result?.profile_path || `.storage/switch_vision_calibrations → profiles.${profile}`,
      };

      const loaded = result?.calibration;
      if (loaded && typeof loaded === "object") {
        this._profileCalibration = cloneCalibrationData(loaded);
        this._profileLoadedProfile = profile;
        const loadedForEdit = applyConfigToCalibrationForEdit(this._profileCalibration, this.config);
        if (applyToWorking || !this._calibrationWorking) {
          this._calibrationWorking = cloneCalibrationData(loadedForEdit);
          this._calibrationDirty = false;
        }
        if (!calibrationControlsEnabled(this.config)) this._calibrationWorking = null;
        if (applyToWorking) this.setCalibrationSaveStatus(`Loaded profile: ${profile}`, false);
        this.render();
        return this._profileLoadInfo;
      }

      const shouldCreateStarter =
        applyToWorking &&
        calibrationControlsEnabled(this.config) &&
        this.config?.calibration_profile_auto_create !== false;

      if (shouldCreateStarter) {
        return await this.createStarterCalibrationProfile(profile);
      }

      if (applyToWorking) this.setCalibrationSaveStatus(`No saved profile found: ${profile}`, true);
      if (calibrationControlsEnabled(this.config)) this.render();
      return this._profileLoadInfo;
    } catch (err) {
      // Fallback to current card YAML/baked defaults if the integration or websocket command is unavailable.
      this._profileLoadError = err;
      this._profileLoadInfo = {
        profile,
        exists: false,
        source: "profile load unavailable; using current card config / baked defaults",
        storage_key: "switch_vision_calibrations",
        storage_path: ".storage/switch_vision_calibrations",
        profile_path: `.storage/switch_vision_calibrations → profiles.${profile}`,
      };
      if (applyToWorking) this.setCalibrationSaveStatus("Load failed — check HA logs/config", true);
      console.debug?.("Switch Vision profile load unavailable", err);
      if (calibrationControlsEnabled(this.config)) this.render();
      return this._profileLoadInfo;
    } finally {
      this._profileLoading = false;
    }
  }

  async createStarterCalibrationProfile(profile) {
    const targetProfile = String(profile || this.calibrationProfileName()).trim();
    if (!targetProfile) return null;
    if (this._profileLoadedProfile === targetProfile) return this._profileLoadInfo || null;
    if (this._profileAutoCreateRequested === targetProfile) return this._profileLoadInfo || null;

    this._profileAutoCreateRequested = targetProfile;
    const starter = applyConfigToCalibrationForEdit(this.baseCalibrationData(), this.config);
    this.setCalibrationSaveStatus(`Creating starter profile: ${targetProfile}`, false);
    if (calibrationControlsEnabled(this.config)) this.render();

    try {
      await this.saveCalibrationProfile(starter);
      if (this.calibrationProfileName() !== targetProfile) return null;

      this._calibrationWorking = cloneCalibrationData(
        applyConfigToCalibrationForEdit(this._profileCalibration, this.config)
      );
      this._calibrationDirty = false;
      this.setCalibrationSaveStatus(`Created starter profile: ${targetProfile}`, false);
      if (calibrationControlsEnabled(this.config)) this.render();
      this.clearCalibrationSaveStatusSoon();
      return this._profileLoadInfo;
    } catch (err) {
      this._profileAutoCreateRequested = null;
      this._profileLoadError = err;
      this.setCalibrationSaveStatus(`Could not create starter profile: ${targetProfile}`, true);
      console.debug?.("Switch Vision starter profile creation failed", err);
      if (calibrationControlsEnabled(this.config)) this.render();
      return this._profileLoadInfo || null;
    }
  }

  maybeLoadCalibrationProfile(force = false) {
    const profile = this.calibrationProfileName();
    const controlsActive = calibrationControlsEnabled(this.config);
    const autoLoadEnabled = this.config?.calibration_profile_auto_load !== false;
    const needsProfile = profile && this._profileLoadedProfile !== profile;
    const safeToApply = controlsActive && autoLoadEnabled && needsProfile && this._calibrationDirty !== true;

    // v0.6.18: when a calibration page is opened directly, Home Assistant may
    // render the editor from card YAML/baked defaults before the saved profile
    // websocket response returns. In that case, automatically apply the saved
    // profile into the active edit session. The manual load button remains as a
    // fallback/reload action.
    this.loadCalibrationProfile(force || safeToApply, { applyToWorking: safeToApply });
  }

  subscribeCalibrationUpdates() {
    if (this._calibrationEventSubscriptionRequested || !this._hass?.connection?.subscribeEvents) return;
    this._calibrationEventSubscriptionRequested = true;
    this._hass.connection.subscribeEvents((event) => {
      const data = event?.data || {};
      const profile = String(data.profile || "");
      const mine = this.calibrationProfileName();
      if (profile && profile !== "*" && profile !== mine) return;
      this._profileLoadRequested = null;
      this._profileLoadedProfile = null;
      if (data.calibration && typeof data.calibration === "object") {
        this.handleLocalCalibrationSaved({ detail: { profile: mine, calibration: data.calibration } });
      } else {
        this.maybeLoadCalibrationProfile(true);
      }
    }, "switch_vision_calibration_updated").then((unsub) => {
      this._calibrationEventUnsub = unsub;
    }).catch((err) => {
      console.debug?.("Switch Vision event subscription unavailable", err);
    });
  }

  async maybeLoadAssetLibrary(force = false) {
    if (!this._hass?.callWS) return null;
    if (this._assetLibraryLoading) return null;
    if (!force && this._assetLibrary) return this._assetLibrary;
    this._assetLibraryLoading = true;
    this._assetLibraryError = null;
    try {
      const result = await this._hass.callWS({ type: "switch_vision/list_assets" });
      this._assetLibrary = {
        logos: Array.isArray(result?.logos) ? result.logos : [],
        faceplates: Array.isArray(result?.faceplates) ? result.faceplates : [],
        logos_path: result?.logos_path || "/config/www/switch-vision/logos",
        faceplates_path: result?.faceplates_path || "/config/www/switch-vision/faceplates"
      };
      if (calibrationControlsEnabled(this.config)) this.render();
      return this._assetLibrary;
    } catch (err) {
      this._assetLibraryError = err;
      this._assetLibrary = { logos: [], faceplates: [], logos_path: "/config/www/switch-vision/logos", faceplates_path: "/config/www/switch-vision/faceplates" };
      console.debug?.("Switch Vision asset listing unavailable", err);
      if (calibrationControlsEnabled(this.config)) this.render();
      return null;
    } finally {
      this._assetLibraryLoading = false;
    }
  }

  saveCalibrationExportSize() {
    if (!this.shadowRoot) return;
    const textarea = this.shadowRoot.querySelector('.cv-cal-export');
    if (!textarea) return;
    const rect = textarea.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      this._calibrationExportSize = { width: Math.round(rect.width), height: Math.round(rect.height) };
    }
  }

  applyCalibrationExportSize() {
    if (!this.shadowRoot || !this._calibrationExportSize) return;
    const textarea = this.shadowRoot.querySelector('.cv-cal-export');
    if (!textarea) return;
    textarea.style.width = `${this._calibrationExportSize.width}px`;
    textarea.style.height = `${this._calibrationExportSize.height}px`;
  }

  calibrationProfileName() {
    return String(
      this.config?.calibration_profile ||
      this.config?.selected_switch ||
      this.config?.discovery_selected_switch ||
      this.config?.member ||
      "default"
    ).trim() || "default";
  }

  calibrationProfileSourceDetails(profileName = this.calibrationProfileName()) {
    const explicit = String(this.config?.calibration_profile || "").trim();
    const selected = String(this.config?.selected_switch || this.config?.discovery_selected_switch || "").trim();
    const member = String(this.config?.member || "").trim();
    let profileSource = "default";
    if (explicit) profileSource = "calibration_profile";
    else if (selected) profileSource = "selected_switch";
    else if (member) profileSource = "member";

    const info = this._profileLoadInfo || {};
    const storagePath = info.storage_path || ".storage/switch_vision_calibrations";
    const profilePath = info.profile_path || `${storagePath} → profiles.${profileName}`;
    const loaded = info.exists === true || this._profileLoadedProfile === profileName;
    const source = loaded ? "saved Home Assistant profile" : (info.source || "current card config / baked defaults");
    return { profileSource, storagePath, profilePath, loaded, source };
  }

  setCalibrationSaveStatus(message, isError = false) {
    this._calibrationSaveStatus = { message, isError, ts: Date.now() };
  }

  markCalibrationDirty() {
    this._calibrationDirty = true;
  }

  clearCalibrationSaveStatusSoon() {
    clearTimeout(this._calibrationSaveStatusTimer);
    this._calibrationSaveStatusTimer = setTimeout(() => {
      this._calibrationSaveStatus = null;
      if (calibrationControlsEnabled(this.config)) this.render();
    }, 2200);
  }

  async saveCalibrationProfile(cal, profileOverride = null) {
    const profile = String(profileOverride || this.calibrationProfileName()).trim() || "default";
    const payload = calibrationExportData(cal);
    payload.profile_name = profile;

    if (!this._hass?.callService) {
      throw new Error("Home Assistant service API is not available");
    }

    await this._hass.callService("switch_vision", "save_calibration", {
      profile,
      calibration: payload
    });

    this._profileCalibration = cloneCalibrationData(payload);
    this._profileLoadedProfile = profile;
    this._profileLoadRequested = profile;
    this._profileLoadInfo = {
      profile,
      exists: true,
      source: "saved Home Assistant profile",
      storage_key: "switch_vision_calibrations",
      storage_path: ".storage/switch_vision_calibrations",
      profile_path: `.storage/switch_vision_calibrations → profiles.${profile}`,
    };

    window.dispatchEvent(new CustomEvent("switch-vision-calibration-saved", {
      detail: { profile, calibration: cloneCalibrationData(payload) }
    }));

    return profile;
  }


  detectedExactModel() {
    const candidates = [
      this.config?.exact_model,
      this.config?.switch_model,
      this.config?.device_model,
      this.config?.model,
      this.config?.platform,
    ];
    for (const value of candidates) {
      const model = String(value || "").trim().toUpperCase();
      if (/^WS-C[A-Z0-9-]+$/.test(model)) return model;
    }
    return "";
  }

  visualRecommendation(cal) {
    const model = this.detectedExactModel();
    const recommendation = exactModelVisualRecommendation(model);
    if (!recommendation) return { model, recommendation: null, checks: [], compatible: false };
    const checks = [];
    const profileOk = Boolean(recommendation.profile) && recommendation.profile === "default_cisco_48_port";
    checks.push({ label: "Calibration profile", ok: profileOk, detail: recommendation.profile || "Not assigned" });
    const faceplate = String(recommendation.faceplate || "");
    const faceplateFile = faceplate.startsWith("faceplates/") ? faceplate.split("/").pop() : "";
    const faceplateOk = faceplate === "faceplates/sv-dark.png" || faceplate === "faceplates/sv-light.png" || Boolean(faceplateFile && (this._assetLibrary?.faceplates || []).includes(faceplateFile));
    checks.push({ label: "Faceplate file", ok: faceplateOk, detail: faceplate || "Not assigned" });
    const rj45Ok = Number(recommendation.rj45 || 0) === Object.keys(cal?.ports || {}).length;
    checks.push({ label: "RJ45 count", ok: rj45Ok, detail: `${Object.keys(cal?.ports || {}).length} / ${recommendation.rj45}` });
    const uplinkOk = Number(recommendation.uplinks || 0) === Object.keys(cal?.sfp || {}).length;
    checks.push({ label: "Uplink count", ok: uplinkOk, detail: `${Object.keys(cal?.sfp || {}).length} / ${recommendation.uplinks}` });
    const canvas = recommendation.canvas || {};
    const canvasOk = Number(canvas.width || 0) === Number(cal?.image?.width || 0) && Number(canvas.height || 0) === Number(cal?.image?.height || 0);
    checks.push({ label: "Canvas", ok: canvasOk, detail: `${cal?.image?.width || 0} × ${cal?.image?.height || 0}` });
    return { model, recommendation, checks, compatible: checks.every((item) => item.ok) };
  }

  calibrationSectionOpen(key, defaultOpen = false) {
    this._calibrationSectionState = this._calibrationSectionState || {};
    return Object.prototype.hasOwnProperty.call(this._calibrationSectionState, key) ? this._calibrationSectionState[key] : defaultOpen;
  }

  calibrationSectionHtml(key, title, summary, body, defaultOpen = false) {
    const open = this.calibrationSectionOpen(key, defaultOpen) ? "open" : "";
    return `<details class="cv-cal-section" data-cv-section="${htmlEscape(key)}" ${open}><summary><span>${htmlEscape(title)}</span><small>${htmlEscape(summary || "")}</small></summary><div class="cv-cal-section-body">${body}</div></details>`;
  }

  calibrationControls(cal) {
    if (!calibrationControlsEnabled(this.config)) return "";

    const target = normalCalibrationTarget(this.config);
    const selectedTarget = targetLabelForConfig(this.config);
    const editable = getEditableCalibrationTarget(cal, this.config);
    const step = Math.max(1, Number(this.config.calibration_step || 1));
    const point = editable?.point || (editable?.group ? ["all", "all"] : ["?", "?"]);
    const item = editable?.item || {};
    const hitbox = editable?.hitbox || (editable?.group && editable.type === "ports" ? (editable.part === "center" ? [34, 56] : null) : (item.hitbox || null));
    const calibrationUi = uiFromCalibration(cal);
    const statusUi = calibrationUi.status_panel;
    const status2Ui = calibrationUi.status_panel_2;
    const logoUi = calibrationUi.logo;
    const faceplateAssetUi = calibrationUi.faceplate;
    const assetLibrary = this._assetLibrary || { logos: [], faceplates: [], logos_path: "/config/www/switch-vision/logos", faceplates_path: "/config/www/switch-vision/faceplates" };
    const logoSelection = logoUi.show === false ? SV_ASSET_NONE : (logoUi.source === "custom" ? String(logoUi.file || SV_ASSET_DEFAULT) : SV_ASSET_DEFAULT);
    const faceplateSelection = faceplateAssetUi.show === false ? SV_ASSET_NONE : String(faceplateAssetUi.file || SV_ASSET_DEFAULT);
    const assetStatus = this._assetLibraryLoading ? "Scanning folders…" : (this._assetLibraryError ? "Asset listing unavailable — check the custom component" : `${assetLibrary.logos.length} logo(s) · ${assetLibrary.faceplates.length} faceplate(s)`);
    const visualInfo = this.visualRecommendation(cal);
    const visualRec = visualInfo.recommendation;
    const visualChecksHtml = visualInfo.checks.map((check) => `<span class="cv-cal-current ${check.ok ? "is-ok" : "is-error"}">${htmlEscape(check.label)}: ${check.ok ? "OK" : "Check"} (${htmlEscape(check.detail)})</span>`).join("");
    const visualRecommendationHtml = visualRec ? `<div class="cv-cal-tools-row cv-cal-style-row cv-cal-recommendation">
      <span class="cv-cal-quick-label">Recommended setup</span>
      <span class="cv-cal-current"><b>${htmlEscape(visualInfo.model)}</b> · ${htmlEscape(visualRec.family)} · Registry: ${htmlEscape(visualRec.status)}</span>
      <span class="cv-cal-current">Faceplate: ${htmlEscape(visualRec.faceplate || "Not available")}</span>
      <span class="cv-cal-current">Profile: ${htmlEscape(visualRec.profile || "Not assigned")}</span>
      ${visualChecksHtml}
      <span class="cv-cal-current"><b>Compatibility: ${visualInfo.compatible ? "Confirmed" : (visualRec.visual_status === "pending_faceplate" ? "Pending faceplate/profile" : "Review required")}</b></span>
      ${visualInfo.compatible ? `<button type="button" data-cv-action="apply-recommended-setup">Apply Recommended Setup</button>` : ""}
    </div>` : `<div class="cv-cal-tools-row cv-cal-style-row cv-cal-recommendation"><span class="cv-cal-quick-label">Recommended setup</span><span class="cv-cal-current">${visualInfo.model ? `No exact-model visual recommendation for ${htmlEscape(visualInfo.model)}.` : "Set an exact switch model in the card configuration to receive a registry recommendation."}</span></div>`;
    ensureStatusPanelFieldState(statusUi);
    // Status Box 1 controls always edit switch-summary rows. Port selection no
    // longer swaps this control to port fields; those have their own section.
    const statusRowType = "switch";
    const statusRowDefs = STATUS_PANEL_ROW_DEFS.switch;
    const statusRowOrder = normaliseStatusPanelFieldOrder(statusUi.field_order?.switch, "switch");
    const statusHiddenFields = new Set(fieldListFromValue(statusUi.hidden_fields?.switch) || []);
    const selectedStatusRowField = statusRowDefs.defaults.includes(String(this.config.status_panel_selected_field || "").toLowerCase())
      ? String(this.config.status_panel_selected_field).toLowerCase()
      : statusRowOrder[0];
    const selectedStatusRowHidden = statusHiddenFields.has(selectedStatusRowField);
    const statusRowOptions = statusRowOrder.map((field) => {
      const label = statusRowDefs.labels[field] || field.toUpperCase();
      const suffix = statusHiddenFields.has(field) ? " (hidden)" : "";
      return `<option value="${htmlEscape(field)}" ${field === selectedStatusRowField ? "selected" : ""}>${htmlEscape(label + suffix)}</option>`;
    }).join("");
    ensureStatusPanelFieldState(status2Ui);
    const status2RowOrder = normaliseStatusPanelFieldOrder(status2Ui.field_order?.switch, "switch");
    const status2HiddenFields = new Set(fieldListFromValue(status2Ui.hidden_fields?.switch) || []);
    const selectedStatus2RowField = STATUS_PANEL_ROW_DEFS.switch.defaults.includes(String(this.config.status_panel_2_selected_field || "").toLowerCase()) ? String(this.config.status_panel_2_selected_field).toLowerCase() : status2RowOrder[0];
    const selectedStatus2RowHidden = status2HiddenFields.has(selectedStatus2RowField);
    const status2RowOptions = status2RowOrder.map((field) => { const label = STATUS_PANEL_ROW_DEFS.switch.labels[field] || field.toUpperCase(); const suffix = status2HiddenFields.has(field) ? " (hidden)" : ""; return `<option value="${htmlEscape(field)}" ${field === selectedStatus2RowField ? "selected" : ""}>${htmlEscape(label + suffix)}</option>`; }).join("");
    const portRowDefs = STATUS_PANEL_ROW_DEFS.port;
    const portRowOrder = normaliseStatusPanelFieldOrder(statusUi.field_order?.port, "port");
    const portHiddenFields = new Set(fieldListFromValue(statusUi.hidden_fields?.port) || []);
    const selectedPortRowField = portRowDefs.defaults.includes(String(this.config.port_status_selected_field || "").toLowerCase())
      ? String(this.config.port_status_selected_field).toLowerCase()
      : portRowOrder[0];
    const selectedPortRowHidden = portHiddenFields.has(selectedPortRowField);
    const portRowOptions = portRowOrder.map((field) => {
      const label = portRowDefs.labels[field] || field.toUpperCase();
      const suffix = portHiddenFields.has(field) ? " (hidden)" : "";
      return `<option value="${htmlEscape(field)}" ${field === selectedPortRowField ? "selected" : ""}>${htmlEscape(label + suffix)}</option>`;
    }).join("");
    const status1TitleOptions = statusRowOrder.map((field) => `<option value="${htmlEscape(field)}" ${field === String(statusUi.title_field || "model") ? "selected" : ""}>${htmlEscape(statusRowDefs.labels[field] || field.toUpperCase())}</option>`).join("");
    const status2TitleOptions = status2RowOrder.map((field) => `<option value="${htmlEscape(field)}" ${field === String(status2Ui.title_field || "faceplate") ? "selected" : ""}>${htmlEscape(STATUS_PANEL_ROW_DEFS.switch.labels[field] || field.toUpperCase())}</option>`).join("");
    const statusFontWeight = String(statusUi.font_weight || "normal");
    const statusBold = statusFontWeight === "bold" || Number(statusFontWeight) >= 600;
    const status2FontWeight = String(status2Ui.font_weight || "normal");
    const status2Bold = status2FontWeight === "bold" || Number(status2FontWeight) >= 600;
    const customFontValue = "SwitchVisionCustom, Arial, Helvetica, sans-serif";
    ensureCalibrationStack(cal);
    const stackConfig = stackMemberSettings(this.config, cal);
    const stackUi = stackConfig.stack;
    const stackMember = stackConfig.member;
    const currentMemberKey = normalizePanelMember(this.config).toUpperCase();
    const stackMemberNumber = Number(stackMember.member_number || currentMemberKey.replace(/[^0-9]/g, "")) || "";
    const stackUptimeMode = normaliseStackUptimeMode(stackMember.uptime_mode);
    const stackUptimeSource = String(stackMember.uptime_source || stackUi.uptime_source || "");
    const switchIpValue = String(explicitConfigValue(this.config, ["switch_ip", "management_ip", "mgmt_ip", "host_ip", "snmp_host"]) || managementIpFromCalibration(cal) || "").trim();
    const exportPayload = calibrationExportData(cal);
    exportPayload.profile_name = this.calibrationProfileName();
    const exportJson = JSON.stringify(exportPayload, null, 2);
    const showExportJson = this._showCalibrationJson === true;
    const profileName = this.calibrationProfileName();
    const profileDetails = this.calibrationProfileSourceDetails(profileName);
    const profileLoadedText = this._profileLoading ? "loading" : (profileDetails.loaded ? "loaded" : "not saved / fallback");
    const saveStatus = this._calibrationSaveStatus;
    const saveStatusHtml = saveStatus?.message ? `<span class="cv-cal-save-status ${saveStatus.isError ? "is-error" : "is-ok"}">${htmlEscape(saveStatus.message)}</span>` : "";
    const partNames = { center: "hitbox centre", led_left: "link/speed LED", led_right: "activity LED", number: "number label" };
    const partText = partNames[editable?.part] || editable?.part;
    let targetText = "no target";
    if (editable?.group && editable.type === "ports") {
      const groupLabel = editable.custom ? "selected" : (editable.parity === "odd" ? "odd" : (editable.parity === "even" ? "even" : "all"));
      const selectedCount = calibrationPortKeysForEditable(cal, editable).length;
      targetText = `${selectedCount} ${groupLabel} RJ45 ports · ${partText}`;
    }
    else if (editable?.group && editable.type === "sfps") targetText = "all SFP / uplinks · center";
    else if (editable?.group && editable.type === "status_leds") targetText = "all status LEDs · center";
    else if (editable?.group && editable.type === "status_fields") targetText = "all Status Box 1 fields";
    else if (editable?.group && editable.type === "status_fields_2") targetText = "all Status Box 2 fields";
    else if (editable?.type === "status_field") targetText = `Status Box 1 · ${statusFieldLabel(editable.id)} field`;
    else if (editable?.type === "status_field_2") targetText = `Status Box 2 · ${statusFieldLabel(editable.id)} field`;
    else if (editable) targetText = `${editable.type}:${editable.id} · ${partText}`;
    const visualSize = hitbox ? visualHitboxSize(editable?.type, hitbox) : null;
    const sizeText = visualSize ? `W ${visualSize[0]} · H ${visualSize[1]}` : "n/a";

    return `<div class="cv-cal-tools">
      <div class="cv-cal-tools-row cv-cal-tools-head">
        <div><b>Interactive calibration</b> <span>v${SV_VERSION}</span> <span class="cv-cal-profile">profile: ${htmlEscape(profileName)}</span></div>
        <div class="cv-cal-profile-path" title="${htmlEscape(profileDetails.profilePath)}">${htmlEscape(profileLoadedText)} · ${htmlEscape(profileDetails.profileSource)} · ${htmlEscape(profileDetails.profilePath)}</div>
        <div class="cv-cal-current">${htmlEscape(targetText)} · X ${htmlEscape(point[0])} · Y ${htmlEscape(point[1])} · ${htmlEscape(sizeText)}</div>
      </div>
      ${visualRecommendationHtml}
      <details class="cv-cal-section" data-cv-section="appearance" ${this.calibrationSectionOpen("appearance", false) ? "open" : ""}><summary><span>Appearance, Assets & Status Boxes</span><small>${htmlEscape(assetStatus)}</small></summary><div class="cv-cal-section-body"><div class="cv-cal-tools-row cv-cal-style-row cv-cal-assets-row">
        <span class="cv-cal-quick-label">Assets</span>
        <label>Logo
          <select class="cv-cal-select" data-cv-field="logo-file">${assetOptionsHtml("logos", assetLibrary.logos, logoSelection, "Use card default")}</select>
        </label>
        <label>Faceplate
          <select class="cv-cal-select" data-cv-field="faceplate-file">${assetOptionsHtml("faceplates", assetLibrary.faceplates, faceplateSelection, `${htmlEscape(this.config.switch_model || this.config.model || layout.model_text?.text || "Switch model")} (Default)`)}</select>
        </label>
        <button type="button" data-cv-action="refresh-assets" title="Scan the logo and faceplate folders again">Refresh files</button>
        <span class="cv-cal-current" title="Logos: ${htmlEscape(assetLibrary.logos_path)} · Faceplates: ${htmlEscape(assetLibrary.faceplates_path)}">${htmlEscape(assetStatus)}</span>
      </div>
      <div class="cv-cal-tools-row cv-cal-style-row cv-cal-faceplate-tip">
        <span class="cv-cal-current"><b>Tip:</b> Faceplates replace the switch artwork. For best results, use wide images (2048 px or wider).</span>
        <span class="cv-cal-current" data-cv-faceplate-info>Detected image dimensions appear after selection.</span>
      </div>
      <div class="cv-cal-tools-row cv-cal-style-row">
        <span class="cv-cal-quick-label">Status Box 1 style</span>
        <label>Status font
          <select class="cv-cal-select" data-cv-field="status-font">
            <option value="Arial Narrow, Roboto Condensed, Helvetica Neue Condensed, Arial, Helvetica, sans-serif" ${String(statusUi.font_family).startsWith("Arial Narrow") ? "selected" : ""}>Condensed</option>
            <option value="Arial, Helvetica, sans-serif" ${String(statusUi.font_family).startsWith("Arial,") ? "selected" : ""}>Arial</option>
            <option value="${customFontValue}" ${String(statusUi.font_family).startsWith("SwitchVisionCustom") ? "selected" : ""}>Custom / IntelOne</option>
            <option value="Courier New, monospace" ${String(statusUi.font_family).startsWith("Courier") ? "selected" : ""}>Courier</option>
            <option value="monospace" ${String(statusUi.font_family) === "monospace" ? "selected" : ""}>Monospace</option>
          </select>
        </label>
        <button type="button" class="cv-cal-bold-toggle ${statusBold ? "is-active" : ""}" data-cv-action="toggle-status-bold" title="Toggle status font bold"><b>B</b></button>
        <label>Font size
          <select class="cv-cal-select" data-cv-field="status-font-size">
            ${[12,13,14,15,16,17,18,19,20,22,24].map(v => `<option value="${v}" ${Number(statusUi.font_size) === v ? "selected" : ""}>${v}px</option>`).join("")}
          </select>
        </label>
        <label>Text colour
          <select class="cv-cal-select" data-cv-field="status-text-color">
            ${[["#ffffff","White"],["#eef7ff","Ice"],["#29a8ff","Blue"],["#ffb321","Amber"],["#76ff33","Green"]].map(([v,l]) => `<option value="${v}" ${statusUi.text_color === v ? "selected" : ""}>${l}</option>`).join("")}
          </select>
        </label>
        <label>Box colour
          <select class="cv-cal-select" data-cv-field="status-box-color">
            ${[["transparent","Clear"],["rgba(0,0,0,.06)","Smoke"],["rgba(0,0,0,.35)","Dark"],["rgba(41,168,255,.16)","Blue"],["rgba(255,179,33,.16)","Amber"]].map(([v,l]) => `<option value="${v}" ${statusUi.background_color === v ? "selected" : ""}>${l}</option>`).join("")}
          </select>
        </label>
        <label>Border <input type="checkbox" data-cv-field="status-border-show" ${statusUi.border_show !== false ? "checked" : ""}></label>
        <label>Border colour
          <select class="cv-cal-select" data-cv-field="status-border-color">
            ${[["rgba(245,248,250,.75)","White"],["#29a8ff","Blue"],["#ffb321","Amber"],["#76ff33","Green"],["#ff5252","Red"],["#000000","Black"]].map(([v,l]) => `<option value="${v}" ${statusUi.border_color === v ? "selected" : ""}>${l}</option>`).join("")}
          </select>
        </label>
      </div>
      <div class="cv-cal-tools-row cv-cal-status-row">
        <span class="cv-cal-quick-label">Status Box 1</span>
        <label>Field
          <select class="cv-cal-select" data-cv-field="status-row-field">${statusRowOptions}</select>
        </label>
        <button type="button" data-cv-action="status-row-up">Move up</button>
        <button type="button" data-cv-action="status-row-down">Move down</button>
        <button type="button" data-cv-action="status-row-toggle">${selectedStatusRowHidden ? "Show" : "Hide"}</button>
      </div>
      <div class="cv-cal-tools-row cv-cal-style-row">
        <span class="cv-cal-quick-label">Status Box 2 style</span>
        <label>Status font
          <select class="cv-cal-select" data-cv-field="status2-font">
            <option value="Arial Narrow, Roboto Condensed, Helvetica Neue Condensed, Arial, Helvetica, sans-serif" ${String(status2Ui.font_family).startsWith("Arial Narrow") ? "selected" : ""}>Condensed</option>
            <option value="Arial, Helvetica, sans-serif" ${String(status2Ui.font_family).startsWith("Arial,") ? "selected" : ""}>Arial</option>
            <option value="${customFontValue}" ${String(status2Ui.font_family).startsWith("SwitchVisionCustom") ? "selected" : ""}>Custom / IntelOne</option>
            <option value="Courier New, monospace" ${String(status2Ui.font_family).startsWith("Courier") ? "selected" : ""}>Courier</option>
            <option value="monospace" ${String(status2Ui.font_family) === "monospace" ? "selected" : ""}>Monospace</option>
          </select>
        </label>
        <button type="button" class="cv-cal-bold-toggle ${status2Bold ? "is-active" : ""}" data-cv-action="toggle-status2-bold" title="Toggle Status Box 2 font bold"><b>B</b></button>
        <label>Font size<select class="cv-cal-select" data-cv-field="status2-font-size">${[12,13,14,15,16,17,18,19,20,22,24].map(v => `<option value="${v}" ${Number(status2Ui.font_size) === v ? "selected" : ""}>${v}px</option>`).join("")}</select></label>
        <label>Text colour<select class="cv-cal-select" data-cv-field="status2-text-color">${[["#ffffff","White"],["#eef7ff","Ice"],["#29a8ff","Blue"],["#ffb321","Amber"],["#76ff33","Green"]].map(([v,l]) => `<option value="${v}" ${status2Ui.text_color === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label>Box colour<select class="cv-cal-select" data-cv-field="status2-box-color">${[["transparent","Clear"],["rgba(0,0,0,.06)","Smoke"],["rgba(0,0,0,.35)","Dark"],["rgba(41,168,255,.16)","Blue"],["rgba(255,179,33,.16)","Amber"]].map(([v,l]) => `<option value="${v}" ${status2Ui.background_color === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label>Border <input type="checkbox" data-cv-field="status2-border-show" ${status2Ui.border_show !== false ? "checked" : ""}></label>
        <label>Border colour<select class="cv-cal-select" data-cv-field="status2-border-color">${[["rgba(245,248,250,.75)","White"],["#29a8ff","Blue"],["#ffb321","Amber"],["#76ff33","Green"],["#ff5252","Red"],["#000000","Black"]].map(([v,l]) => `<option value="${v}" ${status2Ui.border_color === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
      </div>
      <div class="cv-cal-tools-row cv-cal-status-row">
        <span class="cv-cal-quick-label">Status Box 2</span>
        <label>Field<select class="cv-cal-select" data-cv-field="status2-row-field">${status2RowOptions}</select></label>
        <button type="button" data-cv-action="status2-row-up">Move up</button>
        <button type="button" data-cv-action="status2-row-down">Move down</button>
        <button type="button" data-cv-action="status2-row-toggle">${selectedStatus2RowHidden ? "Show" : "Hide"}</button>
      </div>
      <div class="cv-cal-tools-row cv-cal-status-row">
        <span class="cv-cal-quick-label">Port Status Box</span>
        <label>Field<select class="cv-cal-select" data-cv-field="port-status-row-field">${portRowOptions}</select></label>
        <button type="button" data-cv-action="port-status-row-up">Move up</button>
        <button type="button" data-cv-action="port-status-row-down">Move down</button>
        <button type="button" data-cv-action="port-status-row-toggle">${selectedPortRowHidden ? "Show" : "Hide"}</button>
      </div>
      <div class="cv-cal-tools-row cv-cal-ip-row">
        <label>Switch IP
          <input class="cv-cal-input cv-cal-ip-input" data-cv-field="switch-ip" value="${htmlEscape(switchIpValue)}" placeholder="192.168.1.102">
        </label>
        <span class="cv-cal-current">Use status row field: IP</span>
      </div>
      <div class="cv-cal-tools-row cv-cal-stack-row">
        <span class="cv-cal-quick-label">Stack</span>
        <label>Enabled
          <input type="checkbox" data-cv-field="stack-enabled" ${stackUi.enabled ? "checked" : ""}>
        </label>
        <label>Member
          <select class="cv-cal-select" data-cv-field="stack-member-number">
            <option value="" ${stackMemberNumber === "" ? "selected" : ""}>Auto</option>
            ${[1,2,3,4,5,6,7,8,9].map(v => `<option value="${v}" ${Number(stackMemberNumber) === v ? "selected" : ""}>${v}</option>`).join("")}
          </select>
        </label>
        <label>Uptime
          <select class="cv-cal-select" data-cv-field="stack-uptime-mode">
            <option value="standalone" ${stackUptimeMode === "standalone" ? "selected" : ""}>Own sensor</option>
            <option value="stack_source" ${stackUptimeMode === "stack_source" ? "selected" : ""}>Stack source</option>
            <option value="inherit_stack" ${stackUptimeMode === "inherit_stack" ? "selected" : ""}>Inherit stack</option>
          </select>
        </label>
        <label>Source
          <input class="cv-cal-input cv-cal-entity-input" data-cv-field="stack-uptime-source" value="${htmlEscape(stackUptimeSource)}" placeholder="sensor.sw1_uptime">
        </label>
      </div>
      </div></details>
      <details class="cv-cal-section" data-cv-section="target" ${this.calibrationSectionOpen("target", false) ? "open" : ""}><summary><span>Calibration Target</span><small>${htmlEscape(targetText)} · ${sortedCalibrationPortKeys(cal).length} ports</small></summary><div class="cv-cal-section-body"><div class="cv-cal-tools-row">
        <label>Target
          <select class="cv-cal-select" data-cv-field="target">${targetOptionsHtml(cal, selectedTarget)}</select>
        </label>
        <label>Part
          <select class="cv-cal-select" data-cv-field="part">${calibrationPartOptionsHtml(target, this.config.calibration_part)}</select>
        </label>
        <label>Step
          <select class="cv-cal-select" data-cv-field="step">
            <option value="1" ${step === 1 ? "selected" : ""}>1px</option>
            <option value="5" ${step === 5 ? "selected" : ""}>5px</option>
            <option value="10" ${step === 10 ? "selected" : ""}>10px</option>
          </select>
        </label>
      </div>
      <div class="cv-cal-tools-row cv-cal-port-manager-row cv-cal-port-manager-main">
        <span class="cv-cal-quick-label">Port manager</span>
        <button type="button" data-cv-action="add-port">Add port</button>
        <button type="button" data-cv-action="duplicate-port">Duplicate port</button>
        <label>Port number<input class="cv-cal-input" data-cv-field="port-number" type="number" min="1" step="1" value="${editable?.type === "port" ? htmlEscape(editable.key) : ""}" ${editable?.type === "port" ? "" : "disabled"}></label>
        <button type="button" data-cv-action="rename-port" ${editable?.type === "port" ? "" : "disabled"}>Rename</button>
        <button type="button" data-cv-action="remove-port" ${editable?.type === "port" ? "" : "disabled"}>Remove port</button>
        <span class="cv-cal-current">${sortedCalibrationPortKeys(cal).length} visual ports</span>
      </div></div></details>
      <details class="cv-cal-section" data-cv-section="quick-selection" ${this.calibrationSectionOpen("quick-selection", false) ? "open" : ""}><summary><span>Quick Selection</span><small>${htmlEscape(targetText)}</small></summary><div class="cv-cal-section-body">
      <div class="cv-cal-tools-row cv-cal-quick-row">
        <span class="cv-cal-quick-label">Quick select</span>
        <button type="button" data-cv-action="select-target" data-target="logo" data-part="box">Logo</button>
        <button type="button" data-cv-action="select-target" data-target="status_box" data-part="box">Status Box 1</button>
        <button type="button" data-cv-action="select-target" data-target="status_box_2" data-part="box">Status Box 2</button>
        <button type="button" data-cv-action="select-target" data-target="calibration_button" data-part="box">Calibration button</button>
        <button type="button" data-cv-action="select-target" data-target="status_fields" data-part="field">All Status Box 1 fields</button>
        <button type="button" data-cv-action="select-target" data-target="status_fields_2" data-part="field">All Status Box 2 fields</button>
        <button type="button" data-cv-action="select-target" data-target="ports" data-part="center">All ports</button>
        <button type="button" data-cv-action="select-target" data-target="sfps" data-part="center">All SFP</button>
        <button type="button" data-cv-action="select-target" data-target="status_leds" data-part="center">All status</button>
        <button type="button" data-cv-action="select-target" data-target="ports_led_left" data-part="led_left">All link/speed</button>
        <button type="button" data-cv-action="select-target" data-target="ports_led_right" data-part="led_right">All activity</button>
        <button type="button" data-cv-action="select-target" data-target="ports_numbers" data-part="number">All numbers</button>
      </div>
      <div class="cv-cal-tools-row cv-cal-parity-row">
        <span class="cv-cal-quick-label">Odd</span>
        <button type="button" data-cv-action="select-target" data-target="ports_odd_center" data-part="center">All odd ports</button>
        <button type="button" data-cv-action="select-target" data-target="ports_odd_led_left" data-part="led_left">Odd link LEDs</button>
        <button type="button" data-cv-action="select-target" data-target="ports_odd_led_right" data-part="led_right">Odd activity LEDs</button>
        <button type="button" data-cv-action="select-target" data-target="ports_odd_numbers" data-part="number">Odd port numbers</button>
        <span class="cv-cal-parity-divider" aria-hidden="true"></span>
        <span class="cv-cal-quick-label">Even</span>
        <button type="button" data-cv-action="select-target" data-target="ports_even_center" data-part="center">All even ports</button>
        <button type="button" data-cv-action="select-target" data-target="ports_even_led_left" data-part="led_left">Even link LEDs</button>
        <button type="button" data-cv-action="select-target" data-target="ports_even_led_right" data-part="led_right">Even activity LEDs</button>
        <button type="button" data-cv-action="select-target" data-target="ports_even_numbers" data-part="number">Even port numbers</button>
      </div>
      <div class="cv-cal-tools-row cv-cal-custom-port-row">
        <span class="cv-cal-quick-label">Custom ports</span>
        <input class="cv-cal-input cv-cal-port-list-input" data-cv-field="custom-port-list" value="${htmlEscape(String(this.config.calibration_port_selection || ""))}" placeholder="1,3,5,6,11,21 or 1-6,11">
        <label>Part
          <select class="cv-cal-select" data-cv-field="custom-port-part">
            <option value="center" ${String(this.config.calibration_part || "center") === "center" ? "selected" : ""}>Ports</option>
            <option value="led_left" ${String(this.config.calibration_part || "") === "led_left" ? "selected" : ""}>Link LEDs</option>
            <option value="led_right" ${String(this.config.calibration_part || "") === "led_right" ? "selected" : ""}>Activity LEDs</option>
            <option value="number" ${String(this.config.calibration_part || "") === "number" ? "selected" : ""}>Port numbers</option>
          </select>
        </label>
        <button type="button" data-cv-action="select-custom-ports">Select</button>
        <span class="cv-cal-current">${htmlEscape(String(this.config.calibration_port_selection_summary || "Enter port numbers or ranges"))}</span>
      </div>
      </div></details>
      <details class="cv-cal-section" data-cv-section="position-size" ${this.calibrationSectionOpen("position-size", false) ? "open" : ""}><summary><span>Position and Size</span><small>${htmlEscape(targetText)} · step ${step}px</small></summary><div class="cv-cal-section-body"><div class="cv-cal-tools-row cv-cal-nudge-grid">
        <button type="button" data-cv-action="move" data-dx="0" data-dy="-${step}">↑</button>
        <button type="button" data-cv-action="move" data-dx="-${step}" data-dy="0">←</button>
        <button type="button" data-cv-action="move" data-dx="${step}" data-dy="0">→</button>
        <button type="button" data-cv-action="move" data-dx="0" data-dy="${step}">↓</button>
        <button type="button" data-cv-action="size" data-dw="-${step}" data-dh="0" ${hitbox ? "" : "disabled"}>W−</button>
        <button type="button" data-cv-action="size" data-dw="${step}" data-dh="0" ${hitbox ? "" : "disabled"}>W+</button>
        <button type="button" data-cv-action="size" data-dw="0" data-dh="-${step}" ${hitbox ? "" : "disabled"}>H−</button>
        <button type="button" data-cv-action="size" data-dw="0" data-dh="${step}" ${hitbox ? "" : "disabled"}>H+</button>
      </div></div></details>
      <div class="cv-cal-profile-controls" data-cv-profile-controls>
        <div class="cv-cal-tools-row">
          <span class="cv-cal-current">${htmlEscape(profileName)} · ${htmlEscape(profileLoadedText)}</span>
          <button type="button" data-cv-action="copy">Copy JSON</button>
          <button type="button" data-cv-action="download-profile">Download Profile</button>
          <button type="button" data-cv-action="import-profile">Import Profile</button>
          <input type="file" data-cv-profile-file accept="application/json,.json" hidden>
          <button type="button" data-cv-action="toggle-json">${showExportJson ? "Hide JSON" : "Show JSON"}</button>
          <button type="button" data-cv-action="load-profile" title="Fallback: reload the saved profile from Home Assistant storage into this calibration session">Reload Saved Profile</button>
          <button type="button" data-cv-action="save-profile">Save Profile</button>
          <button type="button" data-cv-action="reset-target">Reset target</button>
          <button type="button" data-cv-action="reset-all">Reset all</button>
          ${saveStatusHtml}
        </div>
        ${showExportJson ? `<textarea class="cv-cal-export" readonly spellcheck="false">${htmlEscape(exportJson)}</textarea>` : ""}
      </div>
    </div>`;
  }

  redrawSwitchSvg(activeCalibration = null) {
    if (!this.shadowRoot) return;
    const svg = this.shadowRoot.getElementById("s");
    if (!svg) return;

    const cal = activeCalibration || this.calibrationData();
    while (svg.firstChild) svg.removeChild(svg.firstChild);

    drawPanel(svg, {
      hass: this._hass,
      config: this.config,
      calibration: cal,
      layout
    });

    drawCalibrationOverlay(svg, {
      config: this.config,
      calibration: cal,
      layout
    });

    this.attachSelectionHandlers(svg, cal);
  }

  render() {
    if (!this.shadowRoot) this.attachShadow({ mode: "open" });
    this.saveCalibrationExportSize();

    const baseTitle = String(this.config.title || "Switch Vision").trim();
    const memberTitle = String(this.config.member || "").trim();
    const baseEndsWithMember = memberTitle && baseTitle.toLowerCase().endsWith(memberTitle.toLowerCase());
    const title = memberTitle && !baseEndsWithMember ? `${baseTitle} • ${memberTitle}` : baseTitle;
    const activeCalibration = this.calibrationData();

    this.shadowRoot.innerHTML = `<link rel="stylesheet" href="/local/switch-vision/css/switch-vision.css?v=${SV_VERSION}">
      <div class="cv-card" tabindex="0">
        <div class="cv-header">
          <div class="cv-title">${title}</div>
          <div class="cv-status">v${SV_VERSION} · ${calibrationEnabled(this.config) ? (calibrationControlsEnabled(this.config) ? "interactive calibration" : "calibration") : (this.config.demo ? "demo" : "live")} · 2048 × 448</div>
        </div>
        ${this.calibrationControls(activeCalibration)}
        <div class="cv-stage">
          ${this.calibrationButton()}
          <img class="cv-image" data-cv-faceplate-image src="${activeCalibration.ui?.faceplate?.show !== false && ![SV_ASSET_DEFAULT, SV_ASSET_NONE].includes(String(activeCalibration.ui?.faceplate?.file || SV_ASSET_DEFAULT)) ? assetUrl("faceplates", activeCalibration.ui.faceplate.file) : `/local/switch-vision/faceplates/sv-dark.png?v=${SV_VERSION}`}" style="object-fit:${htmlEscape(activeCalibration.ui?.faceplate?.fit || "fill")};opacity:${Math.max(0, Math.min(1, Number(activeCalibration.ui?.faceplate?.opacity ?? 1)))}">
          <svg class="cv-svg" viewBox="0 0 2048 448" preserveAspectRatio="xMidYMid meet" id="s"></svg>
        </div>
        ${this.legend()}
      </div>`;

    this.redrawSwitchSvg(activeCalibration);
    this.attachCalibrationControlHandlers(activeCalibration);
    this.attachCalibrationButtonHandler();
    const faceplateImage = this.shadowRoot.querySelector("[data-cv-faceplate-image]");
    const info = this.shadowRoot.querySelector("[data-cv-faceplate-info]");
    if (faceplateImage && info) {
      const updateInfo = () => { const w = faceplateImage.naturalWidth || 0; const h = faceplateImage.naturalHeight || 0; info.textContent = w && h ? `Detected image: ${w} × ${h} px · Aspect ratio ${(w/h).toFixed(2)}:1${w < 2048 ? " · Recommended width: 2048 px" : ""}` : "Detected image dimensions unavailable"; };
      if (faceplateImage.complete) updateInfo(); else faceplateImage.addEventListener("load", updateInfo, {once:true});
    }
    this.applyCalibrationExportSize();
  }

  nudgeCalibrationTarget(cal, dx, dy) {
    const editable = getEditableCalibrationTarget(cal, this.config);
    if (!editable) return false;

    if (editable.type === "logo") {
      editable.item.x = Math.round((Number(editable.item.x) + dx) * 10) / 10;
      editable.item.y = Math.round((Number(editable.item.y) + dy) * 10) / 10;
      return true;
    }

    if (editable.type === "calibration_button") {
      editable.item.x = Math.round((Number(editable.item.x) + dx) * 10) / 10;
      editable.item.y = Math.round((Number(editable.item.y) + dy) * 10) / 10;
      return true;
    }

    if (editable.type === "status_box" || editable.type === "status_box_2") {
      editable.item.x = Math.round((Number(editable.item.x) + dx) * 10) / 10;
      editable.item.y = Math.round((Number(editable.item.y) + dy) * 10) / 10;
      return true;
    }

    if (editable.group && (editable.type === "status_fields" || editable.type === "status_fields_2")) {
      const p = editable.type === "status_fields_2" ? cal.ui.status_panel_2 : cal.ui.status_panel;
      for (const xy of Object.values(p.fields || {})) movePoint(xy, dx, dy);
      return true;
    }

    if (editable.group && editable.type === "ports") {
      for (const key of calibrationPortKeysForEditable(cal, editable)) movePoint(cal.ports?.[key]?.[editable.part], dx, dy);
      return true;
    }

    if (editable.group && editable.type === "sfps") {
      for (const sfp of Object.values(cal.sfp || {})) movePoint(sfp?.center, dx, dy);
      return true;
    }

    if (editable.group && editable.type === "status_leds") {
      for (const [name, xy] of Object.entries(cal.status_leds || {})) {
        if (String(name).toUpperCase() === "MODE") continue;
        movePoint(xy, dx, dy);
      }
      return true;
    }

    if (editable.point) {
      movePoint(editable.point, dx, dy);
      return true;
    }

    return false;
  }

  resizeCalibrationTarget(cal, dw, dh) {
    const editable = getEditableCalibrationTarget(cal, this.config);
    if (!editable) return false;

    const resizeHitbox = (hitbox) => {
      if (!hitbox) return;
      hitbox[0] = Math.max(8, Math.round((Number(hitbox[0]) + dw) * 10) / 10);
      hitbox[1] = Math.max(8, Math.round((Number(hitbox[1]) + dh) * 10) / 10);
    };

    if (["logo", "status_box", "status_box_2", "calibration_button"].includes(editable.type)) {
      editable.item.width = Math.max(8, Math.round((Number(editable.item.width) + dw) * 10) / 10);
      editable.item.height = Math.max(8, Math.round((Number(editable.item.height) + dh) * 10) / 10);
      return true;
    }

    if (editable.group && editable.type === "ports" && editable.part === "center") {
      for (const key of calibrationPortKeysForEditable(cal, editable)) resizeHitbox(cal.ports?.[key]?.hitbox);
      return true;
    }

    if (editable.group && editable.type === "sfps") {
      for (const sfp of Object.values(cal.sfp || {})) resizeHitbox(sfp?.hitbox);
      return true;
    }

    if (editable.item?.hitbox) {
      resizeHitbox(editable.item.hitbox);
      return true;
    }

    return false;
  }

  attachCalibrationControlHandlers(cal) {
    if (!calibrationControlsEnabled(this.config) || !this.shadowRoot) return;

    for (const section of this.shadowRoot.querySelectorAll("details[data-cv-section]")) {
      section.addEventListener("toggle", () => {
        this._calibrationSectionState = this._calibrationSectionState || {};
        this._calibrationSectionState[section.getAttribute("data-cv-section")] = section.open;
      });
    }

    const targetSelect = this.shadowRoot.querySelector('[data-cv-field="target"]');
    if (targetSelect) {
      targetSelect.addEventListener("change", (event) => {
        const value = event.target.value;
        const part = value === "ports_led_left" ? "led_left" : (value === "ports_led_right" ? "led_right" : (value === "ports_numbers" ? "number" : "center"));
        this.config = { ...this.config, calibration_target: value, calibration_part: part };
        this.render();
      });
    }

    const partSelect = this.shadowRoot.querySelector('[data-cv-field="part"]');
    if (partSelect) {
      partSelect.addEventListener("change", (event) => {
        this.config = { ...this.config, calibration_part: event.target.value };
        this.render();
      });
    }

    const stepSelect = this.shadowRoot.querySelector('[data-cv-field="step"]');
    if (stepSelect) {
      stepSelect.addEventListener("change", (event) => {
        this.config = { ...this.config, calibration_step: Number(event.target.value || 1) };
        this.render();
      });
    }


    const statusFontSelect = this.shadowRoot.querySelector('[data-cv-field="status-font"]');
    if (statusFontSelect) {
      statusFontSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        cal.ui.status_panel.font_family = event.target.value;
        this.markCalibrationDirty();
        this.render();
      });
    }

    const statusFontSizeSelect = this.shadowRoot.querySelector('[data-cv-field="status-font-size"]');
    if (statusFontSizeSelect) {
      statusFontSizeSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        cal.ui.status_panel.font_size = Number(event.target.value || 16);
        this.markCalibrationDirty();
        this.render();
      });
    }


    const statusTextColorSelect = this.shadowRoot.querySelector('[data-cv-field="status-text-color"]');
    if (statusTextColorSelect) {
      statusTextColorSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        cal.ui.status_panel.text_color = event.target.value;
        cal.ui.status_panel.label_color = event.target.value;
        cal.ui.status_panel.title_color = event.target.value;
        this.markCalibrationDirty();
        this.render();
      });
    }

    const statusBoxColorSelect = this.shadowRoot.querySelector('[data-cv-field="status-box-color"]');
    if (statusBoxColorSelect) {
      statusBoxColorSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        cal.ui.status_panel.background_color = event.target.value;
        this.markCalibrationDirty();
        this.render();
      });
    }

    const bindPanelStyleControls = (prefix, panelKey, configPrefix = null) => {
      const font = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-font"]`);
      const fontSize = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-font-size"]`);
      const textColor = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-text-color"]`);
      const boxColor = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-box-color"]`);
      const borderShow = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-border-show"]`);
      const borderColor = this.shadowRoot.querySelector(`[data-cv-field="${prefix}-border-color"]`);
      const setConfigOverride = (name, value) => {
        if (!configPrefix) return;
        this.config = { ...this.config, [`${configPrefix}_${name}`]: value };
      };
      // ensureCalibrationUi() replaces the nested panel objects while merging
      // defaults. Resolve the live panel after that merge for every event instead
      // of mutating a stale object captured when the handlers were attached.
      const update = (fn) => (event) => {
        ensureCalibrationUi(cal);
        const panel = cal.ui?.[panelKey];
        if (!panel) return;
        fn(event, panel);
        this.markCalibrationDirty();
        this.render();
      };
      if (font) font.addEventListener("change", update((event, panel) => { panel.font_family = event.target.value; setConfigOverride("font_family", panel.font_family); }));
      if (fontSize) fontSize.addEventListener("change", update((event, panel) => { panel.font_size = Number(event.target.value || 16); setConfigOverride("font_size", panel.font_size); }));
      if (textColor) textColor.addEventListener("change", update((event, panel) => {
        panel.text_color = event.target.value;
        panel.label_color = event.target.value;
        panel.title_color = event.target.value;
        setConfigOverride("text_color", panel.text_color);
        setConfigOverride("label_color", panel.label_color);
        setConfigOverride("title_color", panel.title_color);
      }));
      if (boxColor) boxColor.addEventListener("change", update((event, panel) => { panel.background_color = event.target.value; setConfigOverride("background_color", panel.background_color); }));
      if (borderShow) borderShow.addEventListener("change", update((event, panel) => {
        panel.border_show = event.target.checked === true;
        // Match Status Box 1: the calibration profile is the source of truth.
        // Remove any stale card-level override left by older handlers, otherwise
        // statusPanelUi() could keep reading that value after the profile changes.
        if (configPrefix) {
          const next = { ...this.config };
          delete next[`${configPrefix}_border_show`];
          this.config = next;
        }
      }));
      if (borderColor) borderColor.addEventListener("change", update((event, panel) => {
        panel.border_color = String(event.target.value || "rgba(245,248,250,.75)");
        if (configPrefix) {
          const next = { ...this.config };
          delete next[`${configPrefix}_border_color`];
          this.config = next;
        }
      }));
    };
    // Status Box 2 uses the same profile values as the renderer, with card-level
    // overrides kept in sync for the non-border style controls.
    bindPanelStyleControls("status2", "status_panel_2", "status_panel_2");
    const statusBorderShow = this.shadowRoot.querySelector('[data-cv-field="status-border-show"]');
    if (statusBorderShow) statusBorderShow.addEventListener("change", (event) => { cal.ui.status_panel.border_show = event.target.checked === true; this.markCalibrationDirty(); this.render(); });
    const statusBorderColor = this.shadowRoot.querySelector('[data-cv-field="status-border-color"]');
    if (statusBorderColor) statusBorderColor.addEventListener("change", (event) => { cal.ui.status_panel.border_color = event.target.value; this.markCalibrationDirty(); this.render(); });

    const statusRowFieldSelect = this.shadowRoot.querySelector('[data-cv-field="status-row-field"]');
    if (statusRowFieldSelect) {
      statusRowFieldSelect.addEventListener("change", (event) => {
        this.config = { ...this.config, status_panel_selected_field: event.target.value };
        this.render();
      });
    }



    const status2RowFieldSelect = this.shadowRoot.querySelector('[data-cv-field="status2-row-field"]');
    if (status2RowFieldSelect) status2RowFieldSelect.addEventListener("change", (event) => { this.config = { ...this.config, status_panel_2_selected_field: event.target.value }; this.render(); });

    const portStatusRowFieldSelect = this.shadowRoot.querySelector('[data-cv-field="port-status-row-field"]');
    if (portStatusRowFieldSelect) portStatusRowFieldSelect.addEventListener("change", (event) => { this.config = { ...this.config, port_status_selected_field: event.target.value }; this.render(); });

    const switchIpInput = this.shadowRoot.querySelector('[data-cv-field="switch-ip"]');
    if (switchIpInput) {
      const updateSwitchIp = () => {
        ensureCalibrationManagement(cal);
        const value = String(switchIpInput.value || "").trim();
        cal.management.switch_ip = value;
        this.markCalibrationDirty();
        this.render();
      };
      switchIpInput.addEventListener("change", updateSwitchIp);
      switchIpInput.addEventListener("blur", updateSwitchIp);
    }

    const stackEnabledInput = this.shadowRoot.querySelector('[data-cv-field="stack-enabled"]');
    if (stackEnabledInput) {
      stackEnabledInput.addEventListener("change", (event) => {
        ensureCalibrationStack(cal);
        cal.stack.enabled = event.target.checked === true;
        this.config = { ...this.config, stack_enabled: cal.stack.enabled };
        this.markCalibrationDirty();
        this.render();
      });
    }

    const stackMemberSelect = this.shadowRoot.querySelector('[data-cv-field="stack-member-number"]');
    if (stackMemberSelect) {
      stackMemberSelect.addEventListener("change", (event) => {
        ensureCalibrationStack(cal);
        const key = normalizePanelMember(this.config).toUpperCase();
        cal.stack.members[key] = cal.stack.members[key] || {};
        cal.stack.members[key].member_number = Number(event.target.value || "") || "";
        this.config = { ...this.config, stack_member_number: cal.stack.members[key].member_number || null };
        this.markCalibrationDirty();
        this.render();
      });
    }

    const stackModeSelect = this.shadowRoot.querySelector('[data-cv-field="stack-uptime-mode"]');
    if (stackModeSelect) {
      stackModeSelect.addEventListener("change", (event) => {
        ensureCalibrationStack(cal);
        const key = normalizePanelMember(this.config).toUpperCase();
        cal.stack.members[key] = cal.stack.members[key] || {};
        cal.stack.members[key].uptime_mode = normaliseStackUptimeMode(event.target.value);
        this.config = { ...this.config, stack_uptime_mode: cal.stack.members[key].uptime_mode };
        this.markCalibrationDirty();
        this.render();
      });
    }

    const stackSourceInput = this.shadowRoot.querySelector('[data-cv-field="stack-uptime-source"]');
    if (stackSourceInput) {
      const updateStackSource = () => {
        ensureCalibrationStack(cal);
        const value = String(stackSourceInput.value || "").trim();
        const key = normalizePanelMember(this.config).toUpperCase();
        cal.stack.uptime_source = value;
        cal.stack.members[key] = cal.stack.members[key] || {};
        cal.stack.members[key].uptime_source = value;
        this.config = { ...this.config, stack_uptime_source: value, stack_member_uptime_source: value };
        this.markCalibrationDirty();
        this.render();
      };
      stackSourceInput.addEventListener("change", updateStackSource);
      stackSourceInput.addEventListener("blur", updateStackSource);
    }

    const logoFileSelect = this.shadowRoot.querySelector('[data-cv-field="logo-file"]');
    if (logoFileSelect) {
      logoFileSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        const value = String(event.target.value || SV_ASSET_DEFAULT);
        if (value === SV_ASSET_NONE) {
          cal.ui.logo.show = false;
          cal.ui.logo.source = "none";
        } else if (value === SV_ASSET_DEFAULT) {
          cal.ui.logo.show = true;
          cal.ui.logo.source = "default";
          cal.ui.logo.file = layout.logo?.file || "sv-logo.png";
        } else {
          cal.ui.logo.show = true;
          cal.ui.logo.source = "custom";
          cal.ui.logo.file = safeAssetFilename(value);
        }
        this.markCalibrationDirty();
        this.render();
      });
    }

    const faceplateFileSelect = this.shadowRoot.querySelector('[data-cv-field="faceplate-file"]');
    if (faceplateFileSelect) {
      faceplateFileSelect.addEventListener("change", (event) => {
        ensureCalibrationUi(cal);
        const value = String(event.target.value || SV_ASSET_DEFAULT);
        if (value === SV_ASSET_NONE) {
          cal.ui.faceplate.show = false;
          cal.ui.faceplate.file = SV_ASSET_NONE;
        } else if (value === SV_ASSET_DEFAULT) {
          cal.ui.faceplate.show = false;
          cal.ui.faceplate.file = SV_ASSET_DEFAULT;
        } else {
          cal.ui.faceplate.show = true;
          cal.ui.faceplate.file = safeAssetFilename(value);
        }
        this.markCalibrationDirty();
        this.render();
      });
    }

    const exportTextarea = this.shadowRoot.querySelector('.cv-cal-export');
    if (exportTextarea) {
      const saveSize = () => this.saveCalibrationExportSize();
      exportTextarea.addEventListener("pointerup", saveSize);
      exportTextarea.addEventListener("mouseup", saveSize);
      exportTextarea.addEventListener("blur", saveSize);
      exportTextarea.addEventListener("input", saveSize);
    }

    for (const button of this.shadowRoot.querySelectorAll('[data-cv-action]')) {
      button.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const action = button.getAttribute("data-cv-action");
        const editable = getEditableCalibrationTarget(cal, this.config);

        if (action === "refresh-assets") {
          this._assetLibrary = null;
          await this.maybeLoadAssetLibrary(true);
          this.setCalibrationSaveStatus("Asset folders refreshed", false);
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "select-custom-ports") {
          const input = this.shadowRoot.querySelector('[data-cv-field="custom-port-list"]');
          const partInput = this.shadowRoot.querySelector('[data-cv-field="custom-port-part"]');
          const parsed = parseCalibrationPortSelection(input?.value, cal);
          const part = String(partInput?.value || "center");

          if (!parsed.keys.length) {
            const details = parsed.invalid.length
              ? `Invalid: ${parsed.invalid.join(", ")}`
              : (parsed.missing.length ? `Ports not present: ${parsed.missing.join(", ")}` : "Enter at least one existing port");
            this.setCalibrationSaveStatus(details, true);
            this.clearCalibrationSaveStatusSoon();
            return;
          }

          const skipped = [];
          if (parsed.invalid.length) skipped.push(`invalid ${parsed.invalid.join(", ")}`);
          if (parsed.missing.length) skipped.push(`missing ${parsed.missing.join(", ")}`);
          const summary = `Selected ${parsed.keys.length}: ${parsed.keys.join(", ")}${skipped.length ? ` · skipped ${skipped.join("; ")}` : ""}`;

          this.config = {
            ...this.config,
            calibration_target: "ports_custom",
            calibration_part: part,
            calibration_port_selection: parsed.normalised,
            calibration_port_selection_summary: summary
          };
          this.setCalibrationSaveStatus(summary, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "select-target") {
          const nextTarget = button.getAttribute("data-target") || "ports";
          const nextPart = button.getAttribute("data-part") || "center";
          this.config = { ...this.config, calibration_target: nextTarget, calibration_part: nextPart };
          this.render();
          return;
        }

        if (action === "add-port" || action === "duplicate-port") {
          const selected = editable?.type === "port" ? editable.key : sortedCalibrationPortKeys(cal).at(-1);
          const newKey = String(nextCalibrationPortNumber(cal));
          cloneCalibrationPort(cal, selected, newKey, action === "add-port" ? 12 : 0, 0);
          this.config = { ...this.config, calibration_target: `port:${newKey}`, calibration_part: "center" };
          this.markCalibrationDirty();
          this.setCalibrationSaveStatus(`${action === "add-port" ? "Added" : "Duplicated"} visual port ${newKey}`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "rename-port" && editable?.type === "port") {
          const input = this.shadowRoot.querySelector('[data-cv-field="port-number"]');
          const next = String(Math.max(1, Math.trunc(Number(input?.value || 0))));
          if (!next || next === "NaN") return;
          if (next !== editable.key && cal.ports?.[next]) {
            this.setCalibrationSaveStatus(`Port ${next} already exists`, true);
            this.clearCalibrationSaveStatusSoon();
            return;
          }
          if (next !== editable.key) {
            cal.ports[next] = cal.ports[editable.key];
            delete cal.ports[editable.key];
          }
          this.config = { ...this.config, calibration_target: `port:${next}`, calibration_part: this.config.calibration_part || "center" };
          this.markCalibrationDirty();
          this.setCalibrationSaveStatus(`Renamed visual port ${editable.key} to ${next}`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "remove-port" && editable?.type === "port") {
          const keys = sortedCalibrationPortKeys(cal);
          if (keys.length <= 1) {
            this.setCalibrationSaveStatus("At least one visual port must remain", true);
            this.clearCalibrationSaveStatusSoon();
            return;
          }
          if (!window.confirm(`Remove visual port ${editable.key} from this calibration profile? Home Assistant and SNMP2MQTT entities will not be deleted.`)) return;
          const oldIndex = keys.indexOf(editable.key);
          delete cal.ports[editable.key];
          const remaining = sortedCalibrationPortKeys(cal);
          const nextKey = remaining[Math.min(Math.max(oldIndex, 0), remaining.length - 1)] || remaining[0];
          this.config = { ...this.config, calibration_target: `port:${nextKey}`, calibration_part: "center" };
          this.markCalibrationDirty();
          this.setCalibrationSaveStatus(`Removed visual port ${editable.key}`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "select-status-row") {
          const field = String(button.getAttribute("data-field") || "model");
          this.config = { ...this.config, status_panel_selected_field: field };
          this.render();
          return;
        }

        if (action === "toggle-status-bold" || action === "toggle-status2-bold") {
          ensureCalibrationUi(cal);
          const panel = action === "toggle-status2-bold" ? cal.ui.status_panel_2 : cal.ui.status_panel;
          const current = String(panel.font_weight || "normal");
          panel.font_weight = (current === "bold" || Number(current) >= 600) ? "normal" : "bold";
          if (action === "toggle-status2-bold") {
            this.config = { ...this.config, status_panel_2_font_weight: panel.font_weight };
          }
          this.markCalibrationDirty();
          this.render();
          return;
        }

        if (["status2-row-up", "status2-row-down", "status2-row-toggle"].includes(action)) {
          ensureCalibrationUi(cal);
          const panel = ensureStatusPanelFieldState(cal.ui.status_panel_2);
          const defs = STATUS_PANEL_ROW_DEFS.switch;
          const selected = defs.defaults.includes(String(this.config.status_panel_2_selected_field || "").toLowerCase()) ? String(this.config.status_panel_2_selected_field).toLowerCase() : normaliseStatusPanelFieldOrder(panel.field_order?.switch, "switch")[0];
          const order = normaliseStatusPanelFieldOrder(panel.field_order?.switch, "switch");
          panel.field_order.switch = order; panel.hidden_fields.switch = fieldListFromValue(panel.hidden_fields?.switch) || [];
          if (action === "status2-row-toggle") { const hidden = new Set(panel.hidden_fields.switch); if (hidden.has(selected)) hidden.delete(selected); else hidden.add(selected); panel.hidden_fields.switch = [...hidden].filter((field) => defs.defaults.includes(field)); this.markCalibrationDirty(); }
          if (action === "status2-row-up" || action === "status2-row-down") { const idx = order.indexOf(selected); const swap = action === "status2-row-up" ? idx - 1 : idx + 1; if (idx >= 0 && swap >= 0 && swap < order.length) { [order[idx], order[swap]] = [order[swap], order[idx]]; panel.field_order.switch = order; this.markCalibrationDirty(); } }
          this.render(); return;
        }

        if (["port-status-row-up", "port-status-row-down", "port-status-row-toggle"].includes(action)) {
          ensureCalibrationUi(cal);
          const panel = ensureStatusPanelFieldState(cal.ui.status_panel);
          const defs = STATUS_PANEL_ROW_DEFS.port;
          const selected = defs.defaults.includes(String(this.config.port_status_selected_field || "").toLowerCase())
            ? String(this.config.port_status_selected_field).toLowerCase()
            : normaliseStatusPanelFieldOrder(panel.field_order?.port, "port")[0];
          const order = normaliseStatusPanelFieldOrder(panel.field_order?.port, "port");
          panel.field_order.port = order;
          panel.hidden_fields.port = fieldListFromValue(panel.hidden_fields?.port) || [];
          if (action === "port-status-row-toggle") {
            const hidden = new Set(panel.hidden_fields.port);
            if (hidden.has(selected)) hidden.delete(selected); else hidden.add(selected);
            panel.hidden_fields.port = [...hidden].filter((field) => defs.defaults.includes(field));
            this.markCalibrationDirty();
          }
          if (action === "port-status-row-up" || action === "port-status-row-down") {
            const idx = order.indexOf(selected);
            const swap = action === "port-status-row-up" ? idx - 1 : idx + 1;
            if (idx >= 0 && swap >= 0 && swap < order.length) {
              [order[idx], order[swap]] = [order[swap], order[idx]];
              panel.field_order.port = order;
              this.markCalibrationDirty();
            }
          }
          this.render(); return;
        }

        if (["status-row-up", "status-row-down", "status-row-toggle"].includes(action)) {
          ensureCalibrationUi(cal);
          const panel = ensureStatusPanelFieldState(cal.ui.status_panel);
          const rowType = "switch";
          const defs = STATUS_PANEL_ROW_DEFS.switch;
          const selected = defs.defaults.includes(String(this.config.status_panel_selected_field || "").toLowerCase())
            ? String(this.config.status_panel_selected_field).toLowerCase()
            : normaliseStatusPanelFieldOrder(panel.field_order?.[rowType], rowType)[0];
          const order = normaliseStatusPanelFieldOrder(panel.field_order?.[rowType], rowType);
          panel.field_order[rowType] = order;
          panel.hidden_fields[rowType] = fieldListFromValue(panel.hidden_fields?.[rowType]) || [];

          if (action === "status-row-toggle") {
            const hidden = new Set(panel.hidden_fields[rowType]);
            if (hidden.has(selected)) hidden.delete(selected);
            else hidden.add(selected);
            panel.hidden_fields[rowType] = [...hidden].filter((field) => defs.defaults.includes(field));
            this.markCalibrationDirty();
          }

          if (action === "status-row-up" || action === "status-row-down") {
            const idx = order.indexOf(selected);
            const swap = action === "status-row-up" ? idx - 1 : idx + 1;
            if (idx >= 0 && swap >= 0 && swap < order.length) {
              [order[idx], order[swap]] = [order[swap], order[idx]];
              panel.field_order[rowType] = order;
              this.markCalibrationDirty();
            }
          }

          this.render();
          return;
        }

        if (action === "move") {
          const dx = Number(button.getAttribute("data-dx") || 0);
          const dy = Number(button.getAttribute("data-dy") || 0);
          if (this.nudgeCalibrationTarget(cal, dx, dy)) {
            this.markCalibrationDirty();
            this.render();
            return;
          }
        }

        if (action === "size") {
          const dw = Number(button.getAttribute("data-dw") || 0);
          const dh = Number(button.getAttribute("data-dh") || 0);
          if (this.resizeCalibrationTarget(cal, dw, dh)) {
            this.markCalibrationDirty();
            this.render();
            return;
          }
        }

        if (action === "reset-target" && editable) {
          const original = cloneCalibrationData(calibration);
          if (editable.type === "ports") cal.ports = original.ports;
          if (editable.type === "sfps") cal.sfp = original.sfp;
          if (editable.type === "status_leds") cal.status_leds = original.status_leds;
          if (editable.type === "port" && original.ports?.[editable.key]) cal.ports[editable.key] = original.ports[editable.key];
          if (editable.type === "sfp" && original.sfp?.[editable.key]) cal.sfp[editable.key] = original.sfp[editable.key];
          if (editable.type === "status" && original.status_leds?.[editable.key]) cal.status_leds[editable.key] = original.status_leds[editable.key];
          if (editable.type === "logo") cal.ui.logo = original.ui.logo;
          if (editable.type === "calibration_button") cal.ui.calibration_button = original.ui.calibration_button;
          if (editable.type === "status_box") cal.ui.status_panel = original.ui.status_panel;
          if (editable.type === "status_box_2") cal.ui.status_panel_2 = original.ui.status_panel_2;
          if (editable.type === "status_fields") {
            cal.ui.status_panel.fields = original.ui.status_panel.fields;
            cal.ui.status_panel.field_order = original.ui.status_panel.field_order;
            cal.ui.status_panel.hidden_fields = original.ui.status_panel.hidden_fields;
          }
          if (editable.type === "status_fields_2") {
            cal.ui.status_panel_2.fields = original.ui.status_panel_2.fields;
            cal.ui.status_panel_2.field_order = original.ui.status_panel_2.field_order;
            cal.ui.status_panel_2.hidden_fields = original.ui.status_panel_2.hidden_fields;
          }
          if (editable.type === "status_field" && original.ui.status_panel.fields?.[editable.key]) cal.ui.status_panel.fields[editable.key] = original.ui.status_panel.fields[editable.key];
          if (editable.type === "status_field_2" && original.ui.status_panel_2.fields?.[editable.key]) cal.ui.status_panel_2.fields[editable.key] = original.ui.status_panel_2.fields[editable.key];
          this.markCalibrationDirty();
          this.render();
          return;
        }

        if (action === "reset-all") {
          const original = cloneCalibrationData(calibration);
          cal.ports = original.ports;
          cal.sfp = original.sfp;
          cal.status_leds = original.status_leds;
          cal.ui = original.ui;
          ensureCalibrationUi(cal);

          // Reset status boxes to the canonical shared defaults explicitly.
          // This clears legacy absolute row/value coordinates that could survive
          // older profiles and push values against the right edge.
          for (const [panelKey, panelNumber] of [["status_panel", 1], ["status_panel_2", 2]]) {
            const panel = cal.ui[panelKey];
            panel.font_family = "SwitchVisionCustom, Arial, Helvetica, sans-serif";
            panel.font_size = 16;
            panel.font_weight = "bold";
            panel.fields = {};
            for (const [fieldKey, _label, fallback] of STATUS_PANEL_FIELD_DEFS) {
              const reference = statusPanelFieldReference(fieldKey, panelNumber, fallback);
              panel.fields[fieldKey] = [Number(reference[0]), Number(reference[1])];
            }
          }

          cal.ui.status_panel_2.field_order.switch = [
            "vendor", "uptime",
            ...STATUS_PANEL_ROW_DEFS.switch.defaults.filter((field) => !["vendor", "uptime"].includes(field))
          ];
          cal.ui.status_panel_2.hidden_fields.switch = STATUS_PANEL_ROW_DEFS.switch.defaults
            .filter((field) => !["vendor", "uptime"].includes(field));

          this.markCalibrationDirty();
          this.render();
          return;
        }

        if (action === "apply-recommended-setup") {
          const info = this.visualRecommendation(cal);
          if (!info.recommendation || !info.compatible) {
            this.setCalibrationSaveStatus("Recommended setup is not fully compatible", true);
            this.render();
            this.clearCalibrationSaveStatusSoon();
            return;
          }
          const recommended = info.recommendation;
          const next = cloneCalibrationData(calibration);
          next.profile = recommended.profile || next.profile;
          next.model = calibration.model;
          next.ui = uiFromCalibration(next);
          if (recommended.faceplate === "faceplates/sv-dark.png") {
            next.ui.faceplate.show = false;
            next.ui.faceplate.file = SV_ASSET_DEFAULT;
          } else if (String(recommended.faceplate || "").startsWith("faceplates/")) {
            next.ui.faceplate.show = true;
            next.ui.faceplate.file = safeAssetFilename(String(recommended.faceplate).split("/").pop());
          }
          this._calibrationWorking = next;
          this.markCalibrationDirty();
          this.setCalibrationSaveStatus(`Applied recommended setup for ${info.model}. Click Done to save it, or use Save Profile to save without closing.`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "load-profile") {
          await this.loadCalibrationProfile(true, { applyToWorking: true });
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "save-profile") {
          try {
            const profile = await this.saveCalibrationProfile(cal);
            this._calibrationDirty = false;
            this._profileLoadedProfile = profile;
            this._profileLoadRequested = profile;
            this._profileLoadInfo = {
              ...(this._profileLoadInfo || {}),
              profile,
              exists: true,
              source: "saved Home Assistant profile",
              storage_key: "switch_vision_calibrations",
              storage_path: ".storage/switch_vision_calibrations",
              profile_path: `.storage/switch_vision_calibrations → profiles.${profile}`,
            };
            this.setCalibrationSaveStatus(`Saved profile: ${profile}`, false);
          } catch (err) {
            console.error("Switch Vision save profile failed", err);
            this.setCalibrationSaveStatus("Save failed — check HA logs/config", true);
          }
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "download-profile") {
          const payload = calibrationExportData(cal);
          const profile = this.calibrationProfileName();
          payload.profile_name = profile;
          const model = safeDownloadName(payload.model, "model");
          const profilePart = safeDownloadName(profile, "profile");
          downloadJsonFile(`switch-vision-${model}-${profilePart}.json`, payload);
          this.setCalibrationSaveStatus(`Downloaded profile: ${profile}`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
          return;
        }

        if (action === "import-profile") {
          const input = this.shadowRoot.querySelector('[data-cv-profile-file]');
          if (input) input.click();
          return;
        }

        if (action === "toggle-json") {
          this._showCalibrationJson = !this._showCalibrationJson;
          this.render();
          return;
        }

        if (action === "copy") {
          const exportData = calibrationExportData(cal);
          exportData.profile_name = this.calibrationProfileName();
          const payload = JSON.stringify(exportData, null, 2);
          const textarea = this.shadowRoot.querySelector(".cv-cal-export");
          if (textarea) textarea.value = payload;

          const copied = await copyTextToClipboard(payload);
          if (copied) {
            button.textContent = "Copied";
            this.setCalibrationSaveStatus("JSON copied to clipboard", false);
          } else {
            if (textarea) {
              textarea.focus();
              textarea.select();
            }
            this.setCalibrationSaveStatus("Clipboard blocked — use Show JSON and copy manually", true);
          }

          setTimeout(() => this.render(), 900);
          this.clearCalibrationSaveStatusSoon();
          return;
        }
      });
    }

    const importInput = this.shadowRoot.querySelector('[data-cv-profile-file]');
    if (importInput) {
      importInput.addEventListener("change", async () => {
        const file = importInput.files?.[0];
        importInput.value = "";
        if (!file) return;
        try {
          const raw = JSON.parse(await file.text());
          const currentCal = this.calibrationData();
          const result = validateImportedCalibration(raw, currentCal);
          if (!result.valid) {
            this.setCalibrationSaveStatus(`Import rejected: ${result.errors[0] || "invalid profile"}`, true);
            window.alert(`Switch Vision profile import failed:\n\n${result.errors.join("\n")}`);
            this.render();
            return;
          }

          const summary = result.summary;
          const details = [
            `Model: ${summary.model}`,
            `Canvas: ${summary.width} × ${summary.height}`,
            `RJ45 ports: ${summary.portCount}`,
            `SFP/uplinks: ${summary.sfpCount}`,
            `Status LEDs: ${summary.statusCount}`,
            `Image: ${summary.imageFile}`
          ];
          if (result.warnings.length) details.push("", "Warnings:", ...result.warnings.map((warning) => `• ${warning}`));
          if (!window.confirm(`Import this Switch Vision profile?\n\n${details.join("\n")}`)) return;

          const suggested = summary.profileName || this.calibrationProfileName();
          const requested = window.prompt("Save imported profile as:", suggested);
          if (requested === null) return;
          const targetProfile = String(requested).trim();
          if (!targetProfile) {
            this.setCalibrationSaveStatus("Import cancelled: profile name is required", true);
            this.render();
            return;
          }

          let exists = false;
          try {
            const listed = await this._hass?.callWS?.({ type: "switch_vision/list_calibrations" });
            exists = Array.isArray(listed?.profiles) && listed.profiles.includes(targetProfile);
          } catch (err) {
            // Saving remains available even if the optional preflight list fails.
          }
          if (exists && !window.confirm(`Profile “${targetProfile}” already exists. Replace it?`)) return;

          this._calibrationWorking = cloneCalibrationData(result.calibration);
          this.markCalibrationDirty();
          await this.saveCalibrationProfile(this._calibrationWorking, targetProfile);
          this._calibrationDirty = false;
          this.setCalibrationSaveStatus(`Imported and saved: ${targetProfile}`, false);
          this.render();
          this.clearCalibrationSaveStatusSoon();
        } catch (err) {
          console.error("Switch Vision profile import failed", err);
          this.setCalibrationSaveStatus("Import failed — invalid JSON or storage error", true);
          window.alert(`Switch Vision profile import failed:\n\n${err?.message || err}`);
          this.render();
        }
      });
    }
  }


  attachSelectionHandlers(svg, activeCalibration = calibration) {
    if (!svg || !activeCalibration) return;

    svg.addEventListener("pointerdown", (event) => {
      if (event.target !== svg) return;

      event.preventDefault();
      event.stopPropagation();

      this.config = {
        ...this.config,
        selected_interface: null,
        selected_port: null
      };

      this.render();
    });
    const addHitbox = (type, id, item) => {
      if (!item?.center || !item?.hitbox) return;

      const [cx, cy] = item.center;
      const [w, h] = visualHitboxSize(type, item.hitbox);
      const el = document.createElementNS("http://www.w3.org/2000/svg", "rect");

      el.setAttribute("class", "cv-click-hitbox");
      el.setAttribute("x", cx - (w / 2));
      el.setAttribute("y", cy - (h / 2));
      el.setAttribute("width", w);
      el.setAttribute("height", h);
      el.setAttribute("rx", 4);
      el.setAttribute("ry", 4);
      const selectHitbox = (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        const nextConfig = {
          ...this.config,
          selected_interface: { type, id },
          selected_port: type === "port" ? id : null
        };

        if (calibrationControlsEnabled(this.config)) {
          nextConfig.calibration_target = `${type}:${id}`;
          nextConfig.calibration_part = "center";
        }

        this.config = nextConfig;
        this.render();
      };

      el.addEventListener("pointerdown", selectHitbox);

      svg.appendChild(el);
    };

    for (const [num, port] of Object.entries(activeCalibration.ports || {})) {
      addHitbox("port", Number(num), port);
    }

    for (const [name, sfp] of Object.entries(activeCalibration.sfp || {})) {
      const nums = String(name).match(/\d+/g) || [];
      const sfpPort = Number(nums[nums.length - 1] || 0);
      addHitbox("sfp", sfpPort, sfp);
    }
  }
}

if (!customElements.get(SV_TYPE)) {
  customElements.define(SV_TYPE, SwitchVision3650);
}

window.customCards = window.customCards || [];
if (!window.customCards.some(c => c.type === SV_TYPE)) {
  window.customCards.push({
    type: SV_TYPE,
    name: "Switch Vision 3650",
    description: "Switch Vision 3650 live switch renderer"
  });
}
