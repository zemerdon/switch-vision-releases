"""Switch Vision calibration profile storage integration."""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import voluptuous as vol
import yaml

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.helpers.storage import Store
from homeassistant.components import frontend, panel_custom, websocket_api
from homeassistant.components.frontend import async_panel_exists, async_remove_panel
from homeassistant.components.http import StaticPathConfig

_LOGGER = logging.getLogger(__name__)

DOMAIN = "switch_vision"
STORAGE_KEY = "switch_vision_calibrations"
STORAGE_VERSION = 1
STORAGE_PATH = f".storage/{STORAGE_KEY}"
EVENT_CALIBRATION_UPDATED = "switch_vision_calibration_updated"

SAVE_SCHEMA = vol.Schema(
    {
        vol.Required("profile"): vol.All(str, vol.Length(min=1)),
        vol.Required("calibration"): object,
    }
)

DELETE_SCHEMA = vol.Schema(
    {
        vol.Required("profile"): vol.All(str, vol.Length(min=1)),
    }
)

GET_WS_SCHEMA = {
    vol.Required("type"): "switch_vision/get_calibration",
    vol.Required("profile"): vol.All(str, vol.Length(min=1)),
}

LIST_WS_SCHEMA = {
    vol.Required("type"): "switch_vision/list_calibrations",
}

LIST_ASSETS_WS_SCHEMA = {
    vol.Required("type"): "switch_vision/list_assets",
}

DASHBOARD_PANEL_WS_SCHEMA = {
    vol.Required("type"): "switch_vision/get_dashboard_panel",
    vol.Optional("refresh", default=False): bool,
}

PANEL_URL_PATH = "switch-vision"
PANEL_VERSION = "1.8.0"
PANEL_JS_PATH = "/api/switch_vision/switch-vision-panel.js"
PANEL_JS_URL = f"{PANEL_JS_PATH}?v={PANEL_VERSION}"
ICONSET_JS_PATH = "/api/switch_vision/switch-vision-iconset.js"
ICONSET_JS_URL = f"{ICONSET_JS_PATH}?v={PANEL_VERSION}"
CARD_JS_PATH = "/api/switch_vision/switch-vision-card.js"
CARD_JS_URL = f"{CARD_JS_PATH}?v={PANEL_VERSION}"
DEFAULT_DASHBOARD_CONFIG_PATH = "/share/switch_vision/generated-dashboard-card.yaml"
CONF_SHOW_PANEL_IN_SIDEBAR = "show_panel_in_sidebar"
CONF_SHOW_CALIBRATION_BUTTONS = "show_calibration_buttons"
DATA_CONFIG = "config"
DATA_SHOW_CALIBRATION_BUTTONS = "show_calibration_buttons"

ASSET_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".svg"}
ASSET_KINDS = ("logos", "faceplates")


def _normalise_profile(value: str) -> str:
    """Normalise a profile name for storage."""
    return str(value).strip()


def _normalise_calibration(value: Any) -> dict[str, Any]:
    """Accept a JSON object or JSON string and return a dict."""
    if isinstance(value, str):
        parsed = json.loads(value)
    else:
        parsed = value
    if not isinstance(parsed, dict):
        raise vol.Invalid("calibration must be a JSON object or JSON object string")
    return parsed


def _extract_dashboard_cards(document: Any) -> list[dict[str, Any]]:
    """Extract Switch Vision card configs from generated dashboard YAML."""
    cards: list[dict[str, Any]] = []

    def visit(value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                visit(item)
            return
        if not isinstance(value, dict):
            return
        if value.get("type") == "custom:switch-vision-3650":
            cards.append(dict(value))
            return
        for key in ("views", "sections", "cards"):
            if key in value:
                visit(value[key])

    visit(document)
    return cards


def _dashboard_file_payload(path: Path, show_calibration_buttons: bool = True) -> dict[str, Any]:
    """Read the generated review YAML without modifying it."""
    if not path.is_file():
        return {
            "exists": False,
            "path": str(path),
            "cards": [],
            "card_count": 0,
            "message": "Run Discovery with dashboard-card generation enabled, then refresh the Switch Vision panel.",
            "warnings": ["Manual generated dashboard YAML remains available as the fallback workflow."],
        }
    try:
        text = path.read_text(encoding="utf-8")
        document = yaml.safe_load(text)
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as err:
        return {
            "exists": True,
            "path": str(path),
            "cards": [],
            "card_count": 0,
            "message": f"Generated dashboard YAML could not be parsed: {err}",
            "warnings": ["The source file was not changed."],
        }
    cards = _extract_dashboard_cards(document)
    for card in cards:
        card["calibration_button"] = bool(show_calibration_buttons)
    stat = path.stat()
    return {
        "exists": True,
        "path": str(path),
        "runtime_version": PANEL_VERSION,
        "asset_revision": PANEL_VERSION,
        "modified": stat.st_mtime,
        "cards": cards,
        "card_count": len(cards),
        "warnings": [] if cards else ["No custom:switch-vision-3650 cards were found in the generated file."],
        "show_calibration_buttons": bool(show_calibration_buttons),
    }


async def async_setup(hass: HomeAssistant, config: dict[str, Any]) -> bool:
    """Set up Switch Vision services."""
    store: Store[dict[str, Any]] = Store(hass, STORAGE_VERSION, STORAGE_KEY)
    domain_config = config.get(DOMAIN, {}) if isinstance(config, dict) else {}
    configured_dashboard_path = domain_config.get("dashboard_config_path") if isinstance(domain_config, dict) else None
    dashboard_path = Path(str(configured_dashboard_path or DEFAULT_DASHBOARD_CONFIG_PATH))
    hass.data.setdefault(DOMAIN, {})[DATA_CONFIG] = {"dashboard_config_path": str(dashboard_path)}

    async def _load() -> dict[str, Any]:
        data = await store.async_load()
        if not isinstance(data, dict):
            return {"profiles": {}}
        profiles = data.get("profiles")
        if not isinstance(profiles, dict):
            data["profiles"] = {}
        return data

    async def _save(data: dict[str, Any]) -> None:
        await store.async_save(data)

    def _asset_root() -> Path:
        return Path(hass.config.path("www", "switch-vision"))

    def _list_assets() -> dict[str, Any]:
        root = _asset_root()
        result: dict[str, Any] = {"root": "/config/www/switch-vision"}
        for kind in ASSET_KINDS:
            folder = root / kind
            folder.mkdir(parents=True, exist_ok=True)
            files = sorted(
                path.name
                for path in folder.iterdir()
                if path.is_file()
                and path.suffix.lower() in ASSET_EXTENSIONS
                and path.name == Path(path.name).name
                and not path.name.startswith(".")
            )
            result[kind] = files
            result[f"{kind}_path"] = f"/config/www/switch-vision/{kind}"
        result["extensions"] = sorted(ASSET_EXTENSIONS)
        return result

    async def handle_save(call: ServiceCall) -> None:
        profile = _normalise_profile(call.data["profile"])
        calibration = _normalise_calibration(call.data["calibration"])
        data = await _load()
        data.setdefault("profiles", {})[profile] = calibration
        await _save(data)
        hass.bus.async_fire(
            EVENT_CALIBRATION_UPDATED,
            {"profile": profile, "action": "saved"},
        )
        _LOGGER.info("Saved Switch Vision calibration profile %s", profile)

    async def handle_delete(call: ServiceCall) -> None:
        profile = _normalise_profile(call.data["profile"])
        data = await _load()
        existed = profile in data.setdefault("profiles", {})
        data["profiles"].pop(profile, None)
        await _save(data)
        hass.bus.async_fire(
            EVENT_CALIBRATION_UPDATED,
            {"profile": profile, "action": "deleted", "existed": existed},
        )
        _LOGGER.info("Deleted Switch Vision calibration profile %s", profile)

    async def handle_reload(call: ServiceCall) -> None:
        hass.bus.async_fire(
            EVENT_CALIBRATION_UPDATED,
            {"profile": "*", "action": "reload"},
        )

    @websocket_api.websocket_command(GET_WS_SCHEMA)
    @websocket_api.async_response
    async def websocket_get_calibration(hass: HomeAssistant, connection, msg):
        """Return one saved Switch Vision calibration profile."""
        profile = _normalise_profile(msg["profile"])
        data = await _load()
        calibration = data.setdefault("profiles", {}).get(profile)
        connection.send_result(
            msg["id"],
            {
                "profile": profile,
                "exists": calibration is not None,
                "calibration": calibration,
                "source": "Home Assistant storage" if calibration is not None else "current card config / baked defaults",
                "storage_key": STORAGE_KEY,
                "storage_path": STORAGE_PATH,
                "profile_path": f"{STORAGE_PATH} → profiles.{profile}",
            },
        )

    @websocket_api.websocket_command(LIST_WS_SCHEMA)
    @websocket_api.async_response
    async def websocket_list_calibrations(hass: HomeAssistant, connection, msg):
        """Return the list of saved Switch Vision calibration profiles."""
        data = await _load()
        profiles = sorted(data.setdefault("profiles", {}).keys())
        connection.send_result(msg["id"], {"profiles": profiles})

    @websocket_api.websocket_command(LIST_ASSETS_WS_SCHEMA)
    @websocket_api.async_response
    async def websocket_list_assets(hass: HomeAssistant, connection, msg):
        """Return safe logo and faceplate filenames from the Switch Vision folders."""
        connection.send_result(msg["id"], _list_assets())

    @websocket_api.websocket_command(DASHBOARD_PANEL_WS_SCHEMA)
    @websocket_api.async_response
    async def websocket_get_dashboard_panel(hass: HomeAssistant, connection, msg):
        """Return generated card configuration for the native Switch Vision panel."""
        show_calibration_buttons = hass.data.setdefault(DOMAIN, {}).get(DATA_SHOW_CALIBRATION_BUTTONS, True)
        payload = await hass.async_add_executor_job(
            _dashboard_file_payload, dashboard_path, bool(show_calibration_buttons)
        )
        connection.send_result(msg["id"], payload)

    # Create the public asset folders during integration setup so users can copy
    # files into them immediately, even before opening Calibration.
    _list_assets()

    websocket_api.async_register_command(hass, websocket_get_calibration)
    websocket_api.async_register_command(hass, websocket_list_calibrations)
    websocket_api.async_register_command(hass, websocket_list_assets)
    websocket_api.async_register_command(hass, websocket_get_dashboard_panel)

    panel_file = Path(__file__).with_name("switch-vision-panel.js")
    iconset_file = Path(__file__).with_name("switch-vision-iconset.js")
    card_file = Path(__file__).with_name("switch-vision-card.js")
    await hass.http.async_register_static_paths(
        [
            StaticPathConfig(PANEL_JS_PATH, str(panel_file), cache_headers=False),
            StaticPathConfig(ICONSET_JS_PATH, str(iconset_file), cache_headers=False),
            StaticPathConfig(CARD_JS_PATH, str(card_file), cache_headers=False),
        ]
    )
    frontend.add_extra_js_url(hass, ICONSET_JS_URL)

    # Create a config entry automatically for existing YAML-based installs so the
    # integration gains a normal Configure/options screen without requiring users
    # to remove their current configuration.
    if not hass.config_entries.async_entries(DOMAIN):
        hass.async_create_task(
            hass.config_entries.flow.async_init(
                DOMAIN,
                context={"source": "import"},
                data={"dashboard_config_path": str(dashboard_path)},
            )
        )

    hass.services.async_register(DOMAIN, "save_calibration", handle_save, schema=SAVE_SCHEMA)
    hass.services.async_register(DOMAIN, "delete_calibration", handle_delete, schema=DELETE_SCHEMA)
    hass.services.async_register(DOMAIN, "reload_calibrations", handle_reload)

    return True

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up the Switch Vision config entry and optional sidebar panel."""
    stored_config = hass.data.setdefault(DOMAIN, {}).get(DATA_CONFIG, {})
    dashboard_path = Path(
        str(
            entry.data.get("dashboard_config_path")
            or stored_config.get("dashboard_config_path")
            or DEFAULT_DASHBOARD_CONFIG_PATH
        )
    )
    show_in_sidebar = entry.options.get(CONF_SHOW_PANEL_IN_SIDEBAR, True)
    show_calibration_buttons = entry.options.get(CONF_SHOW_CALIBRATION_BUTTONS, True)
    hass.data.setdefault(DOMAIN, {})[DATA_SHOW_CALIBRATION_BUTTONS] = bool(show_calibration_buttons)

    # Reloads must replace the existing panel so its sidebar visibility changes
    # immediately without requiring another Home Assistant restart.
    if async_panel_exists(hass, PANEL_URL_PATH):
        async_remove_panel(hass, PANEL_URL_PATH)

    await panel_custom.async_register_panel(
        hass,
        frontend_url_path=PANEL_URL_PATH,
        webcomponent_name="switch-vision-panel",
        sidebar_title="Switch Vision" if show_in_sidebar else None,
        sidebar_icon="switch-vision:logo",
        module_url=PANEL_JS_URL,
        config={
            "automatic_dashboard": True,
            "version": PANEL_VERSION,
            "generated_dashboard_path": str(dashboard_path),
            "manual_yaml_fallback": True,
            "show_in_sidebar": show_in_sidebar,
            "runtime_version": PANEL_VERSION,
            "asset_revision": PANEL_VERSION,
            "show_calibration_buttons": bool(show_calibration_buttons),
        },
    )
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload the Switch Vision config entry."""
    if async_panel_exists(hass, PANEL_URL_PATH):
        async_remove_panel(hass, PANEL_URL_PATH)
    return True

