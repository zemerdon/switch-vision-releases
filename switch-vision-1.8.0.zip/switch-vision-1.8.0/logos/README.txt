Switch Vision bundled logos

Files:
- sv-logo.png — default Switch Vision logo
- cisco.svg — optional Cisco vendor logo
- 1984-cisco-logo.svg — optional classic Cisco logo
- 1996-cisco-logo.svg — optional Cisco Systems logo
- 2016-cisco-logo.svg — optional current Cisco logo
- juniper.svg — optional Juniper vendor logo

Home Assistant path:
/config/www/switch-vision/logos/

New profiles use sv-logo.png by default.
