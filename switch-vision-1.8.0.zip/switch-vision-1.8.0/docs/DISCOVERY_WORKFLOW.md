# Discovery workflow

Switch Vision Discovery performs read-only SNMP collection, identifies exact models and interfaces, generates configuration, and updates the automatic dashboard workflow.

## Persistent Web UI

The Discovery add-on starts into **Idle / Ready** and keeps the Web UI online. Discovery only runs when **Run Discovery** is selected.

Duplicate runs are blocked. Starting a new run does not interrupt or restart an existing run.

## Main pages

- **Discovery** — guided run status and Debug output
- **Devices** — compact per-device results
- **Support My Switch** — privacy-processed contribution packages
- **Diagnostics** — installation, registry, file, and device checks

## Normal workflow

1. Validate the configured switch rows.
2. Run targeted or full SNMP walks.
3. Identify exact models, interfaces, stacks, PoE, environmental data, and capabilities.
4. Generate SNMP2MQTT YAML.
5. Generate dashboard card YAML.
6. Validate the newly generated SNMP2MQTT YAML.
7. Start or restart the installed Switch Vision SNMP2MQTT add-on.
8. Make the generated cards available to the native Switch Vision panel.

## Guided stage labels

```text
1. Validating configured switches
2. Running SNMP walks
3. Identifying exact models and interfaces
4. Generating SNMP2MQTT YAML
5. Generating dashboard card YAML
6. Complete
```

## Minimal and Debug views

Minimal mode is the default. It shows:

- current stage;
- switch name;
- target;
- masked current command;
- action;
- status;
- elapsed time.

It shows the SNMP walk command without streaming every returned OID.

Select **Show Debug** to display:

- command execution;
- SNMP walk progress and returned-line counts;
- parser activity;
- exact file paths;
- registry lookups;
- generator stages;
- warnings, return codes, and Supervisor responses.

Credentials remain masked.

## Live polling

The Web UI:

- polls every second while Discovery or Support My Switch is active;
- polls every five seconds while idle;
- pauses when the tab is hidden;
- refreshes immediately when the tab becomes visible or focused;
- advances the elapsed timer locally every second while a run is active.

## Switch model selection

Every switch row defaults to:

```text
Switch Model: Auto-detect
```

A registered exact model may be selected as an experimental compatibility override.

Reports retain:

- detected model;
- selected override;
- effective mapping/visual model.

The detected model remains authoritative for support status.

## Persistent walk folders

Each switch uses a stable folder based on **Switch Name (Used internally only)**:

```text
/share/switch_vision/snmpwalks/<switch_name>/
```

Display names do not control folder names.

## Generated output

| Output | Purpose |
|---|---|
| `snmpwalk.log` | Walk commands, timing, warnings, and results. |
| `discovery-report.txt` | Human-readable hardware, registry, and capability report. |
| `last-discovery-run.txt` | Short latest-run summary. |
| `generated-snmp2mqtt.yaml` | Authoritative generated telemetry configuration for the SNMP2MQTT add-on import. |
| `generated-dashboard-card.yaml` | Source for the native Switch Vision panel and manual Lovelace fallback. |
| `capabilities/*-capabilities.json` | Normalised per-switch capability and registry data. |

## SNMP2MQTT handoff

After a successful run, Discovery only attempts the handoff when the current run created a new valid `generated-snmp2mqtt.yaml`.

It then:

1. locates the installed Switch Vision SNMP2MQTT add-on dynamically;
2. restarts it when already running;
3. starts it when stopped;
4. reports the resulting status.

A missing add-on, unavailable Supervisor token, or failed Supervisor request is reported as a warning and does not change the successful Discovery result.

## Automatic dashboard update

The native Switch Vision panel reads `generated-dashboard-card.yaml` through the custom component. While visible, it checks the source file every five seconds and rebuilds the cards when the modified timestamp changes.

The **Refresh** action performs an immediate check. The panel also checks when the browser tab becomes visible or focused.

## New-device support

Use Support My Switch for unknown models. Evidence can establish detected or experimental support, but real-hardware testing is required before promotion.
