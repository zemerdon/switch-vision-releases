# Clean installation

These instructions describe the recommended v1.8.0 Gold installation. Back up custom faceplates, logos, and calibration profiles before replacing an existing installation.

## 1. Extract the release

Use the installable release folder:

```text
Releases/switch-vision-1.8.0/
```

To build it from source:

```bash
python3 build.py -v 1.8.0 --gold
```

## 2. Install Switch Vision Discovery

Copy:

```text
addons/switch_vision_discovery/
```

to the local add-ons directory, normally:

```text
/addons/switch_vision_discovery/
```

In Home Assistant:

1. Open **Settings → Add-ons → Add-on Store**.
2. Open the top-right menu and select **Check for updates**.
3. Install or rebuild **Switch Vision Discovery**.
4. Enable **Start on boot** so the persistent Web UI remains available.
5. Start the add-on.

The shipped add-on already includes:

```yaml
boot: auto
hassio_api: true
hassio_role: manager
```

A full rebuild/reinstall is required when those add-on permissions change; a simple restart does not recreate the container permissions.

## 3. Install the custom component

Copy the contents of:

```text
custom_components/switch_vision/
```

directly into:

```text
/config/custom_components/switch_vision/
```

The files must be directly inside that folder. Do not create a nested path such as:

```text
/config/custom_components/switch_vision/switch_vision/
```

Add this to `configuration.yaml` when it is not already present:

```yaml
switch_vision:
```

Restart Home Assistant Core.

The integration creates or imports a normal Switch Vision config entry and registers the native sidebar panel.

## 4. Install the dashboard assets

Replace the complete folder:

```text
/config/www/switch-vision/
```

with the release assets, including:

```text
calibration/
css/
faceplates/
js/
layouts/
logos/
```

The native panel loads the card using its release-specific URL. A separate Lovelace resource is only needed when using manual dashboard cards.

For the manual workflow, register this as a **JavaScript Module**:

```text
/local/switch-vision/js/switch-vision.js?v=1.8.0
```

## 5. Install and configure Switch Vision SNMP2MQTT

Install the separate Switch Vision SNMP2MQTT add-on from its official repository.

Enable its generated-YAML import option so it reads:

```text
/share/switch_vision/generated-snmp2mqtt.yaml
```

Do not configure a second copied or active YAML path. The generated file is the authoritative Switch Vision handoff.

## 6. Configure Discovery

Open:

```text
Settings → Add-ons → Switch Vision Discovery → Configuration
```

For each switch, enter:

- **Switch Name (Used internally only)** — stable unique internal ID;
- display name — optional friendly dashboard name;
- management IP or hostname;
- sensor prefix;
- read-only SNMP community;
- targeted or full walk mode;
- **Switch Model** — normally leave at **Auto-detect**.

For a stack, add the parent switch once and configure a separate stack-member prefix for each member.

## 7. Run Discovery

Open the persistent Discovery Web UI and choose **Run Discovery**.

The normal workflow performs:

```text
Validating configured switches
→ Running SNMP walks
→ Identifying exact models and interfaces
→ Generating SNMP2MQTT YAML
→ Generating dashboard card YAML
→ Starting or restarting Switch Vision SNMP2MQTT
→ Complete
```

The elapsed time visibly updates every second. Use **Show Debug** for full command and processing details.

## 8. Open the automatic dashboard

After Discovery completes, select **Switch Vision** from the Home Assistant sidebar.

The native panel reads:

```text
/share/switch_vision/generated-dashboard-card.yaml
```

and automatically displays the generated switch cards.

The panel checks for a newer generated file every five seconds while visible and refreshes immediately when the tab regains focus.

## 9. Configure sidebar visibility

To hide or show the automatic dashboard shortcut:

```text
Settings → Devices & services → Switch Vision → Configure
```

Change:

```text
Show Switch Vision dashboard in sidebar
```

This does not disable Switch Vision or remove manual cards.

The Discovery add-on has its own separate **Show in sidebar** setting.

## 10. Calibrate when needed

The dark 3650 faceplate and `default_cisco_48_port` profile are the current defaults.

Open **Calibrate** to adjust ports, LEDs, labels, logos, faceplates, and status boxes. Clicking **Done** validates and saves the active profile automatically.

## Manual dashboard fallback

The generated card YAML remains available at:

```text
/share/switch_vision/generated-dashboard-card.yaml
```

It can be copied into an existing Lovelace dashboard. Install Layout Card through HACS when using the generated `custom:vertical-layout` example.

## Clean update procedure

1. Stop the affected add-on.
2. Replace the local Discovery add-on folder.
3. Rebuild or reinstall the Discovery add-on.
4. Replace `/config/www/switch-vision/` when dashboard assets changed.
5. Replace `/config/custom_components/switch_vision/` when the release notes say the custom component changed.
6. Restart Home Assistant Core after custom-component changes.
7. Hard-refresh the browser; clear cache or test incognito if an older panel remains visible.
8. Run Discovery once to regenerate both output files.

Do not merge partial files from different Switch Vision releases.

## Integration presentation options

After setup, open **Settings → Devices & services → Switch Vision → Configure** to control:

- whether the automatic Switch Vision dashboard is shown in the Home Assistant sidebar;
- whether Calibration buttons are shown on cards in the automatic generated dashboard.

Both options are enabled by default. Hiding Calibration buttons does not delete profiles or alter manual YAML cards.
