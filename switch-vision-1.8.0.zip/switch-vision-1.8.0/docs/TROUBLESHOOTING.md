# Troubleshooting

## Switch Vision sidebar entry is missing

Check the custom-component folder first. It must be exactly:

```text
/config/custom_components/switch_vision/
```

Files such as `__init__.py`, `manifest.json`, and `config_flow.py` must be directly inside it. Remove any accidental nested `switch_vision` directory.

Then:

1. confirm `switch_vision:` exists in `configuration.yaml` when using the YAML setup;
2. restart Home Assistant Core;
3. check **Settings → Devices & services → Switch Vision → Configure**;
4. confirm **Show Switch Vision dashboard in sidebar** is enabled;
5. hard-refresh or test in an incognito window.

## New panel version does not appear

The native panel and the Lovelace card can be cached separately.

1. Confirm the complete v1.8.0 Gold custom component was copied.
2. Confirm `/config/www/switch-vision/` was replaced.
3. Restart Home Assistant Core.
4. Hard-refresh the page.
5. Clear site data or test incognito if the old panel shell remains.

v1.8.0 registers versioned panel and card URLs, which reduces this problem on later updates.

## Generated dashboard does not update

The native panel checks the generated dashboard file every five seconds while visible.

Check that:

- Discovery completed successfully;
- `/share/switch_vision/generated-dashboard-card.yaml` has a newer modified time;
- the panel header shows the expected **Last generated** time;
- the browser tab is visible;
- **Refresh** performs an immediate update.

Open **Advanced** and use **Reload card module** only for frontend troubleshooting.

## Discovery Web UI only updates after refresh

v1.5.3 and later use live polling. Confirm the Discovery add-on itself was rebuilt or reinstalled from the current release rather than only restarted.

Expected behaviour:

- one-second polling while active;
- five-second polling while idle;
- immediate update when returning to the tab;
- elapsed time visibly ticking every second.

## SNMP2MQTT did not start or restart

Open Discovery Debug output and check the final handoff result.

Common causes:

- generated YAML was not updated by the current run;
- YAML validation failed;
- Switch Vision SNMP2MQTT is not installed;
- generated-YAML import is disabled in the SNMP2MQTT add-on;
- the Discovery container was not rebuilt after Supervisor permissions changed;
- Supervisor authorization is unavailable.

The Discovery add-on configuration must include:

```yaml
hassio_api: true
hassio_role: manager
```

Rebuild or reinstall the add-on to apply those permissions.

## Discovery cannot start after an upgrade

Older switch rows may be missing the newer `switch_model` field. Current releases make this field optional and resolve missing or blank values to:

```text
Auto-detect
```

If Home Assistant reports a missing option, open the add-on configuration, save each switch row with **Auto-detect**, then rebuild/reinstall the current add-on.

## Discovery reports a switch timeout

Default SNMP timing is:

```text
Timeout: 3 seconds
Retries: 1
```

A down switch normally takes about six to seven seconds to fail its initial SNMP pre-check before Discovery continues to the next target.

Verify:

- switch IP/hostname;
- UDP port 161 reachability;
- SNMP v2c read-only community;
- access control lists;
- routing between Home Assistant and the switch.

## Manual dashboard shows “Configuration error”

The native Switch Vision panel does not require Layout Card. This issue applies to the manual generated Lovelace workflow.

1. Open **Settings → Dashboards → Resources**.
2. Remove stale or duplicate Layout Card entries.
3. Register this as a **JavaScript Module**:

```text
/hacsfiles/lovelace-layout-card/layout-card.js
```

4. Reload Home Assistant in the browser.

## Manual card changes do not appear

- Confirm the resource URL includes the current version query string.
- Replace `/config/www/switch-vision/js/switch-vision.js`.
- Remove duplicate Switch Vision resource entries.
- Hard-refresh the browser.

## Sensors were not created

- Confirm `generated-snmp2mqtt.yaml` contains the expected target and sensors.
- Confirm the SNMP2MQTT add-on imports that generated file.
- Check the Discovery handoff result.
- Check SNMP2MQTT logs for YAML, OID, MQTT, or connection errors.
- Confirm the generated sensor prefix matches the dashboard card.

A later poll cannot create an entity that is absent from the generated configuration.

## Identity fields show a dash

Model, serial, and system description are generated only when the required OIDs are present in the walk evidence. Missing optional identity data displays as `—` without breaking the card.

## PoE shows an incorrect budget

Switch Vision normalises platform-specific PoE units. Generate a fresh targeted walk and confirm the standard POWER-ETHERNET-MIB branch is available.

## Calibration profile appears stale

- Select **Reload Saved Profile**.
- Use **Reset target** or **Reset all** when old saved geometry overrides newer defaults.
- Click **Done** to validate, save, and close.
- Use **Save Profile** when saving without closing.

## Home Assistant reports blocking filesystem calls

Capture the full Home Assistant Core warning and submit it with a Support My Switch package. The contribution package contains Discovery/add-on evidence but may not contain every Home Assistant Core log message.
