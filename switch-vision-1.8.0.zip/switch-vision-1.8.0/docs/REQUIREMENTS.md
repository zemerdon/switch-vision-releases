# Requirements

## Home Assistant

- Home Assistant OS or another installation that supports local add-ons
- Access to `/config`, `/addons`, and `/share`
- Permission to install a local custom component
- A current Home Assistant frontend and browser

The automatic native Switch Vision dashboard does not require users to create a Lovelace dashboard manually.

## Separate Switch Vision SNMP2MQTT add-on

Install the separately maintained **Switch Vision SNMP2MQTT** add-on before expecting live Home Assistant sensor entities.

Configure it to import:

```text
/share/switch_vision/generated-snmp2mqtt.yaml
```

Discovery validates this file and attempts to start or restart the add-on after a successful run.

## Network and switch access

- A managed switch reachable from Home Assistant
- SNMP v2c enabled with a read-only community
- UDP port 161 permitted between Home Assistant and the switch
- A stable management IP or resolvable hostname

Use a dedicated read-only SNMP community. Do not reuse administrative credentials.

## Supervisor access

The Discovery add-on requires Supervisor API access to start or restart Switch Vision SNMP2MQTT:

```yaml
hassio_api: true
hassio_role: manager
```

These settings are included in the shipped add-on configuration and are applied when the add-on is rebuilt or reinstalled.

## Manual dashboard fallback dependency

Only the manual generated Lovelace workflow requires Layout Card.

Install Layout Card through HACS and register this resource as a **JavaScript Module**:

```text
/hacsfiles/lovelace-layout-card/layout-card.js
```

The native Switch Vision sidebar panel does not use Layout Card.

## Browser support and caching

Use a current desktop or mobile browser. Switch Vision uses versioned panel and card module URLs, but a browser can occasionally retain older frontend code after an upgrade.

After replacing the custom component or dashboard assets:

1. restart Home Assistant Core when required;
2. hard-refresh the browser;
3. clear site data or test in an incognito window if an old version remains visible.
