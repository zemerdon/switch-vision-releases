# Building Switch Vision

Run the build from the project root.

## Build an exact version

```bash
python3 build.py -v 1.8.0 --gold
```

Automatic semantic-version bumps are also supported:

```bash
python3 build.py --bump patch
python3 build.py --bump minor
python3 build.py --bump major
```

Add `--gold` only when producing an officially promoted Gold baseline.

The `-v` option enforces semantic versioning and keeps the release folder, source archive, manifest, frontend version strings, and release metadata aligned.

## Build the next patch in a release line

```bash
python3 build.py -v 1.5.x
```

This resolves the next patch from the current `VERSION` file.

## Build output

A successful v1.8.0 Gold build creates:

```text
Releases/
├── switch-vision-1.8.0/
└── switch-vision-1.8.0.zip

Switch_Vision_v1.8.0_source.zip
```

The source ZIP begins at the archive root and contains:

```text
build.py
VERSION
README.md
CHANGELOG.md
src/
Releases/
└── switch-vision-1.8.0/
```

It must not contain:

- itself;
- prior source archives;
- old release folders;
- built release ZIPs unless explicitly requested;
- `__pycache__` directories;
- `.pyc` files.

## Release contents

The installable release includes:

- Discovery add-on;
- native Switch Vision custom component and panel;
- dashboard card and assets;
- exact-model registry;
- examples;
- current documentation.

Switch Vision SNMP2MQTT is a separate project and is not bundled.

## Components that may require restart

- **Discovery add-on changed:** rebuild/reinstall and restart the add-on.
- **Custom component changed:** replace `/config/custom_components/switch_vision/` and restart Home Assistant Core.
- **Dashboard assets changed:** replace `/config/www/switch-vision/`; use the release-specific module URL for manual cards.

## Automatic version increment

After a successful v1.8.0 Gold build, `VERSION` advances to the next development patch. A failed build does not increment the version.
