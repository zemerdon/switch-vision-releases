# Field reference


## Switch Vision integration options

Open **Settings → Devices & services → Switch Vision → Configure**.

| Option | Default | Behaviour |
|---|---:|---|
| `Show Switch Vision dashboard in sidebar` | On | Shows or hides the automatic Switch Vision dashboard in the Home Assistant sidebar. The panel remains available at `/switch-vision` when hidden. |
| `Show calibration buttons on switch cards` | On | Shows or hides the on-card Calibration button on all cards in the automatic generated dashboard. Manual YAML cards remain controlled by their own `calibration_button` option. |

## Discovery add-on fields

### Core paths

| Field | What it does |
|---|---|
| `input_path` | Fallback path to one SNMP walk file when switch-list walk folders are not being used. |
| `snmpwalks_dir` | Root directory containing per-switch walk folders. |
| `report_path` | Destination for the main human-readable Discovery report. |
| `last_run_summary_path` | Destination for the short latest-run summary. |
| `generated_yaml_path` | Destination for generated SNMP2MQTT YAML imported by the separate Switch Vision SNMP2MQTT add-on. |
| `generated_card_path` | Destination for generated card YAML consumed by the native Switch Vision panel and retained for manual Lovelace use. |
| `snmp_log_path` | Destination for SNMP walk command and result logs. |

### Run controls

| Field | What it does |
|---|---|
| `run_snmp_walks` | When `true`, Discovery performs live SNMP walks before parsing. When `false`, it parses existing files. |
| `enable_switch_list` | Enables the structured `switches` list in the add-on options. |
| `parse_all_walks` | Parses all valid walk files under `snmpwalks_dir`; otherwise current-run files are preferred. |
| `generate_snmp2mqtt` | Generates SNMP2MQTT YAML. After a successful current run and validation, Discovery attempts to start or restart the installed Switch Vision SNMP2MQTT add-on. |
| `clean_output_before_walk` | Removes old files from each target walk folder before writing a fresh walk. |
| `minimum_valid_walk_lines` | Walks with fewer lines are treated as failed/tiny and skipped. |
| `snmp_timeout` | Seconds to wait for an SNMP request before timing out. |
| `snmp_retries` | Number of retry attempts after a timeout. |

### Internal ID versus display name

- **Switch Name (Used internally only)** is the stable machine-facing target ID used by Discovery, such as `SW5` or `CORE_A`. Keep it unique. It links walk folders, stack mappings, generated calibration/profile references, and report sections.
- **Display name** is optional human-facing text used in generated card titles, such as `Core Stack`. Leaving it blank produces `Switch Vision • SW5`.

### `switches` list

| Field | What it does |
|---|---|
| `switch_name` | Stable internal target ID. It is not the friendly title shown above the card. |
| `display_name` | Optional friendly card title used by the generated dashboard. It does not populate a status-box title. |
| `switch_host` | Management IP address or resolvable hostname of the switch/stack. |
| `sensor_prefix` | Prefix used for generated Home Assistant entities, such as `sw5` for `sensor.sw5_port_1_status`. |
| `snmp_community` | SNMP v2c read-only community for this target. It is masked in logs/reports. |
| `walk_mode` | `targeted` requests known useful OIDs; `full` walks the complete accessible tree. |
| `switch_model` | `auto` preserves normal exact-model detection. Selecting a registered exact SKU enables experimental compatibility override mode while retaining the real detected model. |

### `stack_member_prefixes` list

| Field | What it does |
|---|---|
| `switch_name` | Must match the parent stack's `switches[].switch_name`. |
| `member` | Numeric stack member index reported by the switch, such as `1` or `2`. |
| `display_name` | Optional friendly display name for this stack member. It becomes the generated card title. |
| `sensor_prefix` | Entity prefix dedicated to this member, such as `sw5`. |

### CSV/fallback fields

| Field | What it does |
|---|---|
| `targets_csv` | Optional CSV mapping file used for imports or advanced workflows. |


## Native dashboard integration option

Open **Settings → Devices & services → Switch Vision → Configure**.

| Option | What it does |
|---|---|
| `show_panel_in_sidebar` | Shows or hides the dedicated Switch Vision sidebar shortcut. Disabling it does not disable the panel URL, manual cards, Discovery, Calibration, Diagnostics, Support My Switch, or SNMP2MQTT. |

The native panel reads `/share/switch_vision/generated-dashboard-card.yaml` and refreshes when the source file changes.

## Discovery Web UI status behaviour

- Poll interval while active: 1 second.
- Poll interval while idle: 5 seconds.
- Polling pauses while the tab is hidden.
- The elapsed timer advances locally every second during a run.
- **Show Debug** reveals detailed command and processing output.

## Dashboard card fields

### Identity and data mapping

| Field | What it does |
|---|---|
| `type` | Must be `custom:switch-vision-3650` for the current card. |
| `title` | Text shown for the switch/card title when enabled by the layout. |
| `member` | Friendly switch or stack-member name used by the card. |
| `selected_switch` | Selects the generated switch or stack-member entity group used by the card. |
| `discovery_selected_switch` | Links the card to the Discovery target name used for generated examples. |
| `switch_model` | Exact model used for registry recommendations and the generated visual setup. Normally supplied automatically by Discovery. |
| `model_override` | Indicates that `switch_model` came from a manual compatibility override rather than exact detection. |
| `detected_switch_model` | Retains the real detected SKU when a model override is active. |
| `calibration_profile` | Name of the saved calibration profile to load. |
| `calibration_profile_load` | Enables loading a saved profile. |
| `calibration_profile_auto_load` | Automatically loads the saved profile when the card starts. |
| `status_entity_prefix` | Entity prefix before the port number, e.g. `sensor.sw1_port_`. |
| `status_entity_suffix` | Entity suffix after the port number, normally `_status`. |
| `switch_ip` | Optional management IP displayed in the Status Box 1. |
| `management_ip` | Legacy alias/fallback for `switch_ip`; generated cards use the Switch IP label. |

### Stack fields

| Field | What it does |
|---|---|
| `stack_enabled` | Enables stack-specific display/uptime behavior for this card. |
| `stack_id` | Optional stack identifier used by custom layouts or profiles. |
| `stack_member_number` | Numeric member index when explicitly required. |
| `stack_uptime_mode` | Controls stack uptime behavior; `inherit_stack` uses another entity as the source. |
| `stack_uptime_source` | Entity ID that provides inherited stack uptime. |
| `stack_member_uptime_source` | Optional member-specific uptime source. |

### Display controls

| Field | What it does |
|---|---|
| `demo` | Uses demonstration data instead of normal live entities. Keep `false` for production. |
| `calibration_button` | Shows or hides the on-card calibration button. Defaults to `true`, and generated dashboard cards include it explicitly. |
| `show_labels` | Shows or hides port labels. |
| `show_numbers` | Shows or hides port numbers. |
| `show_legend` | Shows or hides the card legend. |
| `show_port_leds` | Shows or hides port/link LED overlays. |
| `show_status_leds` | Shows or hides chassis/status LED overlays. |
| `show_status_panel` | Shows or hides the Status Box 1. |
| `unknown_is_up` | Treats unknown status values as up when enabled; normally leave disabled. |
| `status_up_values` | Custom list of entity states treated as up. |
| `status_down_values` | Custom list of entity states treated as down. |

### Activity and traffic timing

| Field | What it does |
|---|---|
| `activity_hold_seconds` | Keeps activity visible between slower traffic polls. A common value is `30`. |
| `traffic_poll_seconds` | Expected traffic polling interval used by activity timing. |
| `activity_poll_seconds` | Expected activity update interval when configured separately. |
| `activity_window_ms` | Time window used to determine recent activity. |
| `activity_decay_ms` | Time for activity indication to decay. |
| `activity_slow_period_ms` | Blink period for low activity. |
| `activity_medium_period_ms` | Blink period for medium activity. |
| `activity_fast_period_ms` | Blink period for high activity. |
| `traffic_rate_stale_ms` | Age after which a traffic-rate value is treated as stale. |
| `traffic_scan_interval` | Frontend interval for scanning traffic entities. |

### Status Box 1 layout

| Field | What it does |
|---|---|
| `status_panel_fields` | Ordered list of fields shown in the Status Box 1. |
| `status_panel_hidden_fields` | List of status fields hidden from display. |
| `status_panel_x`, `status_panel_y` | Horizontal and vertical panel position. |
| `status_panel_width`, `status_panel_height` | Panel dimensions. |
| `status_panel_font_family` | Font used for status values and labels. |
| `status_panel_font_size` | Main status text size. |
| `status_panel_title_font_size` | Status Box 1 title size. |
| `status_panel_font_weight` | Font weight, such as normal or bold. |
| `status_panel_background_color` | Panel background color. |
| `status_panel_border_color` | Panel border color. |
| `status_panel_text_color` | Main value text color. |
| `status_panel_label_color` | Label text color. |
| `status_panel_title_color` | Title text color. |

### Logo layout

| Field | What it does |
|---|---|
| `logo_show` | Shows or hides the configured logo. |
| `logo_file` | Path to the logo asset. |
| `logo_x`, `logo_y` | Logo position. |
| `logo_width`, `logo_height` | Logo dimensions. |

### Calibration controls

| Field | What it does |
|---|---|
| `calibration_mode` | Enables interactive calibration mode. |
| `calibration_target` | Selects the group being edited, such as ports, LEDs, numbers, logo, or Status Box 1. |
| `calibration_item` | Selects one individual item in the target group. |
| `calibration_part` | Selects a sub-part of the current target when applicable. |
| `calibration_step` | Movement/resize increment used by calibration controls. |
| `calibration_blink` | Enables blink preview while calibrating activity LEDs. |
| `calibration_blink_ms` | Blink preview interval in milliseconds. |
| `calibration_show_hitboxes` | Shows clickable port hitboxes during calibration. |
| `calibration_show_labels` | Shows calibration labels. |
| `calibration_show_led_rings` | Shows LED ring guides. |

## Calibration services

| Service | What it does |
|---|---|
| `switch_vision.save_calibration` | Saves or replaces a named calibration profile in Home Assistant storage. |
| `switch_vision.delete_calibration` | Deletes a named saved calibration profile. |
| `switch_vision.reload_calibrations` | Reloads saved calibration profiles without a full Home Assistant restart. |

## Switch display and faceplate fields

- `display_name`: Friendly title used by generated dashboard cards. The card appends the member name, for example `Core Stack • SW5`. Leave blank to use `Switch Vision • SW5`.

## Status boxes and selected-port fields

- **Status Box 1** is the primary switch-summary container and defaults to model, IP, CPU, temperature, PoE, and uptime.
- **Status Box 2** is an independent secondary switch-summary container and defaults to VENDOR and UPTIME.
- **Port Status Box** controls selected-port fields separately, so clicking a port does not replace Status Box 1 or Status Box 2 configuration.

All three workflows use title-free rows with independent field ordering, visibility, per-field X/Y offsets, font settings, colours, fill, border visibility, and border colour. Status Box 1 and Status Box 2 retain their calibrated width and height; field changes never resize the boxes.

Current VLAN display rules are:

- one VLAN: `VLAN 10`;
- multiple memberships: `VLANS 1, 10, 30`;
- known trunk without membership data: `VLAN TRUNK`.

`MODE` is not a separate current port-status field.

## Display naming

- `display_name` supplies the generated card title only.
- The retired standalone faceplate-label system is no longer part of the current generated dashboard workflow.
