# Supported Devices

This document is generated from `devices/supported_devices.yaml`.
Only exact model identifiers are listed. Support for one SKU does not imply support for nearby variants.

| Vendor | Family | Exact model | RJ45 | Uplinks | PoE | Stack | Recommended faceplate | Calibration profile | Uplink validation | Status | Last validated |
|---|---|---|---:|---:|---|---|---|---|---|---|---|
| Cisco | Catalyst 3650 | `WS-C3650-48PD-E` | 48 | 2 Gigabit SFP + 2 10G SFP+ | Yes | Yes | `faceplates/sv-dark.png` | `default_cisco_48_port` | Confirmed | Confirmed | v1.8.0 |
| Cisco | Catalyst 3650 | `WS-C3650-48PD-L` | 48 | 2 Gigabit SFP + 2 10G SFP+ | Yes | Yes | `faceplates/sv-dark.png` | `default_cisco_48_port` | Confirmed | Confirmed | v1.8.0 |
| Cisco | Catalyst 2960X | `WS-C2960X-48FPD-L` | 48 | 2 Gigabit SFP + 2 10G SFP+ | Yes | No | `Pending` | `Pending` | Pending | Experimental | v1.8.0 |
| Cisco | Catalyst 2960X | `WS-C2960X-24PS-L` | 24 | 4 Gigabit SFP | Yes | No | `Pending` | `Pending` | Pending | Experimental | v1.8.0 |
| Cisco | Catalyst 2960S | `WS-C2960S-48FPD-L` | 48 | 2 Gigabit SFP + 2 10G SFP+ | Yes | No | `Pending` | `Pending` | Pending | Experimental | v1.8.0 |
| Juniper | EX3300 | `EX3300-48P` | 48 | 4 Gigabit SFP + 4 10G SFP+ | Yes | Yes | `faceplates/sv-dark.png` | `default_cisco_48_port` | Pending | Experimental | v1.8.0 |

## Status definitions

- **Detected:** Model identification works, but telemetry and layout are not validated.
- **Experimental:** A profile exists, but real-hardware validation is incomplete.
- **Community Validated:** A contributor has tested the model successfully on real hardware.
- **Confirmed:** Repeatably tested and treated as officially supported.

## Exact-model policy

Each hardware SKU receives its own entry. The registry does not use aliases to infer support for licence, uplink, PoE, regional, or revision variants.
