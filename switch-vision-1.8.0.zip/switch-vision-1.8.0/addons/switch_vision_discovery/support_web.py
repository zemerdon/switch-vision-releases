#!/usr/bin/env python3
"""Local Home Assistant Ingress UI for Support My Switch.

The UI creates privacy-processed contribution bundles by invoking the existing
support_my_switch.sh backend. It never sends email or stores mail credentials.
"""
from __future__ import annotations

import argparse
import html
import json
import mimetypes
import os
import subprocess
import threading
import time
import traceback
import zipfile
import hashlib

import yaml
from email.message import EmailMessage
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from registry_lookup import lookup as registry_lookup

SUPPORT_ADDRESS = "switch-vision@zemerdon.com"
DEFAULT_CONTRIBUTIONS_DIR = Path("/share/switch_vision/contributions")
DEFAULT_OPTIONS_FILE = Path("/data/options.json")
DEFAULT_SUPPORT_SCRIPT = Path("/support_my_switch.sh")
DEFAULT_DISCOVERY_SCRIPT = Path("/discovery_job.sh")
DEFAULT_SHARE_DIR = Path("/share/switch_vision")
DEFAULT_REGISTRY_FILE = Path("/opt/switch-vision/devices/supported_devices.json")
DEFAULT_GENERATED_SNMP2MQTT = Path("/share/switch_vision/generated-snmp2mqtt.yaml")
DEFAULT_DISCOVERY_LOG = DEFAULT_SHARE_DIR / "discovery-web.log"

_STATE_LOCK = threading.Lock()
_STATE: dict[str, Any] = {
    "running": False,
    "started_at": None,
    "finished_at": None,
    "success": None,
    "message": "Ready",
    "log_tail": [],
}

_DISCOVERY_STATE_LOCK = threading.Lock()
_DISCOVERY_STATE: dict[str, Any] = {
    "running": False,
    "started_at": None,
    "finished_at": None,
    "success": None,
    "message": "Idle / Ready",
    "log_tail": [],
    "stage": "Ready",
    "switch": "",
    "target": "",
    "command": "",
    "activity": "",
    "phase": "idle",
    "snmp2mqtt": {"status": "Not checked", "action": "none", "slug": None, "state": None, "message": "Waiting for Discovery"},
}


def _safe_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
    return default


def _load_options(path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _defaults(options_file: Path) -> dict[str, Any]:
    options = _load_options(options_file)
    contributor_type = str(options.get("support_contributor_type") or "anonymous")
    if contributor_type not in {"anonymous", "first_name", "full_name", "github", "forum"}:
        contributor_type = "anonymous"
    return {
        "mask_management_ips": _safe_bool(options.get("support_mask_management_ips"), True),
        "mask_mac_addresses": _safe_bool(options.get("support_mask_mac_addresses"), True),
        "mask_hostnames": _safe_bool(options.get("support_mask_hostnames"), True),
        "mask_vlan_names": _safe_bool(options.get("support_mask_vlan_names"), False),
        "mask_interface_descriptions": _safe_bool(options.get("support_mask_interface_descriptions"), False),
        "contributor_type": contributor_type,
        "contributor_value": str(options.get("support_contributor_value") or "")[:120],
    }


def _zip_member_json(archive: Path, suffix: str) -> Any:
    try:
        with zipfile.ZipFile(archive) as zf:
            candidates = [name for name in zf.namelist() if name.endswith(suffix)]
            if not candidates:
                return None
            return json.loads(zf.read(candidates[0]).decode("utf-8"))
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError, json.JSONDecodeError):
        return None


def _latest_contribution(contributions_dir: Path) -> dict[str, Any] | None:
    archives = sorted(
        contributions_dir.glob("Switch_Vision_Contribution_SV-*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    ) if contributions_dir.is_dir() else []
    if not archives:
        return None
    archive = archives[0]
    stem = archive.stem
    email_path = archive.with_suffix(".eml")
    actions_path = archive.with_name(f"{stem}_Actions.html")
    manifest = _zip_member_json(archive, "/MANIFEST.json") or {}
    devices = _zip_member_json(archive, "/DEVICE_SUMMARY.json") or []
    privacy = manifest.get("privacy_options") or {}
    return {
        "contribution_id": manifest.get("contribution_id") or "Unknown",
        "version": manifest.get("switch_vision_version") or "Unknown",
        "quality": manifest.get("bundle_quality") or "Unknown",
        "ready_to_send": bool(manifest.get("ready_to_send")),
        "created_at": manifest.get("created_at") or "",
        "archive": archive.name,
        "archive_size": archive.stat().st_size,
        "email": email_path.name if email_path.is_file() else None,
        "actions": actions_path.name if actions_path.is_file() else None,
        "devices": devices if isinstance(devices, list) else [],
        "privacy": privacy if isinstance(privacy, dict) else {},
    }


def _state_snapshot() -> dict[str, Any]:
    with _STATE_LOCK:
        return json.loads(json.dumps(_STATE))


def _set_state(**updates: Any) -> None:
    with _STATE_LOCK:
        _STATE.update(updates)



def _discovery_state_snapshot() -> dict[str, Any]:
    with _DISCOVERY_STATE_LOCK:
        return json.loads(json.dumps(_DISCOVERY_STATE))


def _set_discovery_state(**updates: Any) -> None:
    with _DISCOVERY_STATE_LOCK:
        _DISCOVERY_STATE.update(updates)


def _parse_status_marker(line: str) -> dict[str, str] | None:
    if not line.startswith("SV_STATUS|"):
        return None
    result: dict[str, str] = {}
    for part in line.split("|")[1:]:
        key, sep, value = part.partition("=")
        if sep and key:
            result[key] = value
    return result


def _ensure_runtime_paths() -> None:
    """Create writable runtime paths required by Discovery and support bundles."""
    DEFAULT_SHARE_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULT_CONTRIBUTIONS_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULT_DISCOVERY_LOG.touch(exist_ok=True)


def _run_discovery(discovery_script: Path) -> None:
    log_path = DEFAULT_DISCOVERY_LOG
    lines: list[str] = []
    generated_yaml_previous_mtime = DEFAULT_GENERATED_SNMP2MQTT.stat().st_mtime if DEFAULT_GENERATED_SNMP2MQTT.is_file() else None
    _set_discovery_state(
        running=True,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        finished_at=None,
        success=None,
        message="Preparing Discovery",
        log_tail=[],
        stage="Preparing Discovery",
        switch="",
        target="",
        command="",
        activity="Validating configured switches",
        phase="preparing",
        snmp2mqtt={"status": "Waiting", "action": "none", "slug": None, "state": None, "message": "Waiting for Discovery to complete"},
    )
    try:
        _ensure_runtime_paths()
        with log_path.open("a", encoding="utf-8") as log_file:
            log_file.write(f"\n=== Discovery started {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            process = subprocess.Popen(
                [str(discovery_script)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=os.environ.copy(),
            )
            assert process.stdout is not None
            for line in process.stdout:
                clean = line.rstrip()
                log_file.write(line)
                log_file.flush()
                marker = _parse_status_marker(clean)
                if marker is not None:
                    _set_discovery_state(
                        stage=marker.get("stage", "Discovery"),
                        switch=marker.get("switch", ""),
                        target=marker.get("target", ""),
                        command=marker.get("command", ""),
                        activity=marker.get("activity", ""),
                        message=marker.get("stage", "Discovery running"),
                        phase="running",
                    )
                    continue
                debug_line = clean.removeprefix("SV_DEBUG|")
                lines.append(debug_line)
                lines = lines[-300:]
                _set_discovery_state(log_tail=lines)
            return_code = process.wait()
        if return_code != 0:
            raise RuntimeError(f"Discovery exited with code {return_code}.")
        _set_discovery_state(stage="Starting SNMP2MQTT", activity="Validating generated SNMP2MQTT YAML", command="Supervisor add-on action", phase="running")
        snmp2mqtt_result = _ensure_snmp2mqtt_running(lines, generated_yaml_previous_mtime)
        auto_message = "Discovery complete"
        _set_discovery_state(
            success=True,
            message=auto_message,
            stage="Complete",
            activity=snmp2mqtt_result.get("message") or auto_message,
            command="",
            phase="complete",
            log_tail=lines[-300:],
            snmp2mqtt=snmp2mqtt_result,
        )
    except Exception as exc:
        lines.append(str(exc))
        _set_discovery_state(success=False, message=str(exc), log_tail=lines[-80:], phase="failed")
        try:
            with log_path.open("a", encoding="utf-8") as log_file:
                traceback.print_exc(file=log_file)
        except OSError:
            pass
    finally:
        _set_discovery_state(running=False, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))





def _read_supervisor_token() -> str:
    """Return the Supervisor bearer token supplied to the app container."""
    for name in ("SUPERVISOR_TOKEN", "HASSIO_TOKEN"):
        token = os.environ.get(name, "").strip()
        if token:
            return token

    # s6 exposes container environment values as files on some base-image versions.
    for path in (
        Path("/run/s6/container_environment/SUPERVISOR_TOKEN"),
        Path("/var/run/s6/container_environment/SUPERVISOR_TOKEN"),
        Path("/run/s6/container_environment/HASSIO_TOKEN"),
        Path("/var/run/s6/container_environment/HASSIO_TOKEN"),
    ):
        try:
            token = path.read_text(encoding="utf-8").strip().strip("\x00")
        except OSError:
            continue
        if token:
            return token
    return ""


def _supervisor_json(path: str, *, method: str = "GET", timeout: float = 12.0) -> dict[str, Any]:
    token = _read_supervisor_token()
    if not token:
        raise RuntimeError(
            "Supervisor API token is unavailable. Rebuild/reinstall the Discovery app "
            "with hassio_api: true and hassio_role: manager."
        )
    request = Request(
        f"http://supervisor{path}",
        method=method,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        data=b"{}" if method != "GET" else None,
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Supervisor API returned HTTP {exc.code}: {detail[:240]}") from exc
    except (URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Supervisor API request failed: {exc}") from exc
    if isinstance(payload, dict) and payload.get("result") == "error":
        raise RuntimeError(str(payload.get("message") or "Supervisor API reported an error."))
    return payload if isinstance(payload, dict) else {}


def _find_snmp2mqtt_addon() -> dict[str, Any] | None:
    payload = _supervisor_json("/addons")
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    addons = data.get("addons", []) if isinstance(data, dict) else []
    candidates: list[tuple[int, dict[str, Any]]] = []
    for addon in addons if isinstance(addons, list) else []:
        if not isinstance(addon, dict):
            continue
        slug = str(addon.get("slug") or "")
        name = str(addon.get("name") or "")
        haystack = f"{slug} {name}".lower().replace("-", "_")
        if "snmp2mqtt" not in haystack or "discovery" in haystack:
            continue
        score = 0
        if "switch_vision" in haystack or "switch vision" in haystack:
            score += 10
        if slug.endswith("switch_vision_snmp2mqtt") or slug.endswith("switch_vision_snmp2mqtt_addon"):
            score += 10
        if name.strip().lower() == "switch vision snmp2mqtt":
            score += 20
        candidates.append((score, addon))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _ensure_snmp2mqtt_running(lines: list[str], previous_mtime: float | None) -> dict[str, Any]:
    if not DEFAULT_GENERATED_SNMP2MQTT.is_file():
        message = "SNMP2MQTT was not started because Discovery did not generate a YAML file."
        lines.append(message)
        return {"status": "Warning", "action": "none", "slug": None, "state": None, "message": message}
    current_mtime = DEFAULT_GENERATED_SNMP2MQTT.stat().st_mtime
    if previous_mtime is not None and current_mtime <= previous_mtime:
        message = "SNMP2MQTT was not restarted because generated-snmp2mqtt.yaml was not updated by this Discovery run."
        lines.append(message)
        return {"status": "Not changed", "action": "none", "slug": None, "state": None, "message": message}
    validation = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
    if not validation.get("valid"):
        message = f"Generated SNMP2MQTT YAML was not applied: {validation.get('error')}"
        lines.append(message)
        return {"status": "Warning", "action": "none", "slug": None, "state": None, "message": message}
    try:
        addon = _find_snmp2mqtt_addon()
        if addon is None:
            message = "Switch Vision SNMP2MQTT add-on is not installed; Discovery completed without restarting it."
            lines.append(message)
            return {"status": "Warning", "action": "none", "slug": None, "state": "not_installed", "message": message}
        slug = str(addon.get("slug") or "")
        state = str(addon.get("state") or addon.get("status") or "unknown").lower()
        action = "restart" if state in {"started", "running"} else "start"
        lines.append(f"SNMP2MQTT add-on found: {slug} ({state}); requesting {action}.")
        _supervisor_json(f"/addons/{quote(slug, safe='')}/{action}", method="POST", timeout=20.0)
        # Give Supervisor a moment, then retrieve the resulting state when possible.
        time.sleep(1.0)
        resulting_state = "requested"
        try:
            info = _supervisor_json(f"/addons/{quote(slug, safe='')}/info")
            info_data = info.get("data") if isinstance(info.get("data"), dict) else info
            if isinstance(info_data, dict):
                resulting_state = str(info_data.get("state") or resulting_state)
        except Exception as exc:  # The action succeeded; an info refresh failure is non-fatal.
            lines.append(f"SNMP2MQTT status refresh warning: {exc}")
        message = f"Switch Vision SNMP2MQTT {action} requested successfully; status: {resulting_state}."
        lines.append(message)
        return {"status": "Running" if resulting_state in {"started", "running"} else "Action requested", "action": action, "slug": slug, "state": resulting_state, "message": message}
    except Exception as exc:
        message = f"Could not start or restart Switch Vision SNMP2MQTT: {exc}"
        lines.append(message)
        return {"status": "Warning", "action": "failed", "slug": None, "state": None, "message": message}


def _validate_snmp2mqtt_yaml(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"valid": False, "error": "Generated SNMP2MQTT YAML was not found."}
    try:
        text = path.read_text(encoding="utf-8")
        data = yaml.safe_load(text)
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as exc:
        return {"valid": False, "error": f"YAML validation failed: {exc}"}
    if not isinstance(data, (dict, list)) or not data:
        return {"valid": False, "error": "Generated YAML is empty or does not contain a YAML mapping/list."}
    lowered = text.lower()
    if "host:" not in lowered and "target:" not in lowered:
        return {"valid": False, "error": "Generated YAML does not contain any management host/target entries."}
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return {"valid": True, "error": None, "size": len(text.encode("utf-8")), "sha256": digest, "text": text}


def _generated_yaml_status() -> dict[str, Any]:
    validation = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
    return {
        "generated": _file_info(DEFAULT_GENERATED_SNMP2MQTT),
        "validation": {key: value for key, value in validation.items() if key != "text"},
        "import_note": "Enable generated-YAML import in the Switch Vision SNMP2MQTT add-on and restart that add-on after regeneration.",
    }

def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None


def _file_info(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {"found": False, "path": str(path), "size": 0, "modified": None}
    stat = path.stat()
    return {
        "found": True,
        "path": str(path),
        "size": stat.st_size,
        "modified": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(stat.st_mtime)),
    }


def _diagnostics_snapshot(version: str) -> dict[str, Any]:
    share = DEFAULT_SHARE_DIR
    registry_raw = _read_json(DEFAULT_REGISTRY_FILE)
    if isinstance(registry_raw, dict):
        registry_devices = registry_raw.get("devices") or []
    elif isinstance(registry_raw, list):
        registry_devices = registry_raw
    else:
        registry_devices = []

    capability_dir = share / "capabilities"
    capability_files = sorted(capability_dir.glob("*-capabilities.json")) if capability_dir.is_dir() else []
    devices: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []
    for cap_path in capability_files:
        data = _read_json(cap_path)
        if not isinstance(data, dict):
            warnings.append(f"Could not read capability file: {cap_path.name}")
            continue
        device = data.get("device") if isinstance(data.get("device"), dict) else {}
        interfaces = data.get("interfaces") if isinstance(data.get("interfaces"), list) else []
        model = str(device.get("detected_model_text") or device.get("model_text") or device.get("model") or "Unknown")
        registry = registry_lookup({"devices": registry_devices}, model) or {}
        validation = registry.get("validation") if isinstance(registry.get("validation"), dict) else {}
        physical = [i for i in interfaces if isinstance(i, dict) and i.get("physical")]
        rj45 = [i for i in physical if i.get("media") == "rj45"]
        uplinks = [i for i in physical if i.get("media") in {"sfp", "sfp_plus", "uplink"}]
        source_walk = Path(str(data.get("source_walk") or ""))
        walk_found = source_walk.is_file() if str(source_walk) else False
        status = str(registry.get("status") or device.get("support_status") or "detected")
        devices.append({
            "name": cap_path.name.removesuffix("-capabilities.json"),
            "model": model,
            "family": registry.get("family") or device.get("family") or "Unknown",
            "registry_match": bool(registry),
            "registry_status": status,
            "last_validated_version": registry.get("last_validated_version"),
            "mapping_profile": registry.get("mapping_profile") or registry.get("dashboard_profile"),
            "calibration_profile": registry.get("calibration_profile"),
            "validation": validation,
            "physical_interfaces": len(physical),
            "rj45_interfaces": len(rj45),
            "uplink_interfaces": len(uplinks),
            "walk_found": walk_found,
            "generated_at": data.get("generated_at"),
        })

    registry_loaded = isinstance(registry_raw, (dict, list))
    if not registry_loaded:
        errors.append("Supported-device registry could not be loaded.")
    report = _file_info(share / "discovery-report.txt")
    generated_yaml = _file_info(share / "generated-snmp2mqtt.yaml")
    generated_card = _file_info(share / "generated-dashboard-card.yaml")
    if not report["found"]:
        warnings.append("No discovery report has been generated yet.")
    if not generated_yaml["found"]:
        warnings.append("Generated SNMP2MQTT YAML was not found.")
    if not generated_card["found"]:
        warnings.append("Generated dashboard YAML was not found.")
    if report["found"]:
        report_mtime = (share / "discovery-report.txt").stat().st_mtime
        for label, path in [("SNMP2MQTT YAML", share / "generated-snmp2mqtt.yaml"), ("dashboard YAML", share / "generated-dashboard-card.yaml")]:
            if path.is_file() and path.stat().st_mtime + 1 < report_mtime:
                warnings.append(f"Generated {label} is older than the latest discovery report.")

    return {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "version": version,
        "service": "Running",
        "discovery": _discovery_state_snapshot(),
        "registry": {"loaded": registry_loaded, "entries": len(registry_devices), "path": str(DEFAULT_REGISTRY_FILE)},
        "files": {"report": report, "generated_yaml": generated_yaml, "generated_card": generated_card},
        "contribution_workflow": {"ready": DEFAULT_SUPPORT_SCRIPT.is_file(), "directory": str(DEFAULT_CONTRIBUTIONS_DIR)},
        "devices": devices,
        "warnings": warnings,
        "errors": errors,
    }


def _diagnostics_text(data: dict[str, Any]) -> str:
    lines = [
        "Switch Vision Diagnostics",
        "=========================",
        f"Generated: {data.get('generated_at')}",
        f"Switch Vision version: {data.get('version')}",
        f"Discovery add-on: {data.get('service')}",
        f"Discovery status: {(data.get('discovery') or {}).get('message', 'Unknown')}",
        f"Device registry: {'Loaded' if (data.get('registry') or {}).get('loaded') else 'Unavailable'}",
        f"Registry entries: {(data.get('registry') or {}).get('entries', 0)}",
        f"Generated SNMP2MQTT YAML: {'Found' if ((data.get('files') or {}).get('generated_yaml') or {}).get('found') else 'Missing'}",
        f"Generated dashboard YAML: {'Found' if ((data.get('files') or {}).get('generated_card') or {}).get('found') else 'Missing'}",
        f"Contribution workflow: {'Ready' if (data.get('contribution_workflow') or {}).get('ready') else 'Unavailable'}",
        "",
    ]
    for device in data.get("devices") or []:
        lines.extend([
            str(device.get("model") or "Unknown model"),
            "-" * len(str(device.get("model") or "Unknown model")),
            f"Target: {device.get('name')}",
            f"Registry match: {'yes' if device.get('registry_match') else 'no'}",
            f"Registry status: {device.get('registry_status')}",
            f"Last SNMP walk: {'PASS/file found' if device.get('walk_found') else 'Unavailable'}",
            f"Physical interfaces: {device.get('physical_interfaces', 0)}",
            f"RJ45 interfaces: {device.get('rj45_interfaces', 0)}",
            f"Uplink interfaces: {device.get('uplink_interfaces', 0)}",
            f"Mapping profile: {device.get('mapping_profile') or 'Not assigned'}",
            f"Calibration profile: {device.get('calibration_profile') or 'Not assigned'}",
        ])
        validation = device.get("validation") or {}
        for label, key in [("Exact model", "exact_model_detection"), ("RJ45 mapping", "rj45_mapping"), ("PoE", "poe"), ("System sensors", "system_sensors"), ("Uplinks", "uplinks"), ("Stack", "stack")]:
            lines.append(f"{label}: {validation.get(key, 'unknown')}")
        lines.append("")
    if data.get("warnings"):
        lines.append("Warnings")
        lines.append("--------")
        lines.extend(f"WARNING: {item}" for item in data["warnings"])
        lines.append("")
    if data.get("errors"):
        lines.append("Errors")
        lines.append("------")
        lines.extend(f"ERROR: {item}" for item in data["errors"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _validate_request(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Request body must be a JSON object.")
    contributor_type = str(data.get("contributor_type") or "anonymous")
    if contributor_type not in {"anonymous", "first_name", "full_name", "github", "forum"}:
        raise ValueError("Invalid recognition type.")
    contributor_value = str(data.get("contributor_value") or "").replace("\n", " ").replace("\r", " ").strip()[:120]
    if contributor_type != "anonymous" and not contributor_value:
        raise ValueError("Enter the name or username to use for recognition, or choose Anonymous.")
    return {
        "mask_management_ips": _safe_bool(data.get("mask_management_ips"), True),
        "mask_mac_addresses": _safe_bool(data.get("mask_mac_addresses"), True),
        "mask_hostnames": _safe_bool(data.get("mask_hostnames"), True),
        "mask_vlan_names": _safe_bool(data.get("mask_vlan_names"), False),
        "mask_interface_descriptions": _safe_bool(data.get("mask_interface_descriptions"), False),
        "contributor_type": contributor_type,
        "contributor_value": contributor_value,
    }


def _run_bundle(settings: dict[str, Any], support_script: Path, contributions_dir: Path, version: str) -> None:
    log_path = contributions_dir / "support-my-switch-web.log"
    contributions_dir.mkdir(parents=True, exist_ok=True)
    _set_state(
        running=True,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        finished_at=None,
        success=None,
        message="Preparing contribution bundle…",
        log_tail=[],
    )
    env = os.environ.copy()
    env.update({
        "SWITCH_VISION_DISCOVERY_VERSION": version,
        "SUPPORT_MASK_MANAGEMENT_IPS": str(settings["mask_management_ips"]).lower(),
        "SUPPORT_MASK_MAC_ADDRESSES": str(settings["mask_mac_addresses"]).lower(),
        "SUPPORT_MASK_HOSTNAMES": str(settings["mask_hostnames"]).lower(),
        "SUPPORT_MASK_VLAN_NAMES": str(settings["mask_vlan_names"]).lower(),
        "SUPPORT_MASK_INTERFACE_DESCRIPTIONS": str(settings["mask_interface_descriptions"]).lower(),
        "SUPPORT_CONTRIBUTOR_TYPE": settings["contributor_type"],
        "SUPPORT_CONTRIBUTOR_VALUE": settings["contributor_value"],
        "CONTRIBUTIONS_DIR": str(contributions_dir),
    })
    lines: list[str] = []
    try:
        with log_path.open("a", encoding="utf-8") as log_file:
            log_file.write(f"\n=== Web UI contribution started {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            process = subprocess.Popen(
                [str(support_script)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            assert process.stdout is not None
            for line in process.stdout:
                clean = line.rstrip()
                log_file.write(line)
                log_file.flush()
                lines.append(clean)
                lines = lines[-40:]
                _set_state(log_tail=lines, message=clean or "Preparing contribution bundle…")
            return_code = process.wait()
        if return_code != 0:
            raise RuntimeError(f"Support My Switch exited with code {return_code}.")
        _set_state(success=True, message="Contribution ready")
    except Exception as exc:  # noqa: BLE001 - surface safe failure details in local UI
        lines.append(str(exc))
        _set_state(success=False, message=str(exc), log_tail=lines[-40:])
        try:
            with log_path.open("a", encoding="utf-8") as log_file:
                traceback.print_exc(file=log_file)
        except OSError:
            pass
    finally:
        _set_state(running=False, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))


_PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Switch Vision Discovery</title>
<style>
:root{color-scheme:light dark;--accent:#03a9f4;--muted:#77808a;--card:rgba(127,127,127,.10);--line:rgba(127,127,127,.35);--warn:#ffb300;--ok:#43a047;--bad:#e53935}
*{box-sizing:border-box}body{font-family:system-ui,-apple-system,sans-serif;margin:0;padding:22px;line-height:1.45}main{max-width:880px;margin:auto}h1{margin:.1rem 0}.lead{color:var(--muted);margin-top:.25rem}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin:18px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px 22px}.option{display:flex;gap:10px;align-items:flex-start;padding:7px 0}.option input{margin-top:4px}.field{display:grid;gap:6px;margin:12px 0}select,input[type=text]{font:inherit;padding:10px;border-radius:8px;border:1px solid var(--line);background:transparent;color:inherit}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}button,a.button{font:inherit;border:1px solid var(--line);border-radius:9px;padding:11px 16px;background:transparent;color:inherit;text-decoration:none;cursor:pointer}.primary{background:var(--accent)!important;color:#fff!important;border-color:var(--accent)!important;font-weight:700}.hidden{display:none!important}.warning{border-left:4px solid var(--warn);padding:10px 12px;background:rgba(255,179,0,.12);margin:12px 0}.success{border-left:4px solid var(--ok);padding:10px 12px}.failure{border-left:4px solid var(--bad);padding:10px 12px}.status{white-space:pre-wrap;font-family:ui-monospace,monospace;font-size:.85rem;max-height:230px;overflow:auto;background:rgba(0,0,0,.12);padding:12px;border-radius:8px}.device{padding:8px 0;border-bottom:1px solid var(--line)}.device:last-child{border:0}.meta{display:grid;grid-template-columns:max-content 1fr;gap:5px 12px}.meta dt{font-weight:700}.meta dd{margin:0;overflow-wrap:anywhere}small,.muted{color:var(--muted)}.topbar{display:flex;align-items:center;gap:12px;margin-bottom:10px}.topbar h1{flex:1}.back-button{padding:8px 12px!important}.device-card{border:1px solid var(--line);border-radius:10px;padding:14px;margin:10px 0;background:rgba(127,127,127,.06)}.device-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap}.badge{display:inline-block;padding:4px 9px;border-radius:999px;font-size:.8rem;font-weight:700;text-transform:capitalize;border:1px solid var(--line)}.badge-confirmed{background:rgba(67,160,71,.15);border-color:var(--ok)}.badge-experimental{background:rgba(255,179,0,.15);border-color:var(--warn)}.badge-detected{background:rgba(119,128,138,.15)}.validation-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:7px;margin-top:12px}.validation-item{display:flex;justify-content:space-between;gap:8px;border-top:1px solid var(--line);padding-top:7px}.state-confirmed{color:var(--ok);font-weight:700}.state-pending{color:var(--warn);font-weight:700}.state-not_applicable,.state-unknown{color:var(--muted)}.diag-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}.diag-tile{border:1px solid var(--line);border-radius:9px;padding:11px}.diag-value{font-weight:700;font-size:1.05rem}.diag-list{margin:8px 0 0;padding-left:20px}.diag-good{color:var(--ok)}.diag-warn{color:var(--warn)}.diag-bad{color:var(--bad)}.nav-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-top:16px}.nav-card{display:flex;flex-direction:column;align-items:flex-start;min-height:120px;text-align:left;padding:16px!important}.nav-card b{font-size:1.05rem;margin-bottom:5px}.nav-card small{color:var(--muted)}.home-status{display:flex;align-items:center;gap:10px;font-size:1.05rem}.status-dot{width:11px;height:11px;border-radius:50%;background:var(--ok);display:inline-block}.status-dot.running{background:var(--accent)}.status-dot.failed{background:var(--bad)}.steps{display:grid;gap:8px;margin:16px 0}.step{display:flex;gap:10px;align-items:center;border:1px solid var(--line);border-radius:9px;padding:10px 12px}.step-mark{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--line);font-size:.8rem;font-weight:700}.step.active{border-color:var(--accent)}.step.active .step-mark{background:var(--accent);color:white}.step.done .step-mark{background:var(--ok);color:white;border-color:var(--ok)}details.advanced{margin-top:14px;border-top:1px solid var(--line);padding-top:12px}details.advanced summary{cursor:pointer;font-weight:600}.page-title{margin-bottom:0}.simple-result{display:flex;justify-content:space-between;gap:12px;align-items:center;border:1px solid var(--line);border-radius:10px;padding:14px;margin:10px 0}.simple-result .result-main{min-width:0}.simple-result .result-actions{flex-shrink:0}.live-status{display:grid;grid-template-columns:max-content 1fr;gap:7px 14px;border:1px solid var(--line);border-radius:10px;padding:14px;margin:14px 0}.live-status dt{font-weight:700}.live-status dd{margin:0;overflow-wrap:anywhere}.command-line{font-family:ui-monospace,monospace;font-size:.84rem;background:rgba(0,0,0,.12);padding:8px;border-radius:7px}.debug-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:14px}.debug-panel{margin-top:10px;max-height:420px}.elapsed{font-variant-numeric:tabular-nums}.yaml-manager{border-top:1px solid var(--line);margin-top:18px;padding-top:16px}.yaml-state{display:grid;grid-template-columns:max-content 1fr;gap:6px 12px;margin-top:12px}.yaml-state dt{font-weight:700}.yaml-state dd{margin:0;overflow-wrap:anywhere}.code-preview{max-height:360px;overflow:auto;white-space:pre;font-family:ui-monospace,monospace;font-size:.82rem;background:rgba(0,0,0,.18);padding:12px;border-radius:8px}
</style>
</head>
<body><main>
<div class="topbar"><button id="backButton" class="back-button" type="button">← Back to Home Assistant</button><h1 id="pageHeading" class="page-title">Switch Vision Discovery</h1></div>
<p id="pageLead" class="lead">Discover switches, review generated results, prepare support bundles, and check installation health.</p>

<section id="homeCard" class="card">
<div class="home-status"><span id="homeStatusDot" class="status-dot"></span><strong id="homeStatus">Ready</strong></div>
<p class="muted">The Web UI stays available while Discovery is idle, running, or complete.</p>
<div class="nav-grid">
<button id="openDiscoveryButton" class="nav-card primary" type="button"><b>Discovery</b><small>Run Discovery or review the latest run.</small></button>
<button id="openDevicesButton" class="nav-card" type="button"><b>Devices</b><small>See detected models, support status, and generated results.</small></button>
<button id="openSupportButton" class="nav-card" type="button"><b>Support My Switch</b><small>Create a privacy-processed contribution bundle.</small></button>
<button id="openDiagnosticsButton" class="nav-card" type="button"><b>Diagnostics</b><small>View installation and generated-file health checks.</small></button>
</div>
</section>

<section id="discoveryCard" class="card hidden">
<h2>Run Discovery</h2>
<p id="discoveryStatus" class="lead">Idle / Ready</p>
<div id="discoverySteps" class="steps">
<div class="step" data-step="0"><span class="step-mark">1</span><span>Validating configured switches</span></div>
<div class="step" data-step="1"><span class="step-mark">2</span><span>Running SNMP walks</span></div>
<div class="step" data-step="2"><span class="step-mark">3</span><span>Detecting exact models and interfaces</span></div>
<div class="step" data-step="3"><span class="step-mark">4</span><span>Generating SNMP2MQTT YAML</span></div>
<div class="step" data-step="4"><span class="step-mark">5</span><span>Generating dashboard card YAML</span></div>
<div class="step" data-step="5"><span class="step-mark">6</span><span>Complete</span></div>
</div>
<dl class="live-status">
<dt>Current stage</dt><dd id="liveStage">Ready</dd>
<dt>Switch</dt><dd id="liveSwitch">Not running</dd>
<dt>Target</dt><dd id="liveTarget">Not running</dd>
<dt>Action</dt><dd id="liveActivity">Waiting to start</dd>
<dt>Command</dt><dd id="liveCommand" class="command-line">No command running</dd>
<dt>Status</dt><dd id="liveRunStatus">Idle / Ready</dd>
<dt>SNMP2MQTT</dt><dd id="liveSnmp2mqtt">Waiting for Discovery</dd>
<dt>Elapsed</dt><dd id="liveElapsed" class="elapsed">00:00</dd>
</dl>
<div class="actions"><button class="primary" id="runDiscoveryButton" type="button">Run Discovery</button><button id="viewResultsButton" type="button">View Results</button><button id="toggleDebugButton" type="button">Show Debug</button></div>
<div class="yaml-manager">
<h3>Generated SNMP2MQTT YAML</h3>
<p>Discovery writes the file used by the existing SNMP2MQTT generated-YAML import option. Keep that import option enabled. After a successful Discovery run, Switch Vision validates the YAML and automatically starts or restarts the SNMP2MQTT add-on.</p>
<dl class="yaml-state"><dt>Generated file</dt><dd id="generatedYamlState">Checking…</dd><dt>Validation</dt><dd id="generatedYamlValidation">Checking…</dd><dt>Last updated</dt><dd id="generatedYamlUpdated">Checking…</dd></dl>
<div class="actions"><button id="previewGeneratedYamlButton" type="button">Preview generated YAML</button><a id="downloadGeneratedYamlButton" class="button" href="#">Download YAML</a></div>
<p id="generatedYamlActionStatus" class="muted"></p><pre id="generatedYamlPreview" class="code-preview hidden"></pre>
</div>
<div id="debugWrap" class="hidden"><div class="debug-head"><strong>Discovery debug output</strong><small>Commands and detailed activity; credentials remain masked.</small></div><div id="discoveryLog" class="status debug-panel"></div></div>
</section>

<section id="devicesCard" class="card hidden">
<h2>Devices</h2>
<p class="lead">Latest detected hardware and generated configuration status.</p>
<div id="devicesSummary"></div>
<div class="actions"><button class="primary" id="refreshDevicesButton" type="button">Refresh Devices</button><button id="devicesRunDiscoveryButton" type="button">Run Discovery</button></div>
<p id="devicesActionStatus" class="muted"></p>
</section>

<section id="diagnosticsCard" class="card hidden">
<h2>Switch Vision Diagnostics</h2>
<p class="lead">Read-only installation, generated-file and discovered-device checks.</p>
<div id="diagnosticsSummary" class="diag-summary"></div>
<div id="diagnosticsMessages"></div>
<h3>Discovered devices</h3><div id="diagnosticsDevices"></div>
<div class="actions"><button class="primary" id="refreshDiagnosticsButton" type="button">Refresh Diagnostics</button><button id="copyDiagnosticsButton" type="button">Copy Diagnostics</button><a id="downloadDiagnosticsButton" class="button" href="#">Download Diagnostics Report</a><button id="diagnosticsRunDiscoveryButton" type="button">Run Discovery</button></div>
<p id="diagnosticsActionStatus" class="muted"></p>
</section>

<section id="createCard" class="card hidden">
<h2>Support My Switch</h2>
<p class="lead">Prepare a privacy-processed contribution bundle. Nothing is sent automatically.</p>
<h3>Create contribution</h3>
<div class="grid">
<label class="option"><input id="mask_management_ips" type="checkbox"><span><b>Mask management IPs</b><br><small>Recommended for anything shared outside your private network.</small></span></label>
<label class="option"><input id="mask_mac_addresses" type="checkbox"><span><b>Mask MAC addresses</b><br><small>Replaces hardware addresses while preserving useful structure.</small></span></label>
<label class="option"><input id="mask_hostnames" type="checkbox"><span><b>Mask hostnames</b><br><small>Removes detected hostnames and domain names.</small></span></label>
<label class="option"><input id="mask_vlan_names" type="checkbox"><span><b>Mask VLAN names</b><br><small>Enable when VLAN labels contain private information.</small></span></label>
<label class="option"><input id="mask_interface_descriptions" type="checkbox"><span><b>Mask interface descriptions</b><br><small>Enable when port descriptions contain names or locations.</small></span></label>
</div>
<div id="privacyWarning" class="warning hidden"><b>Privacy warning:</b> one or more common identity masks are disabled. The bundle is still credential-sanitized, but review it carefully before sending.</div>
<div class="grid">
<label class="field"><span><b>Recognition</b></span><select id="contributor_type"><option value="anonymous">Anonymous</option><option value="first_name">First name</option><option value="full_name">Full name</option><option value="github">GitHub username</option><option value="forum">Forum username</option></select></label>
<label class="field" id="recognitionValueWrap"><span><b>Name or username</b></span><input id="contributor_value" type="text" maxlength="120" placeholder="Optional recognition"></label>
</div>
<div class="actions"><button class="primary" id="createButton">Create contribution</button></div>
</section>

<section id="progressCard" class="card hidden"><h2>Preparing contribution</h2><p id="progressMessage">Starting…</p><div id="logTail" class="status"></div></section>

<section id="readyCard" class="card hidden">
<h2>Contribution ready</h2>
<div id="qualityBanner"></div>
<dl class="meta"><dt>Contribution ID</dt><dd id="contributionId"></dd><dt>Switch Vision version</dt><dd id="version"></dd><dt>Archive</dt><dd id="archiveName"></dd><dt>Archive size</dt><dd id="archiveSize"></dd></dl>
<h3>Detected hardware</h3><div id="devices"></div>
<div class="actions"><a id="prepareEmail" class="button primary">Prepare Email</a><a id="downloadArchive" class="button">Download Archive</a><a id="mailto" class="button">Open Email Without Attachment</a><button id="createAnother">Create Another Contribution</button></div>
<p><small><b>Prepare Email</b> downloads a standard .eml message with the ZIP attached. Open it in your email application, review it, then press Send.</small></p>
</section>

<section id="importantCard" class="card hidden"><h2>Important</h2><p>Credentials are always removed from the temporary copy. Automated masking cannot identify every possible private value, so review the archive before sharing it.</p><p class="muted">Files are stored in <code>/share/switch_vision/contributions/</code>.</p></section>
</main>
<script>
const $=id=>document.getElementById(id); let defaultsLoaded=false; let polling=null; let elapsedTicker=null; let refreshInFlight=false; let currentView='home'; let lastRunning=false; let lastDiscoveryState={};
function endpoint(path){const href=location.href.endsWith('/')?location.href:location.href+'/';return new URL(path,href).toString()}
function fmtBytes(n){if(!Number.isFinite(n))return 'Unknown';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return `${n.toFixed(i?1:0)} ${u[i]}`}
function updateRecognition(){const anon=$('contributor_type').value==='anonymous';$('recognitionValueWrap').classList.toggle('hidden',anon);if(anon)$('contributor_value').value=''}
function updateWarning(){const unsafe=!$('mask_management_ips').checked||!$('mask_mac_addresses').checked||!$('mask_hostnames').checked;$('privacyWarning').classList.toggle('hidden',!unsafe)}
function setForm(d){for(const k of ['mask_management_ips','mask_mac_addresses','mask_hostnames','mask_vlan_names','mask_interface_descriptions'])$(k).checked=!!d[k];$('contributor_type').value=d.contributor_type||'anonymous';$('contributor_value').value=d.contributor_value||'';updateRecognition();updateWarning();defaultsLoaded=true}
function payload(){return {mask_management_ips:$('mask_management_ips').checked,mask_mac_addresses:$('mask_mac_addresses').checked,mask_hostnames:$('mask_hostnames').checked,mask_vlan_names:$('mask_vlan_names').checked,mask_interface_descriptions:$('mask_interface_descriptions').checked,contributor_type:$('contributor_type').value,contributor_value:$('contributor_value').value}}
function mailto(latest){const subject=`Switch Vision Contribution - ${latest.contribution_id}`;const body=`Hello,\n\nPlease find attached my Switch Vision contribution bundle.\n\nContribution ID: ${latest.contribution_id}\nSwitch Vision version: ${latest.version}\n\nWhat works:\n\nWhat is missing or incorrect:\n\nAnything unusual about this switch:\n\nThank you.`;return `mailto:switch-vision@zemerdon.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`}
function statusLabel(value){return String(value||'unknown').replaceAll('_',' ')}
function validationItem(label,value){const item=document.createElement('div');item.className='validation-item';const name=document.createElement('span');name.textContent=label;const state=document.createElement('span');const normalized=String(value||'unknown').toLowerCase();state.className=`state-${normalized}`;state.textContent=statusLabel(normalized);item.append(name,state);return item}
function deviceCard(d){const card=document.createElement('div');card.className='device-card';const head=document.createElement('div');head.className='device-head';const title=document.createElement('div');const strong=document.createElement('strong');strong.textContent=d.model||'Unknown model';title.appendChild(strong);const detail=document.createElement('div');detail.className='muted';detail.textContent=`${d.vendor_name||d.vendor||'Unknown vendor'}${d.family&&d.family!=='unknown'?` · ${d.family}`:''}`;title.appendChild(detail);const status=String(d.registry_status||'detected').toLowerCase();const badge=document.createElement('span');badge.className=`badge badge-${status}`;badge.textContent=statusLabel(status);head.append(title,badge);card.appendChild(head);const meta=document.createElement('div');meta.className='meta';meta.style.marginTop='10px';const fields=[['Registry match',d.registry_match?'Yes':'No'],['Last validated',d.registry_last_validated_version?`v${d.registry_last_validated_version}`:'Not recorded'],['Physical interfaces',d.physical_count??0],['RJ45 interfaces',d.rj45_count??0]];for(const [label,value] of fields){const dt=document.createElement('dt');dt.textContent=label;const dd=document.createElement('dd');dd.textContent=String(value);meta.append(dt,dd)}card.appendChild(meta);const validation=d.registry_validation||{};const grid=document.createElement('div');grid.className='validation-grid';for(const [label,key] of [['Exact model','exact_model_detection'],['RJ45 mapping','rj45_mapping'],['PoE','poe'],['System sensors','system_sensors'],['Uplinks','uplinks'],['Stack','stack']])grid.appendChild(validationItem(label,validation[key]));card.appendChild(grid);return card}
function setView(view){currentView=view;const isHome=view==='home';$('backButton').textContent=isHome?'← Back to Home Assistant':'← Back';const titles={home:['Switch Vision Discovery','Discover switches, review generated results, prepare support bundles, and check installation health.'],discovery:['Discovery','Run a guided discovery job and review its progress.'],devices:['Devices','Latest detected hardware and generated configuration status.'],support:['Support My Switch','Prepare a privacy-processed contribution bundle. Nothing is sent automatically.'],diagnostics:['Diagnostics','Read-only installation, generated-file and discovered-device checks.'],progress:['Support My Switch','Preparing your contribution bundle.'],ready:['Support My Switch','Your contribution bundle is ready to review.']};const title=titles[view]||titles.home;$('pageHeading').textContent=title[0];$('pageLead').textContent=title[1];$('homeCard').classList.toggle('hidden',view!=='home');$('discoveryCard').classList.toggle('hidden',view!=='discovery');$('devicesCard').classList.toggle('hidden',view!=='devices');$('createCard').classList.toggle('hidden',view!=='support');$('importantCard').classList.toggle('hidden',view!=='support');$('diagnosticsCard').classList.toggle('hidden',view!=='diagnostics');$('progressCard').classList.toggle('hidden',view!=='progress');$('readyCard').classList.toggle('hidden',view!=='ready');window.scrollTo({top:0,behavior:'smooth'})}
function goBack(){if(!$('homeCard').classList.contains('hidden')){try{if(history.length>1){history.back();return}}catch(_e){}try{window.top.location.href='/';return}catch(_e){}location.href='/';return}setView('home')}
function showLatest(latest){if(!latest){$('readyCard').classList.add('hidden');return}$('contributionId').textContent=latest.contribution_id;$('version').textContent=latest.version;$('archiveName').textContent=latest.archive;$('archiveSize').textContent=fmtBytes(latest.archive_size);const q=$('qualityBanner');q.className=latest.ready_to_send?'success':'failure';q.textContent=`Bundle quality: ${latest.quality}${latest.ready_to_send?'':' — review required before sharing'}`;$('devices').innerHTML='';for(const d of latest.devices||[])$('devices').appendChild(deviceCard(d));if(!(latest.devices||[]).length)$('devices').textContent='No devices were detected.';$('prepareEmail').classList.toggle('hidden',!latest.email);if(latest.email)$('prepareEmail').href=endpoint(`download/${encodeURIComponent(latest.email)}`);$('downloadArchive').href=endpoint(`download/${encodeURIComponent(latest.archive)}`);$('mailto').href=mailto(latest)}

function diagTile(label,value,state=''){const tile=document.createElement('div');tile.className='diag-tile';const l=document.createElement('div');l.className='muted';l.textContent=label;const v=document.createElement('div');v.className=`diag-value ${state}`;v.textContent=value;tile.append(l,v);return tile}
function renderDiagnostics(d){const summary=$('diagnosticsSummary');summary.innerHTML='';const discovery=d.discovery||{};const registry=d.registry||{};const files=d.files||{};summary.append(diagTile('Switch Vision version',`v${d.version||'Unknown'}`),diagTile('Discovery add-on',d.service||'Unknown',d.service==='Running'?'diag-good':'diag-bad'),diagTile('Discovery status',discovery.running?'Running':(discovery.message||'Idle / Ready'),discovery.success===false?'diag-bad':'diag-good'),diagTile('Device registry',registry.loaded?`Loaded · ${registry.entries||0} entries`:'Unavailable',registry.loaded?'diag-good':'diag-bad'),diagTile('SNMP2MQTT YAML',files.generated_yaml?.found?'Found':'Missing',files.generated_yaml?.found?'diag-good':'diag-warn'),diagTile('Dashboard YAML',files.generated_card?.found?'Found':'Missing',files.generated_card?.found?'diag-good':'diag-warn'),diagTile('Contribution workflow',d.contribution_workflow?.ready?'Ready':'Unavailable',d.contribution_workflow?.ready?'diag-good':'diag-bad'));
const messages=$('diagnosticsMessages');messages.innerHTML='';for(const [kind,items] of [['failure',d.errors||[]],['warning',d.warnings||[]]]){if(!items.length)continue;const box=document.createElement('div');box.className=kind;const ul=document.createElement('ul');ul.className='diag-list';for(const item of items){const li=document.createElement('li');li.textContent=`${kind==='failure'?'ERROR':'WARNING'}: ${item}`;ul.appendChild(li)}box.appendChild(ul);messages.appendChild(box)}
const devices=$('diagnosticsDevices');devices.innerHTML='';for(const item of d.devices||[]){const normalized={model:item.model,vendor_name:item.name,family:item.family,registry_status:item.registry_status,registry_match:item.registry_match,registry_last_validated_version:item.last_validated_version,physical_count:item.physical_interfaces,rj45_count:item.rj45_interfaces,registry_validation:item.validation};const card=deviceCard(normalized);const extra=document.createElement('div');extra.className='muted';extra.style.marginTop='10px';extra.textContent=`SNMP walk: ${item.walk_found?'Available':'Unavailable'} · Uplinks detected: ${item.uplink_interfaces||0} · Mapping profile: ${item.mapping_profile||'Not assigned'} · Calibration profile: ${item.calibration_profile||'Not assigned'}`;card.appendChild(extra);devices.appendChild(card)}if(!(d.devices||[]).length)devices.textContent='No capability files were found. Run Discovery to populate device diagnostics.'}
function renderDevices(d){const root=$('devicesSummary');root.innerHTML='';for(const item of d.devices||[]){const row=document.createElement('div');row.className='simple-result';const main=document.createElement('div');main.className='result-main';const title=document.createElement('strong');title.textContent=item.model||'Unknown model';const line=document.createElement('div');line.className='muted';const support=statusLabel(item.registry_status||'detected');line.textContent=`Discovery: ${item.walk_found?'Passed':'Needs attention'} · Support: ${support} · Ports: ${item.rj45_interfaces||0} RJ45 + ${item.uplink_interfaces||0} uplinks`;if(item.compatibility_mode){const warning=document.createElement('div');warning.className='notice warning';warning.textContent=`Experimental model override: ${item.detected_model||item.model} → ${item.effective_model}`;main.append(title,line,warning)}else{main.append(title,line)}const generated=document.createElement('div');generated.className='muted';generated.textContent=`Sensor configuration: ${d.files?.generated_yaml?.found?'Ready':'Not available'} · Dashboard configuration: ${d.files?.generated_card?.found?'Ready':'Not available'}`;if(!item.compatibility_mode){}main.append(generated);const action=document.createElement('button');action.type='button';action.textContent='View Details';action.addEventListener('click',loadDiagnostics);row.append(main,action);root.appendChild(row)}if(!(d.devices||[]).length)root.innerHTML='<p class="muted">No discovered devices are available yet. Run Discovery first.</p>'}
async function fetchDiagnosticsData(){const r=await fetch(endpoint('api/diagnostics'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Diagnostics request failed');return d}
async function refreshDevicesData(showStatus=true){if(showStatus)$('devicesActionStatus').textContent='Refreshing devices…';try{const d=await fetchDiagnosticsData();renderDevices(d);$('devicesActionStatus').textContent=`Updated ${d.generated_at||''}`}catch(e){$('devicesActionStatus').textContent=`Could not load devices: ${e}`}}
async function refreshDiagnosticsData(showStatus=true){if(showStatus)$('diagnosticsActionStatus').textContent='Refreshing diagnostics…';try{const d=await fetchDiagnosticsData();window.latestDiagnostics=d;renderDiagnostics(d);$('downloadDiagnosticsButton').href=endpoint('download/diagnostics.txt');$('diagnosticsActionStatus').textContent=`Updated ${d.generated_at||''}`}catch(e){$('diagnosticsActionStatus').textContent=`Could not load diagnostics: ${e}`}}
async function loadDevices(){setView('devices');await refreshDevicesData()}
async function loadDiagnostics(){setView('diagnostics');await refreshDiagnosticsData()}
async function copyTextWithFallback(text){if(navigator.clipboard&&typeof navigator.clipboard.writeText==='function'){try{await navigator.clipboard.writeText(text);return true}catch(_e){}}const area=document.createElement('textarea');area.value=text;area.setAttribute('readonly','');area.style.position='fixed';area.style.left='-9999px';area.style.top='0';area.style.opacity='0';document.body.appendChild(area);area.focus();area.select();area.setSelectionRange(0,area.value.length);let copied=false;try{copied=document.execCommand('copy')}catch(_e){copied=false}document.body.removeChild(area);return copied}
async function copyDiagnostics(){const status=$('diagnosticsActionStatus');status.textContent='Copying diagnostics…';try{const r=await fetch(endpoint('download/diagnostics.txt'),{cache:'no-store'});if(!r.ok)throw new Error(`Diagnostics download failed (${r.status})`);const text=await r.text();const copied=await copyTextWithFallback(text);if(!copied)throw new Error('Clipboard access is unavailable in this browser context');status.textContent='Diagnostics copied to clipboard.'}catch(e){status.textContent=`Could not copy diagnostics: ${e}`}}

function discoveryStage(state){if(!state.running)return state.success===true?5:-1;if((state.phase||'')==='preparing')return -1;const text=((state.log_tail||[]).join(' ')+' '+(state.message||'')+' '+(state.stage||'')).toLowerCase();if(text.includes('dashboard card')||text.includes('generated dashboard'))return 4;if(text.includes('generated yaml')||text.includes('snmp2mqtt')||text.includes('generator'))return 3;if(text.includes('model/platform')||text.includes('interface mapping')||text.includes('parser summary')||text.includes('exact models'))return 2;if(text.includes('snmp walk')||text.includes('walking')||text.includes('oid trees'))return 1;if(text.includes('configured switches')||text.includes('validating'))return 0;return 0}
function updateSteps(state){const current=discoveryStage(state);for(const el of document.querySelectorAll('#discoverySteps .step')){const n=Number(el.dataset.step);el.classList.toggle('done',state.success===true||(current>=0&&n<current));el.classList.toggle('active',state.running&&(state.phase||'')!=='preparing'&&n===current)} }
let debugVisible=false;
function elapsedText(started,finished=null){if(!started)return '00:00';const start=Date.parse(started);const end=finished?Date.parse(finished):Date.now();if(!Number.isFinite(start)||!Number.isFinite(end))return '00:00';const total=Math.max(0,Math.floor((end-start)/1000));const h=Math.floor(total/3600);const m=Math.floor((total%3600)/60);const s=total%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function updateElapsedClock(){const state=lastDiscoveryState||{};if(!$('liveElapsed'))return;$('liveElapsed').textContent=state.running?elapsedText(state.started_at):((state.started_at&&state.finished_at)?elapsedText(state.started_at,state.finished_at):'00:00')}
function startElapsedTicker(){if(elapsedTicker)return;elapsedTicker=setInterval(()=>{if(!document.hidden&&lastDiscoveryState?.running)updateElapsedClock()},250)}
function showDiscovery(d){const state=d||{};lastDiscoveryState=state;const running=!!state.running;const phase=state.phase||(running?'running':(state.success===true?'complete':(state.success===false?'failed':'idle')));const preparing=running&&phase==='preparing';const active=running&&!preparing;const btn=$('runDiscoveryButton');btn.disabled=running;btn.textContent=preparing?'Preparing…':(active?'Discovery Running…':'Run Discovery');let label='Idle / Ready';if(preparing)label='Preparing Discovery';else if(active)label='Discovery running';else if(state.success===true)label='Discovery complete';else if(state.success===false)label=`Discovery failed: ${state.message||'Unknown error'}`;$('discoveryStatus').textContent=label;$('homeStatus').textContent=preparing?'Preparing Discovery':(active?'Discovery running':(state.success===true?'Last discovery complete':(state.success===false?'Discovery needs attention':'Ready')));$('homeStatusDot').className=`status-dot${running?' running':(state.success===false?' failed':'')}`;$('liveStage').textContent=preparing?'Preparing Discovery':(state.stage||label);$('liveSwitch').textContent=preparing?'Waiting':(state.switch||(!running&&state.success===true?'All configured switches':'Not running'));$('liveTarget').textContent=preparing?'Waiting':(state.target||'Not running');$('liveActivity').textContent=preparing?'Validating configured switches':(state.activity||label);$('liveCommand').textContent=preparing?'Not started':(state.command||'No command running');$('liveRunStatus').textContent=preparing?'Preparing':(active?'Running':(state.success===true?'Complete':(state.success===false?'Failed':'Idle / Ready')));const snmp=state.snmp2mqtt||{};$('liveSnmp2mqtt').textContent=snmp.message||snmp.status||'Waiting for Discovery';updateElapsedClock();const lines=state.log_tail||[];$('discoveryLog').textContent=lines.length?lines.join('\n'):'No debug details are available yet.';updateSteps(state)}
async function loadGeneratedYamlStatus(){try{const r=await fetch(endpoint('api/generated-yaml/status'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not read generated YAML status');const found=!!d.generated?.found;$('generatedYamlState').textContent=found?`${d.generated.path||'generated-snmp2mqtt.yaml'} · ${d.generated.size||0} bytes`:'Not generated';$('generatedYamlValidation').textContent=d.validation?.valid?'Valid':`Invalid · ${d.validation?.error||'validation failed'}`;$('generatedYamlUpdated').textContent=d.generated?.modified||'Not available';$('downloadGeneratedYamlButton').href=endpoint('download/generated-snmp2mqtt.yaml')}catch(e){$('generatedYamlActionStatus').textContent=`Could not load generated YAML status: ${e}`}}
async function previewGeneratedYaml(){const status=$('generatedYamlActionStatus');try{const r=await fetch(endpoint('api/generated-yaml/preview'),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Preview failed');$('generatedYamlPreview').textContent=d.text||'';$('generatedYamlPreview').classList.remove('hidden');status.textContent='Generated YAML preview loaded.'}catch(e){status.textContent=`Could not preview generated YAML: ${e}`}}
function toggleDebug(){debugVisible=!debugVisible;$('debugWrap').classList.toggle('hidden',!debugVisible);$('toggleDebugButton').textContent=debugVisible?'Hide Debug':'Show Debug'}
async function runDiscovery(){const btn=$('runDiscoveryButton');btn.disabled=true;$('discoveryStatus').textContent='Preparing Discovery';try{const r=await fetch(endpoint('api/discovery/start'),{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start Discovery');await refresh()}catch(e){$('discoveryStatus').textContent=`Could not start Discovery: ${e}`;btn.disabled=false}}

function schedulePoll(running=lastRunning){if(polling){clearTimeout(polling);polling=null}if(document.hidden)return;polling=setTimeout(refresh,running?1000:5000)}
async function refresh(){if(refreshInFlight)return;refreshInFlight=true;try{const r=await fetch(endpoint('api/status'),{cache:'no-store'});const d=await r.json();if(!defaultsLoaded)setForm(d.defaults);showDiscovery(d.discovery);const contributionRunning=!!d.job.running;const discoveryRunning=!!d.discovery?.running;lastRunning=contributionRunning||discoveryRunning;$('createButton').disabled=contributionRunning;if(contributionRunning&&currentView!=='discovery')setView('progress');$('progressMessage').textContent=d.job.message||'Working…';$('logTail').textContent=(d.job.log_tail||[]).join('\n');if(!contributionRunning&&d.job.success===false&&currentView==='progress'){$('progressMessage').textContent=`Failed: ${d.job.message}`}if(!contributionRunning){showLatest(d.latest);if(d.job.success===true&&d.latest&&currentView==='progress')setView('ready')}if(currentView==='devices')await refreshDevicesData(false);else if(currentView==='diagnostics')await refreshDiagnosticsData(false);else if(currentView==='discovery')await loadGeneratedYamlStatus()}catch(e){if(currentView==='progress')$('progressMessage').textContent=`Could not contact Support My Switch: ${e}`;else $('homeStatus').textContent=`Connection problem: ${e}`}finally{refreshInFlight=false;schedulePoll(lastRunning)}}
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(polling){clearTimeout(polling);polling=null}}else{updateElapsedClock();refresh()}});window.addEventListener('focus',()=>{if(!document.hidden){updateElapsedClock();refresh()}});
async function create(){const btn=$('createButton');btn.disabled=true;setView('progress');$('progressMessage').textContent='Starting…';try{const r=await fetch(endpoint('api/create'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not start contribution');await refresh()}catch(e){$('progressMessage').textContent=`Could not start: ${e}`;btn.disabled=false}}
for(const id of ['mask_management_ips','mask_mac_addresses','mask_hostnames'])$(id).addEventListener('change',updateWarning);$('contributor_type').addEventListener('change',updateRecognition);$('createButton').addEventListener('click',create);$('createAnother').addEventListener('click',()=>setView('support'));$('backButton').addEventListener('click',goBack);$('openDiscoveryButton').addEventListener('click',()=>{setView('discovery');loadGeneratedYamlStatus()});$('openDevicesButton').addEventListener('click',loadDevices);$('openSupportButton').addEventListener('click',()=>setView('support'));$('runDiscoveryButton').addEventListener('click',runDiscovery);$('viewResultsButton').addEventListener('click',loadDevices);$('toggleDebugButton').addEventListener('click',toggleDebug);$('previewGeneratedYamlButton').addEventListener('click',previewGeneratedYaml);$('devicesRunDiscoveryButton').addEventListener('click',()=>{setView('discovery');runDiscovery()});$('refreshDevicesButton').addEventListener('click',loadDevices);$('openDiagnosticsButton').addEventListener('click',loadDiagnostics);$('refreshDiagnosticsButton').addEventListener('click',loadDiagnostics);$('copyDiagnosticsButton').addEventListener('click',copyDiagnostics);$('diagnosticsRunDiscoveryButton').addEventListener('click',()=>{setView('discovery');runDiscovery()});setView('home');startElapsedTicker();refresh();
</script></body></html>"""


class SupportHandler(BaseHTTPRequestHandler):
    server_version = "SwitchVisionSupport/1.0"

    @property
    def app(self) -> "SupportServer":
        return self.server  # type: ignore[return-value]

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[Support My Switch Web] {self.address_string()} - {fmt % args}", flush=True)

    def _json(self, data: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _html(self) -> None:
        body = _PAGE.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _download(self, name: str) -> None:
        safe_name = Path(unquote(name)).name
        if safe_name != unquote(name) or not safe_name.startswith("Switch_Vision_Contribution_"):
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        path = self.app.contributions_dir / safe_name
        if not path.is_file() or path.suffix.lower() not in {".zip", ".eml", ".html"}:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(path.stat().st_size))
        self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with path.open("rb") as source:
            while chunk := source.read(1024 * 128):
                self.wfile.write(chunk)

    def _diagnostics_download(self) -> None:
        data = _diagnostics_snapshot(self.app.version)
        body = _diagnostics_text(data).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", 'attachment; filename="switch-vision-diagnostics.txt"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path.rstrip("/") or "/"
        if path == "/":
            self._html()
        elif path == "/api/status":
            self._json({
                "job": _state_snapshot(),
                "latest": _latest_contribution(self.app.contributions_dir),
                "defaults": _defaults(self.app.options_file),
                "discovery": _discovery_state_snapshot(),
            })
        elif path == "/api/health":
            self._json({"status": "ok", "version": self.app.version})
        elif path == "/api/diagnostics":
            self._json(_diagnostics_snapshot(self.app.version))
        elif path == "/api/generated-yaml/status":
            self._json(_generated_yaml_status())
        elif path == "/api/generated-yaml/preview":
            result = _validate_snmp2mqtt_yaml(DEFAULT_GENERATED_SNMP2MQTT)
            if not result.get("valid"):
                self._json({"error": result.get("error")}, HTTPStatus.BAD_REQUEST)
            else:
                self._json({"text": result.get("text"), "sha256": result.get("sha256")})
        elif path == "/download/generated-snmp2mqtt.yaml":
            if not DEFAULT_GENERATED_SNMP2MQTT.is_file():
                self.send_error(HTTPStatus.NOT_FOUND)
            else:
                body = DEFAULT_GENERATED_SNMP2MQTT.read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/yaml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Content-Disposition", 'attachment; filename="generated-snmp2mqtt.yaml"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        elif path == "/download/diagnostics.txt":
            self._diagnostics_download()
        elif path.startswith("/download/"):
            self._download(path.split("/download/", 1)[1])
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path.rstrip("/")
        if path == "/api/discovery/start":
            if _discovery_state_snapshot().get("running"):
                self._json({"error": "Discovery is already running."}, HTTPStatus.CONFLICT)
                return
            _set_discovery_state(
                running=True,
                started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                finished_at=None,
                success=None,
                message="Preparing Discovery",
                log_tail=[],
                stage="Preparing Discovery",
                switch="",
                target="",
                command="",
                activity="Validating configured switches",
                phase="preparing",
                snmp2mqtt={"status": "Waiting", "action": "none", "slug": None, "state": None, "message": "Waiting for Discovery to complete"},
            )
            thread = threading.Thread(target=_run_discovery, args=(self.app.discovery_script,), daemon=True)
            thread.start()
            self._json({"started": True}, HTTPStatus.ACCEPTED)
            return
        if path != "/api/create":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        if _state_snapshot().get("running"):
            self._json({"error": "A contribution is already being prepared."}, HTTPStatus.CONFLICT)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 65536:
                raise ValueError("Invalid request size.")
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            settings = _validate_request(data)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        _set_state(
            running=True,
            started_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            finished_at=None,
            success=None,
            message="Starting contribution…",
            log_tail=[],
        )
        thread = threading.Thread(
            target=_run_bundle,
            args=(settings, self.app.support_script, self.app.contributions_dir, self.app.version),
            daemon=True,
        )
        thread.start()
        self._json({"started": True}, HTTPStatus.ACCEPTED)


class SupportServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], handler: type[BaseHTTPRequestHandler], *, contributions_dir: Path, options_file: Path, support_script: Path, discovery_script: Path, version: str) -> None:
        super().__init__(address, handler)
        self.contributions_dir = contributions_dir
        self.options_file = options_file
        self.support_script = support_script
        self.discovery_script = discovery_script
        self.version = version


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8099)
    parser.add_argument("--contributions-dir", type=Path, default=DEFAULT_CONTRIBUTIONS_DIR)
    parser.add_argument("--options-file", type=Path, default=DEFAULT_OPTIONS_FILE)
    parser.add_argument("--support-script", type=Path, default=DEFAULT_SUPPORT_SCRIPT)
    parser.add_argument("--discovery-script", type=Path, default=DEFAULT_DISCOVERY_SCRIPT)
    parser.add_argument("--version", default=os.environ.get("SWITCH_VISION_DISCOVERY_VERSION", "unknown"))
    args = parser.parse_args()
    _ensure_runtime_paths()
    args.contributions_dir.mkdir(parents=True, exist_ok=True)
    server = SupportServer(
        (args.host, args.port),
        SupportHandler,
        contributions_dir=args.contributions_dir,
        options_file=args.options_file,
        support_script=args.support_script,
        discovery_script=args.discovery_script,
        version=args.version,
    )
    print(f"[Support My Switch Web] Listening on {args.host}:{args.port}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
