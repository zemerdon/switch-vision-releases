#!/usr/bin/env sh
set -eu

SWITCH_VISION_DISCOVERY_VERSION="1.8.0"
export SWITCH_VISION_DISCOVERY_VERSION

mkdir -p /share/switch_vision /share/switch_vision/contributions
touch /share/switch_vision/discovery-web.log

echo "Switch Vision Discovery service starting in idle/ready mode."
echo "Support My Switch Web UI: listening on Home Assistant Ingress (port 8099)."
exec python3 /support_web.py \
  --port 8099 \
  --version "$SWITCH_VISION_DISCOVERY_VERSION" \
  --discovery-script /discovery_job.sh
