#!/usr/bin/env python3
"""Sanitize a copied Switch Vision data folder before contribution packaging."""
from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import re
from pathlib import Path

TEXT_EXTENSIONS = {
    ".txt", ".log", ".json", ".yaml", ".yml", ".csv", ".conf", ".cfg",
    ".ini", ".md", ".xml", ".sh", ".env",
}
MAX_TEXT_BYTES = 64 * 1024 * 1024

IPV4_RE = re.compile(r"(?<![\w.])(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?![\w.])")
MAC_RE = re.compile(r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}(?![0-9a-f])")

SECRET_LINE_RE = re.compile(
    r"(?im)^(?P<prefix>\s*[\"']?(?:[-\w.]*?(?:snmp_community|community|mqtt_username|mqtt_password|password|passwd|token|access_token|api_key|secret|client_secret)[-\w.]*?)[\"']?\s*[:=]\s*)(?P<value>.*)$"
)
URL_CREDENTIAL_RE = re.compile(r"(?i)(?P<scheme>\b(?:mqtt|mqtts|http|https)://)(?P<creds>[^/@\s]+@)")
SYSNAME_WALK_RE = re.compile(r"(?im)^(?P<prefix>.*(?:SNMPv2-MIB::sysName\.0|\.?1\.3\.6\.1\.2\.1\.1\.5\.0).*?(?:STRING:|=)\s*)(?P<value>.*)$")
HOST_KEY_RE = re.compile(
    r"(?im)^(?P<prefix>\s*[\"']?(?:hostname|host_name|sys_name|sysname|domain|domain_name|switch_host|management_host|system_name|device_name)[\"']?\s*[:=]\s*)(?P<value>.*)$"
)
CISCO_LOCAL_HOSTNAME_RE = re.compile(
    r"(?im)^(?P<prefix>\s*Cisco\s+local\s+hostname\s*[:=]\s*)(?P<value>.*)$"
)
CISCO_LOCAL_HOSTNAME_OID_RE = re.compile(
    r"(?im)^(?P<prefix>.*\.?1\.3\.6\.1\.4\.1\.9\.2\.1\.3\.0\s*=\s*(?:STRING:\s*)?)(?P<value>.*)$"
)
HOST_LABEL_RE = re.compile(
    r"(?im)^(?P<prefix>\s*(?:[-*]\s*)?(?:host(?:name)?|system\s+name|sysname|device\s+name|domain(?:\s+name)?)\s*[:=]\s*)(?P<value>.*)$"
)
VLAN_VALUE_LINE_RE = re.compile(
    r"(?im)^(?P<prefix>.*(?:vlanName|vmVlanName|vlan_name|VLAN name).*?(?:STRING:|[:=])\s*)(?P<value>.*)$"
)
VLAN_TOKEN_RE = re.compile(r"(?i)(?<!masked-)\bVLAN(?:[-_ ]?)(?P<id>\d+)\b")
ALIAS_WALK_RE = re.compile(
    r"(?im)^(?P<prefix>.*(?:IF-MIB::ifAlias|ifAlias\.|\.?1\.3\.6\.1\.2\.1\.31\.1\.1\.1\.18\.\d+).*?(?:STRING:|=)\s*)(?P<value>.*)$"
)
ALIAS_KEY_RE = re.compile(
    r"(?im)^(?P<prefix>\s*[\"']?(?:interface_alias|if_alias|ifalias|interface_description|port_description|alias)[\"']?\s*[:=]\s*)(?P<value>.*)$"
)
HOST_JSON_RE = re.compile(r'(?i)(?P<prefix>["\'](?:hostname|host_name|sys_name|sysname|domain|domain_name|switch_host|management_host|system_name|device_name)["\']\s*:\s*)(?P<value>["\'][^"\']*["\'])')
ALIAS_JSON_RE = re.compile(r'(?i)(?P<prefix>["\'](?:interface_alias|if_alias|ifalias|interface_description|port_description|alias)["\']\s*:\s*)(?P<value>["\'][^"\']*["\'])')


def bool_arg(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


def stable_number(value: str, modulo: int) -> int:
    digest = hashlib.sha256(value.encode("utf-8", errors="ignore")).digest()
    return int.from_bytes(digest[:4], "big") % modulo


def masked_ip(value: str) -> str:
    return f"198.51.100.{stable_number(value, 254) + 1}"


def masked_mac(value: str) -> str:
    digest = hashlib.sha256(value.lower().encode()).digest()
    octets = [0x02, digest[0], digest[1], digest[2], digest[3], digest[4]]
    return ":".join(f"{part:02x}" for part in octets)


def replace_value_line(match: re.Match[str], placeholder: str) -> str:
    raw = match.group("value")
    stripped = raw.strip()
    suffix = "," if stripped.endswith(",") else ""
    stripped = stripped[:-1].rstrip() if suffix else stripped
    quote = '"' if stripped.startswith('"') else "'" if stripped.startswith("'") else ""
    replacement = f"{quote}{placeholder}{quote}" if quote else placeholder
    return match.group("prefix") + replacement + suffix


def looks_text(path: Path) -> bool:
    if path.suffix.lower() in TEXT_EXTENSIONS:
        return True
    try:
        sample = path.read_bytes()[:4096]
    except OSError:
        return False
    return b"\x00" not in sample


def sanitize_text(text: str, options: dict[str, bool], counts: dict[str, int]) -> str:
    def secret_repl(match: re.Match[str]) -> str:
        counts["secrets_removed"] += 1
        return match.group("prefix") + '"<REDACTED>"'

    text = SECRET_LINE_RE.sub(secret_repl, text)

    def url_repl(match: re.Match[str]) -> str:
        counts["url_credentials_removed"] += 1
        return match.group("scheme") + "<REDACTED>@"

    text = URL_CREDENTIAL_RE.sub(url_repl, text)

    if options["mask_management_ips"]:
        def ip_repl(match: re.Match[str]) -> str:
            counts["ip_addresses_masked"] += 1
            return masked_ip(match.group(0))
        text = IPV4_RE.sub(ip_repl, text)

    if options["mask_mac_addresses"]:
        def mac_repl(match: re.Match[str]) -> str:
            counts["mac_addresses_masked"] += 1
            return masked_mac(match.group(0))
        text = MAC_RE.sub(mac_repl, text)

    if options["mask_hostnames"]:
        def host_repl(match: re.Match[str]) -> str:
            counts["hostnames_masked"] += 1
            return replace_value_line(match, "masked-switch")
        text = SYSNAME_WALK_RE.sub(host_repl, text)
        text = HOST_KEY_RE.sub(host_repl, text)
        text = HOST_LABEL_RE.sub(host_repl, text)
        text = CISCO_LOCAL_HOSTNAME_RE.sub(host_repl, text)
        text = CISCO_LOCAL_HOSTNAME_OID_RE.sub(host_repl, text)
        text = HOST_JSON_RE.sub(host_repl, text)

    if options["mask_interface_descriptions"]:
        def alias_repl(match: re.Match[str]) -> str:
            value = match.group("value").strip().rstrip(",").strip('"\'')
            if not value or value in {"masked-interface-description", "<REDACTED>"}:
                return match.group(0)
            counts["interface_descriptions_masked"] += 1
            return replace_value_line(match, "masked-interface-description")
        text = ALIAS_WALK_RE.sub(alias_repl, text)
        text = ALIAS_KEY_RE.sub(alias_repl, text)
        text = ALIAS_JSON_RE.sub(alias_repl, text)

    if options["mask_vlan_names"]:
        def vlan_value_repl(match: re.Match[str]) -> str:
            counts["vlan_names_masked"] += 1
            return replace_value_line(match, "masked-vlan")
        text = VLAN_VALUE_LINE_RE.sub(vlan_value_repl, text)

        def vlan_token_repl(match: re.Match[str]) -> str:
            counts["vlan_names_masked"] += 1
            return f"masked-vlan-{match.group('id')}"
        text = VLAN_TOKEN_RE.sub(vlan_token_repl, text)

    return text


def residual_audit(root: Path, options: dict[str, bool]) -> dict[str, int | None]:
    findings = {
        "private_ipv4_remaining": 0,
        "unmasked_mac_remaining": 0,
        "hostname_fields_remaining": 0,
        "interface_alias_values_remaining": 0,
        "vlan_labels_remaining": 0,
    }
    for path in sorted(root.rglob("*")):
        if not path.is_file() or not looks_text(path):
            continue
        try:
            if path.stat().st_size > MAX_TEXT_BYTES:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if options["mask_management_ips"]:
            for value in IPV4_RE.findall(text):
                try:
                    address = ipaddress.ip_address(value)
                    if address.is_private and not address in ipaddress.ip_network("198.51.100.0/24"):
                        findings["private_ipv4_remaining"] += 1
                except ValueError:
                    pass
        if options["mask_mac_addresses"]:
            findings["unmasked_mac_remaining"] += sum(
                1 for value in MAC_RE.findall(text) if not value.lower().startswith("02:")
            )
        if options["mask_hostnames"]:
            for regex in (SYSNAME_WALK_RE, HOST_KEY_RE, HOST_LABEL_RE, CISCO_LOCAL_HOSTNAME_RE, CISCO_LOCAL_HOSTNAME_OID_RE, HOST_JSON_RE):
                for match in regex.finditer(text):
                    if "masked-switch" not in match.group("value"):
                        findings["hostname_fields_remaining"] += 1
        if options["mask_interface_descriptions"]:
            for regex in (ALIAS_WALK_RE, ALIAS_KEY_RE, ALIAS_JSON_RE):
                for match in regex.finditer(text):
                    value = match.group("value")
                    if value.strip() and "masked-interface-description" not in value:
                        findings["interface_alias_values_remaining"] += 1
        if options["mask_vlan_names"]:
            findings["vlan_labels_remaining"] += len(VLAN_TOKEN_RE.findall(text))
            for match in VLAN_VALUE_LINE_RE.finditer(text):
                if "masked-vlan" not in match.group("value"):
                    findings["vlan_labels_remaining"] += 1
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--mask-management-ips", default="true")
    parser.add_argument("--mask-mac-addresses", default="true")
    parser.add_argument("--mask-hostnames", default="true")
    parser.add_argument("--mask-vlan-names", default="false")
    parser.add_argument("--mask-interface-descriptions", default="false")
    args = parser.parse_args()

    options = {
        "mask_management_ips": bool_arg(args.mask_management_ips),
        "mask_mac_addresses": bool_arg(args.mask_mac_addresses),
        "mask_hostnames": bool_arg(args.mask_hostnames),
        "mask_vlan_names": bool_arg(args.mask_vlan_names),
        "mask_interface_descriptions": bool_arg(args.mask_interface_descriptions),
    }
    counts = {
        "secrets_removed": 0,
        "url_credentials_removed": 0,
        "ip_addresses_masked": 0,
        "mac_addresses_masked": 0,
        "hostnames_masked": 0,
        "vlan_names_masked": 0,
        "interface_descriptions_masked": 0,
        "files_scanned": 0,
        "files_changed": 0,
        "binary_files_skipped": 0,
        "oversized_files_skipped": 0,
        "read_errors": 0,
    }

    root = args.root.resolve()
    if not root.is_dir():
        raise SystemExit(f"Sanitization root not found: {root}")

    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        try:
            size = path.stat().st_size
        except OSError:
            counts["read_errors"] += 1
            continue
        if size > MAX_TEXT_BYTES:
            counts["oversized_files_skipped"] += 1
            continue
        if not looks_text(path):
            counts["binary_files_skipped"] += 1
            continue
        counts["files_scanned"] += 1
        try:
            original = path.read_text(encoding="utf-8", errors="surrogateescape")
            updated = sanitize_text(original, options, counts)
            if updated != original:
                path.write_text(updated, encoding="utf-8", errors="surrogateescape", newline="\n")
                counts["files_changed"] += 1
        except (OSError, UnicodeError):
            counts["read_errors"] += 1

    raw_residuals = residual_audit(root, options)
    residuals = {
        "private_ipv4_remaining": raw_residuals["private_ipv4_remaining"] if options["mask_management_ips"] else None,
        "unmasked_mac_remaining": raw_residuals["unmasked_mac_remaining"] if options["mask_mac_addresses"] else None,
        "hostname_fields_remaining": raw_residuals["hostname_fields_remaining"] if options["mask_hostnames"] else None,
        "interface_alias_values_remaining": raw_residuals["interface_alias_values_remaining"] if options["mask_interface_descriptions"] else None,
        "vlan_labels_remaining": raw_residuals["vlan_labels_remaining"] if options["mask_vlan_names"] else None,
    }
    audit_categories = {
        "private_ipv4": {"enforced": options["mask_management_ips"], "remaining": residuals["private_ipv4_remaining"]},
        "mac_addresses": {"enforced": options["mask_mac_addresses"], "remaining": residuals["unmasked_mac_remaining"]},
        "hostnames": {"enforced": options["mask_hostnames"], "remaining": residuals["hostname_fields_remaining"]},
        "interface_aliases": {"enforced": options["mask_interface_descriptions"], "remaining": residuals["interface_alias_values_remaining"]},
        "vlan_labels": {"enforced": options["mask_vlan_names"], "remaining": residuals["vlan_labels_remaining"]},
    }
    report = {
        "sanitization_version": 7,
        "secrets_always_removed": True,
        "options": options,
        "counts": counts,
        "residual_audit": residuals,
        "audit_categories": audit_categories,
        "enabled_category_leaks_found": any(
            item["enforced"] and bool(item["remaining"]) for item in audit_categories.values()
        ),
        "warning": (
            "Automated masking reduces common privacy risks but cannot guarantee that all "
            "identifying information was removed. Review the archive before sharing."
        ),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
