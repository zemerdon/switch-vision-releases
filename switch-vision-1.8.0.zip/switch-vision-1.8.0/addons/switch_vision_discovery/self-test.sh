#!/usr/bin/env sh
set -eu
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export CV_MIB_DATABASE_DIR="$BASE_DIR/mib_database"
export CV_VENDOR_DIR="$BASE_DIR/vendors"
. "$CV_VENDOR_DIR/base.sh"
. "$CV_VENDOR_DIR/generic.sh"
. "$CV_VENDOR_DIR/cisco.sh"
. "$CV_VENDOR_DIR/known_vendor.sh"
. "$CV_VENDOR_DIR/interface.sh"
. "$CV_VENDOR_DIR/loader.sh"
cv_vendor_database_self_test

tmp_dir=$(mktemp -d)
trap 'rm -rf "$tmp_dir"' EXIT
walk="$tmp_dir/test-walk.txt"
cat > "$walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Cisco IOS Software, C3650 Software"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.9.1.2066
.1.3.6.1.2.1.1.5.0 = STRING: "SW5"
.1.3.6.1.2.1.31.1.1.1.1.1 = STRING: "GigabitEthernet1/0/1"
.1.3.6.1.2.1.31.1.1.1.1.49 = STRING: "TenGigabitEthernet1/1/1"
.1.3.6.1.2.1.31.1.1.1.1.10101 = STRING: "Vlan1"
WALK
cv_detect_vendor_identity "$walk"
[ "$CV_ID_VENDOR" = "cisco" ]
[ "$CV_ID_FAMILY" = "Catalyst 3650" ]
[ "$CV_ID_PRODUCT_MATCH" = "exact" ]
cv_write_capabilities_json "$walk" "$tmp_dir/capabilities.json" "$tmp_dir/latest.json"
jq -e '(.device.vendor == "cisco") and (.summary.interface_count == 3) and (.summary.physical_count == 2) and (.summary.rj45_count == 1) and (.summary.sfp_plus_count == 1)' "$tmp_dir/capabilities.json" >/dev/null

cat >> "$walk" <<'WALK'
.1.3.6.1.2.1.47.1.1.1.1.7.1001 = STRING: "Chassis inlet temperature"
.1.3.6.1.2.1.99.1.1.1.1.1001 = INTEGER: 8
.1.3.6.1.2.1.99.1.1.1.2.1001 = INTEGER: 9
.1.3.6.1.2.1.99.1.1.1.3.1001 = INTEGER: 0
.1.3.6.1.2.1.99.1.1.1.4.1001 = INTEGER: 42
.1.3.6.1.2.1.99.1.1.1.5.1001 = INTEGER: 1
.1.3.6.1.2.1.105.1.3.1.1.2.1 = Gauge32: 740
.1.3.6.1.2.1.105.1.3.1.1.4.1 = Gauge32: 120
WALK
python3 "$BASE_DIR/standard_sensor_scan.py" --walk "$walk" --enrich "$tmp_dir/capabilities.json"
jq -e '(.standard_sensor_discovery.candidate_count == 3) and (.capabilities.environment == true) and (.capabilities.poe == true)' "$tmp_dir/capabilities.json" >/dev/null


juniper_walk="$tmp_dir/juniper-walk.txt"
cat > "$juniper_walk" <<'WALK'
.1.3.6.1.2.1.1.1.0 = STRING: "Juniper Networks, Inc. ex4300-48p"
.1.3.6.1.2.1.1.2.0 = OID: .1.3.6.1.4.1.2636.1.1.1.2.63
.1.3.6.1.2.1.1.5.0 = STRING: "edge-juniper"
JUNIPER-MIB::jnxOperatingTemp.1 = INTEGER: 42
JUNIPER-MIB::jnxOperatingCPU.1 = INTEGER: 17
WALK
cv_detect_vendor_identity "$juniper_walk"
[ "$CV_ID_VENDOR" = "juniper" ]
cv_write_capabilities_json "$juniper_walk" "$tmp_dir/juniper-capabilities.json" ""
python3 "$BASE_DIR/vendor_sensor_scan.py" --walk "$juniper_walk" --database "$BASE_DIR/mib_database" --enrich "$tmp_dir/juniper-capabilities.json"
jq -e '(.device.vendor == "juniper") and (.vendor_sensor_discovery.pack_loaded == true) and (.vendor_sensor_discovery.counts_by_category.temperature == 1) and (.vendor_sensor_discovery.counts_by_category.cpu == 1)' "$tmp_dir/juniper-capabilities.json" >/dev/null

printf '%s\n' "Switch Vision vendor/interface knowledge self-test: PASS"
