# Switch Vision Discovery v1.8.0

Switch Vision Discovery is a read-only Home Assistant add-on that walks or imports SNMP data, identifies supported switch hardware, classifies interfaces, writes capability reports, and generates review-only SNMP2MQTT and Lovelace YAML.

## Requirements

- Home Assistant OS or Supervised with `/share` access
- SNMP v2c read-only access to the target switch
- UDP/161 reachability from Home Assistant to the switch
- Switch Vision card and custom component installed separately from the same release

## Recommended operation

- Start on boot: off
- Watchdog: off
- Run manually when adding, validating, or re-walking switches
- Use targeted mode for known switches and full mode for new hardware investigation

## Main outputs

```text
/share/switch_vision/snmpwalk.log
/share/switch_vision/discovery-report.txt
/share/switch_vision/last-discovery-run.txt
/share/switch_vision/generated-snmp2mqtt.yaml
/share/switch_vision/generated-dashboard-card.yaml
```

## Hardware status

- Cisco Catalyst 3650: supported reference platform
- Selected Catalyst 2960X/2960S models: experimental
- Other models/vendors: untested until validated with walks and a visual profile

For complete setup, examples, and field descriptions, see the release `docs/` folder.

- Discovery switch rows include an optional **display name** for generated card titles.
- Status Box 2 is an independent secondary switch-summary container that defaults to VENDOR and UPTIME.

> **Switch Name (Used internally only) vs display name:** `switch_name` is the unique internal target ID used for mappings and generated profiles. `display_name` is optional friendly text used only for generated card titles.


### Stack-member display names

A stack member `display_name` is used as the generated card title. Stable member/profile IDs continue to come from the sensor prefix, such as `sw5` → `SW5`.


## Port activity

Dashboard activity LEDs are derived from RX/TX byte-counter changes. Switch Vision does not require separate `_last_change` MQTT entities.
## Support My Switch contribution receipt

Support My Switch can record an optional recognition preference, generate a bundle quality result, and include a prepared email template addressed to `switch-vision@zemerdon.com`. Nothing is sent automatically; users review and attach the generated ZIP themselves.
### Prepared email

After a contribution is created, Switch Vision now writes three files to `/share/switch_vision/contributions/`:

- the contribution ZIP;
- a `.eml` email addressed to `switch-vision@zemerdon.com` with the ZIP attached;
- an `_Actions.html` page containing **Prepare Email**, **Download Archive**, and **Open Email Without Attachment** actions.

Open the `.eml` file in your normal email client, review it, and press Send. Nothing is transmitted automatically and Switch Vision stores no email credentials. The HTML action page is a local convenience file and can be opened through a file share or file manager.


## Support My Switch Web UI

Start the add-on and select **Open Web UI** to use the guided Support My Switch workflow. The page provides privacy and recognition options, live creation progress, bundle-quality results, detected-device details, and buttons to prepare an email or download the contribution archive.

The prepared `.eml` file is addressed to `switch-vision@zemerdon.com` and includes the ZIP as an attachment. Nothing is sent automatically and no email credentials are stored.

## Discovery diagnostics

The persistent Discovery Web UI includes a read-only **Diagnostics** page with
service, registry, generated-file and per-device capability checks. Diagnostics
can be refreshed, copied or downloaded without changing the working installation.


## Switch model compatibility override

Discovery switch rows can use **Auto-detect** or select an exact registered model as an experimental compatibility override. The detected model is always retained and shown separately.

## Using generated SNMP2MQTT YAML

Discovery writes `/share/switch_vision/generated-snmp2mqtt.yaml`. The Web UI validates, previews, and downloads this file. Enable generated-YAML import in the separate Switch Vision SNMP2MQTT add-on and restart that add-on after Discovery generates a new file. Discovery does not create a second active copy.
