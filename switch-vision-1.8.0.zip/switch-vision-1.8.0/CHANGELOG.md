# Switch Vision Changelog

## v1.8.0 Gold

- Promoted the fully validated v1.7.53 codebase to the new **Gold / Stable** baseline as v1.8.0.
- Updated all runtime versions, manifests, examples, installation paths, supported-device outputs, Gold documents, and current-release documentation.
- Locked in the final status-box layout: independent Status Box 1, Status Box 2, and Port Status Box controls; title-free rows; IntelOne 16 px bold defaults; and VENDOR/UPTIME defaults for Status Box 2.
- Locked in Juniper EX3300-48P exact-model registry matching, copper-port mapping, PoE/system telemetry, and per-port static Q-BRIDGE VLAN membership display.
- Locked in Support My Switch registry enrichment and explicit privacy-audit enforcement metadata.
- Retained Cisco Catalyst 3650 exact models as Confirmed; Cisco 2960S/2960X and Juniper EX3300-48P remain Experimental pending outstanding uplink or Virtual Chassis validation.
- Confirmed `CHANGELOG.md` as the sole version-history document; historical `RELEASE_NOTES*` files remain excluded.
- Gold update scope: perform a clean complete replacement of the release components, rebuild/reinstall Discovery, restart Home Assistant Core, run Discovery, and refresh the browser.

## 1.7.53

- Cleaned up Support My Switch privacy metadata so disabled legacy residual-audit fields are emitted as `null` rather than misleading zero values.
- Updated the contribution report generator to read authoritative `audit_categories` metadata.
- Increased the sanitization report schema to version 7 and added regression coverage.

## v1.7.52

- Fixed Support My Switch registry enrichment by synchronising the authoritative supported-device registry into the Discovery add-on at build time.
- Juniper `Juniper EX3300-48P` contribution records now resolve to `EX3300-48P` with `registry_match: true` and Experimental metadata.
- Added explicit JSON audit metadata for disabled privacy categories using `enforced: false` and `remaining: null`.
- Bumped the sanitization report schema to version 6.

## v1.7.51

- Unified Juniper model normalisation across Discovery, diagnostics and Support My Switch contribution summaries, so `Juniper EX3300-48P` matches the exact `EX3300-48P` experimental registry entry.
- Contribution bundles now re-enrich privacy-processed capability files with the shared supported-device registry lookup before generating device summaries.
- Privacy reports now state `not enforced - masking disabled` for categories whose masking option was disabled instead of incorrectly reporting zero remaining values.
- Added `build.py --bump patch|minor|major` while retaining explicit `-v/--version` builds.
- Removed accumulated historical `RELEASE_NOTES*` files; version history is maintained in `CHANGELOG.md`.
- Update scope: replace `/addons/switch_vision_discovery/`, rebuild/reinstall the local add-on, and restart Discovery. Home Assistant Core and SNMP2MQTT do not need restarting.

## v1.7.49

- Moved the shared status value column 10 px further left in Status Box 1, Status Box 2, and the Port Status Box.
- Preserved box geometry, label positions, row spacing, and individual field calibration offsets.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

## v1.7.48

- Moved the shared status value column another 5 px left for Status Box 1, Status Box 2 and the Port Status Box.
- Fixed fresh/default profiles so Status Box 2 visibly defaults to VENDOR and UPTIME.
- Fixed Reset All so Status Box 2 restores VENDOR and UPTIME in that order.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

## v1.7.47

- Added a dedicated **Port Status Box** field-control row beneath Status Box 2, so selecting a port no longer replaces the Status Box 1 field controls.
- Removed the obsolete MODE item from port status fields and legacy MODE entries are ignored.
- Status Box 2 now defaults to VENDOR and UPTIME, in that order.
- Moved the shared status-field value column 40 px further left for Status Box 1, Status Box 2 and selected-port details.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

## 1.7.46

- Fixed Reset All so both status boxes explicitly clear legacy row offsets.
- Restored the canonical 88 px label-to-value column spacing.
- Reset defaults are Custom / IntelOne, 16 px and bold.

## v1.7.45

- Set the default font for both status boxes to Custom / IntelOne, 16 px, bold.
- Standardised the default label-to-value column spacing at 88 px from label start to value start.
- Existing saved profiles retain their font settings and individual field offsets.
- Reset All now restores the new shared status-box defaults.

## 1.7.44

- Moved the shared status-box value column further left to reduce the label-to-value gap in both Status Box 1 and Status Box 2.
- Preserved box geometry, outer padding, row spacing, truncation behaviour and independent field calibration offsets.

### Update Scope

Replace:

- `/config/custom_components/switch_vision/`

Then restart Home Assistant Core and refresh the browser. Discovery and SNMP2MQTT do not need restarting.

## 1.7.43

- Removed the confirmation prompt from Reset all; the visual reset now runs immediately.
- Reduced the horizontal gap between status-field labels and values in both Status Box 1 and Status Box 2.
- Preserved box geometry, outer padding, vertical layout, field ordering and independent field calibration offsets.

### Update Scope

Replace:

- `/config/custom_components/switch_vision/`

Then restart Home Assistant Core and refresh the browser. Discovery and SNMP2MQTT do not need restarting.

## 1.7.42

- Fixed Status Box 1 row rendering and field-target alignment.
- Added sixth-row status-field targets.
- Restored Reset all with confirmation and visual-only scope.

## v1.7.41

- Fixed Status Box 2 field calibration targets so label/value markers align with the rendered text.
- Status Box 2 field X/Y nudges now move the live text, not only the calibration overlay.
- Status Box 1 and Status Box 2 field targets now use the same coordinate transform as the renderer.
- Removed the irrelevant `LED centre` part option from status-field targets; they now show `Field position`.
- Removed the deferred `Reset all` control and action.
- Added Reset target support for Status Box 2 field groups and individual fields.
- Removed legacy title points from both status-box field maps while preserving compatibility with older profiles.
- MODE remains excluded from calibration targets and exports.

### Update Scope

Replace:

- `/config/custom_components/switch_vision/`

Then restart Home Assistant Core and refresh the browser. Discovery and SNMP2MQTT do not need restarting.

## v1.7.40

- Added the 1984, 1996, and 2016 Cisco SVG logo variants to the bundled logo library.
- Confirmed obsolete Status Box 1/2 title targets and the MODE calibration target remain excluded.
- Existing saved legacy title or MODE offsets remain harmlessly ignored.

### Update Scope

Replace the logo folder only:

- `/config/www/switch-vision/logos/`

Then refresh the browser. No Home Assistant Core, Discovery, or SNMP2MQTT restart is required.

## v1.7.39

- Added the Q-BRIDGE static VLAN table (`1.3.6.1.2.1.17.7.1.4.3`) to targeted SNMP walks.
- Juniper VLAN membership is now decoded for every mapped port using bridge-port → ifIndex → physical-interface correlation.
- Juniper ports render one VLAN as `VLAN n`, multiple memberships as `VLANS n, n, ...`, and fall back to `VLAN TRUNK` when trunking is known but membership is unavailable.
- Removed obsolete Status Box 1 and Status Box 2 title calibration targets. Legacy saved title offsets remain harmlessly ignored.
- MODE remains excluded from status LED calibration targets and export data.

### Update Scope

Replace both:

- `/addons/switch_vision_discovery/`
- `/config/custom_components/switch_vision/`

Then rebuild/reinstall and restart Discovery, restart Home Assistant Core, run Discovery again, and refresh the browser. SNMP2MQTT does not need restarting unless regenerated configuration changes are applied.

## 1.7.38

- Fixed Juniper EX3300-48P supported-device registry matching when Discovery reports the vendor-prefixed model name `Juniper EX3300-48P`.
- Kept the authoritative exact model entry as `EX3300-48P` while normalising the vendor prefix during registry lookup.
- The Juniper contribution now reports `registry_match: true`, the `juniper-ex3300-48p` mapping profile, and Experimental validation metadata.
- Update scope: replace `/addons/switch_vision_discovery/`, rebuild or reinstall the local add-on, and restart Discovery. Home Assistant Core and SNMP2MQTT do not need restarting.

## 1.7.37

- Added individual calibration targets for every Status Box 2 field, matching Status Box 1 target support.
- Added a separate Status Box 2 field target group and an All Status Box 2 fields quick-selection button.
- Status Box 2 field targets now show calibration rings and labels and can be nudged independently without moving or resizing the box.
- Preserved Status Box 1 behaviour, status-box dimensions, field visibility, ordering, and styling.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

## 1.7.36

- Moved Status Box 2 label and value content 10 px further left.
- Preserved Status Box 1 padding, calibrated box dimensions, vertical layout, and right edge.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

# Switch Vision Changelog

## v1.7.35

- Reduced the left content buffer in Status Box 1 by 5px.
- Applied the same horizontal inset to Status Box 2 so both boxes share matching label and value column margins.
- Preserved calibrated box position, width, height, vertical layout, and right edge.
- Update scope: replace `/config/custom_components/switch_vision/`, restart Home Assistant Core, then refresh the browser.

## v1.7.34

- Removed automatic Status Box 2 height changes introduced in v1.7.33.
- Status Box 2 now always keeps its calibrated width and height.
- Showing, hiding, or reordering fields changes only the content inside the box.
- Rows that do not fit remain clipped by the existing in-box safety rules rather than resizing the panel.

## v1.7.33

- Tightened live Status Box 2 height so its padding and buffer better match Status Box 1.
- Old title-era box heights no longer leave oversized empty space around compact Status Box 2 content.
- Preserved saved calibration profiles while applying the compact height only at render time.

## v1.7.32

- Standardised the horizontal two-column layout for every field in Status Box 1 and Status Box 2.
- All field labels now share one fixed label column.
- All field values now share one fixed, left-aligned value column.
- Short values such as UPTIME no longer appear indented because of right-aligned text width.
- Hidden, reordered, switch, port, and SFP fields all use the same alignment rules.
- Preserved compatibility with existing saved calibration profiles.

## v1.7.31 Gold

- Standardised the vertical layout of every visible field in Status Box 1 and Status Box 2.
- Visible rows now use one compact, evenly spaced grid based on their displayed order.
- Hidden and reordered fields no longer leave uneven gaps.
- Preserved calibrated horizontal label/value positions and existing saved-profile compatibility.

## v1.7.30 Gold

- Designated v1.7.30 as the new **Gold / Stable** baseline.
- Added **Smoke** as a separate status-box background selection for Status Box 1 and Status Box 2.
- **Clear** remains fully transparent.
- **Smoke** restores the previous subtle dim using `rgba(0,0,0,.06)`.
- Existing saved profiles using the old subtle-dim value now appear as **Smoke** in calibration.
- Finalised title-free Status Box 1 and Status Box 2 rendering and calibration controls.
- Finalised blue STACK LED behaviour for every confirmed stack member, with no LED for standalone or unconfirmed stack state.
- Finalised dynamic Juniper EX3300-48P zero-based port mapping and VLAN membership display.
- Kept Cisco trunk presentation unchanged.
- Marked all non-Catalyst-3650 models **Experimental** pending SFP/uplink testing.
- Added Gold packaging validation that excludes `__pycache__/`, `*.pyc`, and `*.pyo`.

## v1.7.29

- Changed the **Clear** status-box colour to true transparency for Status Box 1 and Status Box 2.
- Existing profiles that used the previous `rgba(0,0,0,.06)` Clear value are rendered as fully transparent automatically.
- Border, text, and non-clear colour choices are unchanged.

## v1.7.28

- Removed the rendered title and divider from both Status Box 1 and Status Box 2.
- Shifted enabled rows upward in both boxes without rewriting saved calibration coordinates.
- Removed all title-specific calibration controls for both boxes: title source, title field, custom title, and title size.
- Preserved legacy title keys in saved profiles for backward compatibility; they are now ignored at runtime.

## v1.7.27

- Fixed the blue STACK LED so every confirmed stack member, including member 1, illuminates consistently.
- Discovery now emits `stack_enabled: true` for all cards in a confirmed multi-member stack.

## v1.7.26

- Moved the default Status Box 2 position 5 pixels to the right.
- Added a blue STACK LED for switches explicitly configured as stack members.
- Keeps the STACK LED off for standalone switches, unknown stack state, and unconfirmed membership.
- Preserved saved calibration-profile coordinates; the position change applies only to defaults and new profiles.

## v1.7.25

- Removed the rendered title and divider from Status Box 2.
- Shifted Status Box 2 values upward while preserving existing calibration profiles.
- Restored the Status Box 2 labels in the calibration tool.
- Left Status Box 1 and vendor-specific VLAN display unchanged.

## v1.7.24

- Juniper access ports display a single VLAN value.
- Juniper trunk ports display the complete discovered VLAN membership list under `VLANS`.
- Removed the separate Juniper port-mode and native-VLAN rows from selected-port presentation.
- Cisco `TRUNK` display remains unchanged.

## v1.7.23

Maintenance cleanup release.

- Made `src/js/switch-vision.js` the single authoritative card source and added byte-for-byte build validation for the custom-component copy.
- Synchronised source manifest version, release name, and cache-busting resource metadata.
- Replaced stale embedded calibration generator metadata with the live `SV_VERSION`.
- Added automated Juniper VLAN mode and release-integrity regression tests.
- Normalised changelog headings and release order.
- Preserved existing plural asset paths for backwards compatibility; no calibration-profile migration is required.

## v1.7.22

- Added dynamic Juniper trunk/access classification from Q-BRIDGE VLAN membership bitmaps.
- Port details now show MODE plus the accurate native VLAN.
- Removed redundant Status Box 2 calibration headings.
- Native panel card JavaScript is now served by the custom component to prevent stale frontend versions.

## v1.7.21

- Fixed Juniper logical-interface index parsing when `ifName` values contain a dot, such as `ge-0/0/42.0`.
- Dynamic BRIDGE-MIB/Q-BRIDGE-MIB joins now emit per-port VLAN/PVID sensors instead of resolving logical indexes as zero.
- Added generated-YAML diagnostics for logical interfaces, bridge mappings, PVID rows, and successful joins.

## v1.7.20

- Added `dot1dBasePortIfIndex` and `dot1qPvid` to targeted live SNMP walks so dynamic Juniper per-port VLAN sensors have the source tables required during generation.
- Replaced the hard-coded targeted-walk progress total with a count derived from the configured OID list.
- Keeps VLAN discovery dynamic; no interface-range names, port numbers, bridge indexes, or VLAN IDs are hard-coded.

## v1.7.19

- Added dynamic Juniper per-port VLAN/PVID generation through BRIDGE-MIB and Q-BRIDGE-MIB table correlation.
- VLAN discovery is independent of interface-range names and contains no fixed port, bridge-index, or VLAN mappings.

## v1.7.18

- Fixed Juniper zero-based port mapping in selected-port details so the entity offset is applied exactly once.
- Visual label 42 now resolves to `sensor.sw10_port_42_*` instead of the previous port 41/43 mismatch.
- Link, speed, VLAN, alias and selected-port summary now use the same resolved Juniper entity number as the LEDs and traffic counters.

## v1.7.17

- Fixed the frontend port-number overlay so `port_label_offset` is applied when labels are drawn.
- Juniper EX3300-48P now displays labels 0-47 while retaining zero-based entity mapping.

## v1.7.16

- Added Juniper EX3300-48P zero-based port-number overlays: calibrated slots 1–48 now display labels 0–47.
- Kept Juniper entity lookup aligned with the same zero-based numbering, so label, click target, status, activity, RX/TX and details all use the matching port.
- Cisco and other one-based models remain unchanged.

## v1.7.15

- Fixed Calibration failing to open after the v1.7.14 status-panel change.
- Status Box 2 is now strictly switch-summary only and no longer renders selected-port or selected-SFP details.
- Calibration sections start collapsed for each new Calibration session.
- Preserved Juniper visual ports 1–48 with zero-based entity lookup.

## v1.7.14

- Status Box 2 now remains a switch-summary box and no longer switches to port or SFP details when a front-panel interface is selected.
- Port and SFP selection details are displayed only in Status Box 1.
- Restored visible copper-port numbering to 1-48 for all 48-port faceplates.
- Juniper EX3300 cards retain `port_entity_offset: -1` for correct SNMP entity mapping without changing the displayed port labels.

## v1.7.13

- Fixed Status Box 2 rows being discarded when legacy value anchors sat a few pixels outside the compact box width.
- All Calibration tool sections now open collapsed at the start of every calibration session.
- Added a label mask for remapped port numbering so zero-based Juniper labels 0-47 replace the baked 1-48 faceplate numbers cleanly.
- Clarified Juniper link/activity placement by keeping entity, displayed label, selection and details mapping aligned.

## v1.7.9

- Fixed authoritative version propagation across all packaged runtime components and added strict mixed-version build validation.
- Added walk-aware Juniper EX3300-48P CPU, temperature, memory, fan and power-supply health discovery using `jnxOperatingTable`.
- Kept unsupported Juniper health values absent rather than generating invalid OIDs.

## v1.7.8

- Fixed zero-based Juniper port detail, traffic and activity lookups.
- Selected Juniper ports now show the correct faceplate number in the status panel.
- Added the optional bundled Juniper logo at `logos/juniper.svg`.


- Fixed Juniper EX3300-48P SNMP2MQTT generation so the 48 base `ge-0/0/N` interfaces create live port entities.
- Preserved zero-based labels 0 through 47 and excluded `.0` logical interfaces.
- Corrected generated device metadata from Cisco / unknown to Juniper / EX3300-48P.

## v1.7.7



## v1.7.6

- Corrected Juniper EX3300-48P copper-port numbering to match the physical zero-based labels 0 through 47.
- Added per-card port label and entity offsets so calibrated positions 1 through 48 map to Juniper interfaces ge-0/0/0 through ge-0/0/47.
- Port ge-0/0/42 now drives the faceplate position labelled 42.

# Changelog

## v1.7.5

### Added

- Added experimental Juniper EX3300-48P exact-model detection and front-panel mapping.
- Mapped ge-0/0/0 through ge-0/0/47 as 48 physical RJ45 ports.
- Deduplicated the four shared ge-0/1/N and xe-0/1/N uplink cages.
- Excluded logical unit, management, and VLAN interfaces from front-panel totals.

## v1.7.4

### Fixed

- Create the Discovery Web log directory and file before use.
- Prevent clean-install Discovery failures when `/share/switch_vision/discovery-web.log` does not yet exist.

# Switch Vision changelog

## v1.7.3

- Added local Home Assistant brand images using the bundled Switch Vision logo, removing the missing integration icon on Home Assistant 2026.3 and later.
- Added the supplied Switch Vision SVG as a dedicated custom sidebar icon.
- Unified native panel version reporting so the top-right badge reads the backend runtime version instead of stale v1.6.0 text.
- Added runtime and asset revision metadata to the native sidebar panel and its Advanced diagnostics.
- Updated the build process to patch frontend and backend panel version constants automatically in future releases.

## v1.7.1

- Made the Switch Vision logo the vendor-neutral default for new profiles.
- Moved bundled logos into `logos/` and retained Cisco as optional `logos/cisco.svg`.
- Removed the obsolete `images/` directory.
- Renamed bundled faceplates to `faceplates/sv-dark.png` and `faceplates/sv-light.png`.
- Updated calibration, layout, discovery registry, and runtime asset fallbacks to the new paths.
- Added standard-MIB sensor discovery for unfamiliar and non-Cisco switches.
- Added major-vendor discovery packs for Juniper, HPE/Aruba, Dell, Extreme Networks, Ruckus/Brocade, MikroTik, Ubiquiti, NETGEAR, and Huawei.
- Added vendor-specific symbolic sensor matching and enterprise-OID review candidates alongside the standard-MIB scanner.

## v1.6.0

- Added a Switch Vision integration option to show or hide Calibration buttons on all cards in the automatic generated dashboard.
- The option defaults to enabled and applies without rewriting generated YAML.
- Manual YAML cards continue to use their own `calibration_button` value.
- The native dashboard detects the option change and rebuilds its cards automatically.

## v1.5.5

- Compact one-line native dashboard header.
- Automatic generated-dashboard refresh when Discovery updates the YAML.
- Versioned frontend module URLs for reliable cache invalidation.
- Rewritten current documentation for the zero-copy native dashboard workflow.
- Documented automatic SNMP2MQTT handoff, sidebar visibility, live polling, dark faceplate defaults, cache recovery, and the manual YAML fallback.
- Removed obsolete active-file installation and normal-workflow copy/paste instructions from current documentation.

## v1.5.4

- Fixed Supervisor authorization for automatic SNMP2MQTT start/restart after Discovery.
- Added robust Supervisor token detection.
- Added a continuously ticking elapsed timer while Discovery is running.
- Preserved v1.5.3 live polling behaviour.

## v1.5.3

- Added automatic Discovery Web UI polling.
- Refreshes every second while Discovery or Support My Switch work is running.
- Refreshes every five seconds while idle.
- Pauses polling while the browser tab is hidden.
- Refreshes immediately when the tab becomes visible or receives focus.
- Keeps Discovery status, Debug output, Devices, Diagnostics, generated YAML status, and SNMP2MQTT results current without manual page refreshes.
- No parser, generator, native dashboard, calibration, custom-component, or SNMP2MQTT restart behaviour changes.

## v1.5.2 — Optional native sidebar dashboard

- Added a Switch Vision integration options screen under **Settings → Devices & services → Switch Vision → Configure**.
- Added **Show Switch Vision dashboard in sidebar**, enabled by default.
- Turning the option off hides only the dedicated native dashboard sidebar entry.
- Manual Lovelace cards, generated dashboard YAML, Calibration, Discovery, Diagnostics, Support My Switch and SNMP2MQTT remain available when the sidebar panel is hidden.
- Existing YAML-based installations automatically gain a Switch Vision config entry and retain their current calibration and generated-dashboard paths.
- Option changes reload the panel immediately without requiring another Home Assistant restart.

## v1.5.1 — Seamless SNMP2MQTT activation

- Added automatic start/restart of the Switch Vision SNMP2MQTT add-on after successful Discovery.
- Validate that the current Discovery run updated `generated-snmp2mqtt.yaml` before taking action.
- Discover the installed SNMP2MQTT add-on slug through the Supervisor API.
- Restart the add-on when already running, or start it when stopped.
- Report missing add-ons and Supervisor failures as warnings without failing Discovery.
- Added SNMP2MQTT action status to the minimal Discovery status window and Debug output.
- Kept the existing generated-YAML import option as the authoritative SNMP2MQTT configuration path.

## v1.5.0 — Automatic native dashboard

- Promoted the successful native Home Assistant sidebar dashboard to a major supported feature.
- Added zero-copy dashboard loading from Discovery's generated card configuration.
- Removed prototype/test wording and polished the panel for everyday use.
- Added a compact card count and last-generated timestamp.
- Moved technical source details and module reload controls under Advanced.
- Preserved generated dashboard YAML as the permanent manual fallback.
- Kept existing Lovelace cards, Discovery parsing and SNMP2MQTT behaviour unchanged.

## v1.4.17 — Experimental native dashboard prototype

- Added an experimental native Switch Vision sidebar panel registered by the custom component.
- The panel reads Discovery's generated dashboard-card YAML and renders live Switch Vision cards automatically.
- Preserved the manual generated-YAML workflow as an unchanged fallback.
- Added clear prototype/error states so a panel failure does not affect Discovery or manual cards.
- Simplified SNMP2MQTT generated-YAML controls to validation, preview and download only.
- Removed the duplicate active-file install/backup workflow introduced in v1.4.16.
- Home Assistant Core restart is required because `custom_components/switch_vision` changed.

## v1.4.16

- Added a safe **Use generated SNMP2MQTT YAML** workflow to the persistent Discovery Web UI.
- Added YAML preview, validation, download, manual install and restore actions.
- Added an optional setting to install valid generated YAML automatically after a successful Discovery run.
- Active YAML is installed to `/share/switch_vision/snmp2mqtt.yaml`.
- Existing active YAML is backed up before every replacement under `/share/switch_vision/backups/snmp2mqtt/`.
- Invalid, empty or hostless generated YAML is rejected before installation.
- Switch Vision does not automatically restart the SNMP2MQTT add-on.
- Discovery parsing, dashboard generation and supported-device behaviour are unchanged.

## v1.4.15

- Made Auto-detect the migration-safe default for existing and new switch rows.
- Added distinct Idle, Preparing, Running, Complete and Failed Discovery states.
- Prevented the guided workflow from looking active before real Discovery work starts.
- Renamed the first step to `Validating configured switches`.
- Kept parser, generator and compatibility-override behaviour unchanged.

## v1.4.14

- Added a per-switch **Switch Model** dropdown to Discovery configuration.
- Added Auto-detect plus exact registered model choices.
- Preserved detected, selected override, and effective model values separately.
- Added experimental compatibility warnings to reports and generated cards.
- Included override metadata in capability JSON, diagnostics, and Support My Switch summaries.
- Kept the real detected model authoritative for support status.

## v1.4.13

- Added default minimal and optional debug output modes to Discovery.
- Retained the requested technical stage names for SNMP walks and generated YAML.
- Made the graphite 48-port faceplate the default/recommended 3650 faceplate.
- Made Calibration **Done** validate and save the active profile automatically.

## v1.4.12

- Simplified the persistent Discovery Web UI around four clear destinations: Discovery, Devices, Support My Switch and Diagnostics.
- Added a clean landing page that shows only the current high-level status and primary actions.
- Added a guided six-step Discovery progress view while keeping raw log output inside an Advanced details section.
- Added a Devices results page with compact per-switch discovery, support, port and generated-configuration summaries.
- Moved detailed registry, validation, path and generated-file information behind Diagnostics or View Details.
- Kept the persistent idle/ready lifecycle, duplicate-run protection, parser behaviour and SNMP2MQTT/dashboard generation unchanged.

## v1.4.11

- Updated the generated dashboard-card YAML to include `switch_model` automatically.
- The exact SKU is read from each switch's generated capability JSON.
- Every generated member card in a stack receives the verified exact model.
- Recommended Setup now appears without manually editing generated card YAML.
- Left dashboard rendering, calibration behaviour, parsing, registry matching and SNMP2MQTT generation unchanged.

## v1.4.10

- Added exact-model faceplate and calibration recommendations.
- Added read-only compatibility checks in Interactive Calibration.
- Added a user-triggered Apply Recommended Setup action with no automatic overwrite.
- Marked 2960 visual assets as pending until model-specific faceplates/profiles are supplied.

## v1.4.9

- Fixed **Copy Diagnostics** in Home Assistant Ingress and HTTP browser contexts.
- Added a legacy clipboard fallback when `navigator.clipboard.writeText()` is unavailable or denied.
- Added clearer clipboard and diagnostics-download error reporting.
- Left Discovery, registry, dashboard and SNMP2MQTT behaviour unchanged.

## v1.4.8

- Added a read-only Diagnostics page to the persistent Discovery Web UI.
- Added installation and service checks for the Discovery add-on, exact-model registry, generated SNMP2MQTT YAML, generated dashboard YAML and contribution workflow.
- Added per-device diagnostics from capability JSON, including exact model, registry state, interface counts, mapping/calibration profiles and component-level validation.
- Added clear warning/error messages for missing registry data, missing or stale generated files and unavailable capability data.
- Added **Refresh Diagnostics**, **Copy Diagnostics**, **Download Diagnostics Report** and **Run Discovery** actions.
- Kept parser, registry matching and SNMP2MQTT generation behaviour unchanged.

## v1.4.7

- Changed the Discovery add-on into a persistent idle/ready service.
- The Home Assistant Ingress Web UI now starts immediately with the add-on and remains available between Discovery runs.
- Added a **Run Discovery** control and live Discovery status/log output to the Support My Switch Web UI.
- Discovery now runs as a child job without stopping or replacing the Web UI service.
- Changed the add-on boot setting to `auto` so **Open Web UI** remains available after Home Assistant starts.
- Kept the existing parser, registry lookup, contribution and SNMP2MQTT generation behaviour unchanged inside each Discovery run.

## v1.4.6

- Added downloadable calibration profile JSON files.
- Added profile JSON import with validation and preview.
- Added schema version 1 to exported and factory profiles.
- Added canvas, coordinate and component-count compatibility checks.
- Added safe save-as and overwrite confirmation for imported profiles.
- Kept Discovery, parser and SNMP2MQTT behaviour unchanged.

## v1.4.5

- Added a persistent **Back to Home Assistant** button to the main Support My Switch landing page.
- Kept the shorter **Back** behaviour on contribution progress and result views.
- Added safe browser-history and Home Assistant root fallbacks for Ingress navigation.
- No parser, SNMP2MQTT, dashboard JavaScript, or custom component behaviour changed.

## v1.4.3

- Connected the exact-model supported-device registry to Discovery as informational metadata.
- Added component-level validation fields for model detection, RJ45, PoE, system sensors, uplinks, and stack support.
- Added registry results to discovery reports, capability JSON, and Support My Switch summaries.
- Kept all 2960 variants experimental with uplink validation pending.
- Parser and SNMP2MQTT generator behaviour remain unchanged.

## v1.4.2

- Added exact experimental registry entries for `WS-C2960X-48FPD-L`, `WS-C2960X-24PS-L` and `WS-C2960S-48FPD-L` from real test-rack contributions.
- Revalidated exact confirmed entries for `WS-C3650-48PD-E` and `WS-C3650-48PD-L` using production and test-rack contributions.
- Fixed Discovery model selection so a complete `-E` or `-L` SKU is not overwritten by a shorter chassis model string.
- Updated Cisco vendor knowledge and regenerated supported-device documentation.

## v1.4.1

- Removed the generic `WS-C3650-48PD` supported-device entry.
- Added exact confirmed entries for `WS-C3650-48PD-L` and `WS-C3650-48PD-E`.
- Recorded the exact 48 RJ45 + 2 Gigabit SFP + 2 10G SFP+ front-panel layout.
- Recorded tested IOS version 16.12.14 for both exact models.
- Regenerated Markdown and phpBB supported-device documentation.

## v1.4.0

- Started the exact-model supported-device registry.
- Added confirmed support entry for `WS-C3650-48PD` only.
- Added four controlled support statuses: detected, experimental, community validated and confirmed.
- Added build-time registry validation that rejects aliases and duplicate exact models.
- Added generated Markdown and phpBB supported-device documents.
- Preserved v1.3.15 as the protected Gold baseline.

## v1.3.15

- Replaced the shipped optional dark faceplate with the cooler graphite version.
- Removed the bronze-tinted optional dark plate from the package.
- Kept the same optional faceplate filename, dropdown label and shared calibration profile.
- No calibration or custom component changes were required.

## v1.3.14

- Added `switch-master-dark.png` as the first shipped optional faceplate.
- Added the dropdown label `Switch Vision Cisco 48 Port — Dark`.
- Reused `default_cisco_48_port` because the optional faceplate geometry is unchanged.
- Kept the current default faceplate unchanged.
- Added friendly dropdown labels for known shipped faceplates.
- Added automatic readable labels for user-supplied faceplate and logo filenames.

## v1.3.13

- Updated `default_cisco_48_port` with the latest Status Box 1 and Status Box 2 positions.
- Moved Status Box 1 from Y 37 to Y 30.
- Moved Status Box 2 from Y 20 to Y 25.
- Updated embedded factory calibration metadata for the four-uplink layout.

## v1.3.12

- Added the new `default_cisco_48_port` factory calibration profile.
- Replaced the default faceplate with the new 2048 × 448 modular 48-port design.
- Updated all 48 RJ45 port, LED, number and hitbox coordinates.
- Updated four uplink hitboxes and seven status LED positions.
- Updated default logo, Status Box 1, Status Box 2 and calibration-button placement.
- Preserved the previous faceplate and calibration as legacy assets.
- Made Copy JSON copy directly to the clipboard.
- Added a legacy browser copy fallback for insecure or restricted clipboard contexts.
- Added clear clipboard success and failure messages.

## v1.3.11

- Added editable custom port selection with comma-separated ports and ranges.
- Added custom targets for ports, link LEDs, activity LEDs and port numbers.
- Added sorting, duplicate removal, validation and missing-port reporting.
- Unified calibration blinking for single, grouped, odd/even and custom selections.
- Added a calibration-button selection overlay.
- Fixed Status Box 1 and calibration-button target editability.

## v1.3.9

- Made Profile Controls permanently visible without a collapsible header.
- Merged Port Manager into Calibration Target below the target controls.
- Placed Odd and Even Quick Selection controls on one horizontal row.
- Added horizontal overflow handling for the parity row on narrow panels.
- Normalised the remaining Port Manager field and action names.

## v1.3.8

- Merged Port Manager into Calibration Target and placed its controls directly below the target controls.
- Placed odd and even Quick Selection controls on the same row.
- Made Profile Controls permanently visible and removed its collapsible section header.

## v1.3.7

- Reordered calibration sections to: Appearance, Calibration Target, Port Manager, Quick Selection, Position and Size, Profile Controls.
- Promoted the remaining Port Manager to the single primary Port Manager section.
- Reduced calibration-tool interface text by 2 px for a more compact layout.

## v1.3.6

- Reduced all calibration-tool text by 2 px for a more compact workspace.
- Reduced calibration section text, buttons, dropdowns, badges, profile-path text, JSON export text, the on-card Calibrate toggle, overlay title, and overlay labels.
- Preserved all control sizes, spacing, functionality, and saved calibration data.

## v1.3.5

- Removed the duplicate Port Manager from the top of the calibration panel.
- Kept the single Port Manager near the bottom of the panel.
- Preserved all Add Port, Duplicate Port, Rename Port, Remove Port, and live port-count functionality.
- Simplified the calibration workflow before creating the new default faceplate profile.

## v1.3.1

- Fixed the calibration editor repeatedly alternating between a saved profile and “No saved profile found” on new installations.
- When calibration is opened for a switch with no stored profile, Switch Vision now creates a starter profile from the current generated/default layout.
- Added `calibration_profile_auto_create` (default: `true`) so automatic starter-profile creation can be disabled when required.
- Added an in-flight creation guard to prevent duplicate profile saves while Home Assistant re-renders the card.

## v1.3.0

- Added the first dynamic Port Manager to interactive calibration.
- Port target selectors now follow the ports present in the active calibration profile rather than assuming 48 ports.
- Added Add Port, Duplicate Port, Rename Port, and Remove Port controls.
- Removing a port affects only the visual calibration profile and does not delete Home Assistant or SNMP2MQTT entities.
- Preserved the v1.2.26 Gold release folder unchanged.

# Changelog

## v1.2.25 — Support My Switch prepared email

- Generates a standard `.eml` message addressed to `switch-vision@zemerdon.com` with the contribution ZIP already attached.
- Generates a local action page with **Prepare Email**, **Download Archive**, and **Open Email Without Attachment** actions.
- Nothing is sent automatically and no mail credentials are stored.


## v1.2.24 — Launch documentation refresh

- Rewrote the main README and clean-install guide for the current Switch Vision workflow.
- Documented the required Layout Card resource and the mobile Configuration error recovery procedure.
- Added dedicated troubleshooting and Support My Switch guides.
- Updated support levels, forum and support-email references, status-box guidance, and clean-update instructions.
- Removed stale pre-1.0 version examples and obsolete faceplate-label wording from primary documentation.

## v1.2.26

- Added a Home Assistant Ingress web interface for Support My Switch.
- Added guided privacy and contributor-recognition controls.
- Added live contribution progress, bundle-quality results, and detected-hardware summaries.
- Added one-click Prepare Email, Download Archive, and email-without-attachment actions.
- Kept all sending manual; Switch Vision stores no email credentials.

## v1.2.22

- Removed the icon from the on-card Calibrate button.
- Centred the Calibrate and Done labels within the calibrated button bounds.

## v1.2.21

- Fixed Status Box 2 style controls updating a stale calibration object after UI defaults were merged.
- Border show/hide, border colour, font, sizing, text colour, and fill colour now update the live Status Box 2 profile and renderer immediately.
- Added a browser regression check covering border off, border on, colour changes, and font-size changes.

## v1.2.20

- Fixed Status Box 2 border controls by separating the rendered border from the panel background.
- Moved status-box calibration outlines 5 px outside the boxes so live border visibility and colour changes remain visible while selected.

## v1.2.19

- Fixed Status Box 2 border enable and border-colour controls by using the same profile-driven rendering path as Status Box 1.
- Clears stale Status Box 2 border overrides created by earlier calibration builds.

# Changelog

## v1.2.18

- Fixed Status Box 2 border re-enabling after it was hidden.
- Fixed live Status Box 2 border-colour updates by applying explicit SVG stroke attributes.

## v1.2.17

- Fixed Status Box 2 border visibility and border colour so the renderer uses the box's own saved settings directly.
- Simplified status-box border rendering to a single correctly coloured outline.
- Removed the duplicate Switch IP heading from the calibration panel.

## v1.2.16

- Moved the default Status Box 2 position down another 5 px.
- Fixed Status Box 2 live styling so font, sizing, colours, bold, fill and border controls are applied immediately even when card-level overrides exist.

## v1.2.15

- Moved the default Status Box 2 position down by 5 px, from Y 10 to Y 15.
- Moved the Status Box 2 style row directly above the Status Box 2 field controls.
- Simplified both status-box field selectors to the label **Field**.

## v1.2.14

- Added a dedicated **Status Box 1 style** label so both status-box styling rows use the same layout.
- Added a **Show JSON / Hide JSON** control to the calibration panel.
- The calibration JSON export is now collapsed by default to save vertical space; **Copy JSON** continues to work while it is hidden.

## v1.2.13

- Fixed the calibration controls failing to render after adding Status Box 2 styling.
- Defined the Status Box 2 bold-state value before the calibration panel template is built.
- Restored the calibration panel while retaining all Status Box 2 font and border controls.

## v1.2.12

- Added a dedicated Status Box 2 styling row with independent font, bold, font size, title size, text colour, and fill colour controls.
- Added border visibility and border colour controls for both Status Box 1 and Status Box 2.
- Status-box border settings are saved independently in calibration profiles.
- Reduced the default Status Box 2 height from 60 px to 55 px.

## v1.2.11

- Moved the default Status Box 2 position to the higher, slightly left-aligned placement used by the tested SW6 layout.
- Status Box 2 now defaults fully inside the faceplate frame above the right-side vents and clear of the Calibrate button.
- Existing saved calibration profiles keep their saved position; the new placement applies to new profiles and reset layouts.

## v1.2.10

- Removed the separate faceplate-label rendering, calibration target, controls, YAML generation, and active documentation.
- Status Box 2 is now the single configurable name/label area and defaults to the generated card title as its custom title.
- Moved the default Status Box 2 fully inside the faceplate frame and positioned it neatly above the right-side vents.
- Status Box 2 starts with all rows hidden so its custom title can be used as a clean switch label; users can reveal any status rows manually.
- Existing custom Status Box 2 titles remain editable and are saved in calibration profiles.

## v1.2.9

- Added independently configurable **Status Box 2**, using the same switch status fields as Status Box 1.
- Status Box 2 defaults to the faceplate label while Status Box 1 retains the existing switch fields.
- Changed the default Status Box 1 order to MODEL, IP, CPU, TEMP, POE, UPTIME, then the remaining fields.
- Added editable title sources for both status boxes: default title, status-field value, or a custom title. Selecting a title field does not automatically hide or reorder its normal row.
- Renamed the calibration controls to **Status Box 1 Field** and **Status Box 2 Field**.
- Removed Faceplate label and the individual identity-field buttons from Quick select.
- Renamed the calibration management-address input to **Switch IP**.

## v1.2.8

- Added the standard POWER-ETHERNET-MIB aggregate PoE branch (`1.3.6.1.2.1.105.1.3.1`) to targeted discovery walks.
- Catalyst 2960S devices that omit Cisco extended aggregate PoE totals can now generate PoE used and budget sensors without requiring a full walk.
- Built directly from the v1.2.7 baseline; no abandoned earlier v1.2.8 dashboard changes are included.
- Custom component changed: no.

## v1.2.7

- Added a standard POWER-ETHERNET-MIB fallback for aggregate PoE used and budget sensors when Cisco extended totals are absent.
- Catalyst 2960S devices such as WS-C2960S-48FPD-L now generate `PoE Used W` and `PoE Budget W` sensors and display `0 / 740 W` when no PoE power is in use.


- Fixed Discovery identity parsing so system description, model, and serial sensors are actually emitted into generated SNMP2MQTT YAML.
- Identity sensors now use each switch's existing `Slow System` poll group at 300 seconds and are created on the first poll after SNMP2MQTT restarts.
- ENTITY-MIB model and serial OIDs remain walk-aware and member-specific for supported Catalyst stacks.
- Custom component changed: no.

## v1.2.6



## v1.2.5

- Added generated identity sensors for model, serial number, and system description using exact OIDs found in each discovery walk.
- Generated dashboard cards now map the identity entities automatically.
- Vendor, OS, and firmware are derived from Cisco system-description data when dedicated entities are unavailable.
- Corrected Cisco 2960S/2960X aggregate PoE units to watts while preserving Catalyst 3650 milliwatt reporting.
- Card PoE formatting now respects entity units and safely handles legacy entities without unit metadata.
- Custom component changed: no.

## v1.2.4

- Centered the Calibration button label vertically and horizontally inside its calibrated target box.
- Applied border-box sizing and even internal spacing so the selection border no longer touches the label at the bottom or appears heavier above it.
- Custom component changed: no.

## v1.2.3

- Fixed Calibration button target parsing so arrow and size controls edit the visible button instead of falling through to a port target.
- Added Calibration button support to target labels and Reset target.

# Changelog

## v1.2.2

- Fixed the movable Calibration button so its 2048 × 448 calibration coordinates scale correctly with the displayed card size.
- Calibration button now appears at its default top-right position on newly generated cards.
- Status rows whose calibrated label or value positions fall outside the status box are no longer rendered.
- Prevents identity and telemetry text from overlapping ports or other faceplate elements.
- Custom component changed: no.

## v1.2.1

- Calibration button now defaults to visible when the card setting is omitted.
- Discovery-generated dashboard cards now explicitly include `calibration_button: true`.
- Bundled live and generated-card examples now show the calibration button by default.
- Custom component changed: no.

## v1.1.8

- Added separate custom logo and background folders.
- Added a safe Home Assistant WebSocket asset-listing API.
- Added Logo and Background dropdowns to interactive Calibration.
- Added Use card default, None, empty-folder guidance, and Refresh files controls.
- Added live background/logo preview and calibration-profile persistence.
- Custom component changed: yes.


- Masks Cisco local-hostname OID `1.3.6.1.4.1.9.2.1.3.0` in symbolic and numeric SNMP walk output.
- Adds the Cisco hostname OID to the final residual privacy audit.
- Advances the contribution bundle schema to version 8 and sanitization schema to version 5.

## v1.1.6 - Support My Switch Cisco local hostname privacy fix

- Masks plain-text `Cisco local hostname: <value>` fields in Discovery reports when hostname masking is enabled.
- Extends the final residual privacy audit to detect the same report field.
- Prevents contribution bundles from reporting a clean hostname audit while Cisco local hostnames remain.
- Advances the contribution bundle schema to version 7 and sanitization schema to version 4.

## v1.1.5 - Support My Switch contributor experience

- Added optional contributor recognition preferences: anonymous, first name, full name, GitHub username, or forum username.
- Added `EMAIL_TEMPLATE.txt` with the contribution ID, archive name, recognition preference, and tester-notes prompts.
- Added `BUNDLE_QUALITY.txt` and manifest quality fields driven by the final residual privacy audit.
- Added a clearer review receipt, privacy summary, and next-step instructions in the Discovery log.
- Kept the validated bundle engine and sanitization behaviour unchanged.

## v1.1.4 - Support My Switch report hostname privacy fix

- Masks bullet-style plain-text hostname fields such as `- sysName: switch.example.com` in Discovery reports.
- Extends the final residual audit to detect the same report-style hostname fields.
- Prevents a contribution archive from reporting a clean hostname audit while those values remain.
- Advances the Support My Switch bundle schema to version 5 and sanitization schema to version 3.

## v1.1.3 - Support My Switch privacy completion

- Sanitizes copied switch data before device summaries and fingerprints are generated.
- Adds a final privacy pass across bundle-root metadata to prevent reintroduced hostnames.
- Masks numeric and symbolic IF-MIB ifAlias values when interface-description masking is enabled.
- Masks VLAN labels consistently while preserving numeric VLAN IDs for analysis.
- Adds a final residual privacy audit and records any remaining enabled-category findings.
- Advances Support My Switch bundle schema to version 4.

## v1.1.2 - Support My Switch privacy engine

- Added privacy processing for contribution bundles using only a temporary copy.
- Credential-like values are always removed before archive creation.
- Added configurable masking for management IPs, MAC addresses, hostnames/domains, VLAN names, and interface descriptions.
- Added machine-readable and human-readable sanitization reports.
- Updated bundle manifest schema to version 3 with privacy selections and replacement counts.
- Live `/share/switch_vision/` data remains untouched.

# Switch Vision changelog

## v1.1.1 — Support My Switch bundle metadata and fingerprints

- Replaced development-stage wording with a user-facing Support My Switch workflow.
- Added a concise completion summary with contribution ID, archive size, file count, privacy state, and output path.
- Added `DEVICE_SUMMARY.json` from discovered capability sidecars.
- Added deterministic SHA-256 device fingerprints for grouping repeated contributions from the same hardware profile.
- Expanded `MANIFEST.json` to bundle schema version 2 with device counts and fingerprint references.
- Kept the live `/share/switch_vision` folder read-only and excluded prior contribution archives.
- Privacy sanitization remains a later test stage; generated bundles still require review before sharing.

## v1.0.0 — Gold Master

- Promoted the fully validated v1.8.0 codebase to the first Switch Vision Gold Master.
- Froze the v1.0 compatibility baseline for paths, domains, card fields, generated entities, calibration storage, and generated YAML headers.
- Recorded validated SNMP2MQTT core/add-on v1.8.0 as the Gold telemetry companion.
- Added Gold-only release documentation and explicit `build.py -v 1.0.0 --gold` validation.
- Confirmed all known Gold blockers closed through clean-install evidence on SW5–SW9.

## v1.8.0

- Capability sidecars now read the active Discovery runtime version instead of a hard-coded value.
- Capability interface totals use model-aware 24/48-port front-panel classification and exclude management interfaces.
- Multi-switch runs remove an obsolete empty `snmpwalks/live/` directory without deleting non-empty user data.
- Build validation now covers dynamic capability versioning, interface classification, and legacy-folder cleanup.

## v1.8.0

- Propagate the active release version into every per-switch capability sidecar.
- Align Catalyst 2960S/2960X capability counts with the authoritative front-panel mapping.
- Exclude the dedicated Gi0/0 management interface from physical-port totals.
- Classify 2960 front-panel uplinks above the 24/48-port RJ45 boundary as uplinks instead of RJ45 ports.
- Stop recreating the obsolete empty `snmpwalks/live/` directory during multi-switch discovery.
- Add build regressions for capability versioning, interface classification, and walk-folder cleanup.

## v1.8.0

- The build script now creates `Switch_Vision_v<version>_source.zip` automatically after every successful build.
- The generated source ZIP is placed in the project root for easy upload and contains source files at the archive root plus the matching extracted release.
- Removed the need for the optional `--source-zip` argument.
- Previous local source ZIPs are excluded from newly generated source archives.

## v1.8.0

- Removed obsolete generated `last_change_entity_prefix` and `last_change_entity_suffix` fields.
- Confirmed port activity is derived directly from RX/TX byte-counter deltas.
- Simplified generated dashboard cards by omitting redundant `demo: false` and `calibration_button: false` settings.
- Added release validation so nonexistent `_last_change` dependencies cannot return.

## v1.8.0

- Fixed stack-member status entity resolution with explicit CPU, temperature, and PoE entity mappings.
- Added explicit stack member numbers to generated cards and rejected malformed saved member values.
- Generated faceplate labels now remain authoritative unless the label text is explicitly edited in Calibration.
- Hid the PoE status row when used/budget entities are unavailable.
- Renamed the Discovery field label to **Switch Name (Used internally only)**.

# Changelog

## v1.8.0

- Made stack-member display names drive both generated card titles and default faceplate labels.
- Kept stable member IDs and calibration profile names separate from friendly display text.
- Added optional per-switch and per-stack-member `faceplate_label` overrides.
- Corrected generated stack member status text by preserving stable member keys such as `SW5` and `SW6`.

## v1.8.0

- Fixed switch-list walk-to-target resolution after per-switch folder persistence.
- Parent folders with spaces converted to underscores now match their configured switch names.
- Management IP, sensor prefix, community and display metadata are restored from the runtime switch map during parsing.
- Generated SNMP2MQTT YAML is no longer blocked by false `Management target: unknown` results.
- Removed the stale `v1.8.0` behaviour-authority wording from vendor reports.

## v1.8.0 — Per-switch output cleanup

- Removed creation of the legacy empty `snmpwalks/live/` folder during switch-list runs.
- Capability sidecars now use one stable file per switch: `capabilities/<switch_name>-capabilities.json`.
- Removed the ambiguous latest `capabilities.json` convenience copy.
- Updated Discovery report headings to show the walk root and per-switch folder mode.
- Non-Gold packages no longer include Gold-specific checklist material.
- Build output removes `__pycache__` directories and `.pyc` files.

## v1.8.0

- Removed the user-facing `folder_label` field; walk folders now derive only from sanitized `switch_name`.
- Spaces and unsafe characters in walk folder names are converted to underscores.
- Targeted walks are written directly to `/share/switch_vision/snmpwalks/<switch_name>/` and verified after each write.
- Added an optional `display_name` field for each stack member.
- Generated card titles and faceplate labels inherit stack-member display names when supplied.

## v1.8.0

- Fixed targeted multi-switch walks so each switch persists only in its own switch-name subfolder; removed the legacy shared-root copy that overwrote `live-targeted-snmpwalk.txt`.
- Made high-capacity RX/TX counters walk-aware so missing `ifHCInOctets`/`ifHCOutOctets` OIDs are not generated.
- Made PoE supply/status/used/budget sensors individually walk-aware.
- Made optional trunk-status and alias sensors walk-aware.
- Prevented standalone switch cards from receiving stack inheritance settings unless an explicit multi-member stack is configured.
- Corrected capability interface classification for abbreviated `Gi` names and refined 2960S identity from `sysDescr`.
- Propagated v1.8.0 into capability sidecars.

## v1.8.0

- Fixed targeted switch-list walks retaining the shared `snmpwalks/live` output path when optional folder fields were blank.
- Every switch now writes to `/share/switch_vision/snmpwalks/<switch-name>/live-targeted-snmpwalk.txt` by default.
- Added a build regression check for the per-switch targeted-walk fallback.

## v1.8.0

- Made switch-list `display_name` optional so blank friendly names save correctly.
- Removed legacy opening fields: `selected_switch`, `fallback_switch_host`, top-level `sensor_prefix`, and `fallback_snmp_community`.
- Clarified `switch_name` as the stable internal target ID and `display_name` as the optional friendly title.
- Renamed report headings to `Current target`, `Management IP`, and `Output folder`.

## v1.8.0

- Added optional Discovery `display_name` field for generated card titles.
- Generated cards now avoid duplicate `SW5 • SW5` titles by using `Switch Vision • SW5` when no display name is supplied.
- Added editable and movable **Faceplate label** calibration target above the right-hand vents.
- Discovery-generated cards set `faceplate_label` to the member/switch name.

# Switch Vision changelog

## v1.8.0

- Propagate the enforced build version into Discovery runtime-generated YAML and dashboard headers.
- Prefix per-walk capability sidecar filenames with the configured switch sensor prefix to prevent overwrites.
- Normalize simple `SW<number>` dashboard member/profile names to uppercase while preserving custom labels.
- Add build-time regression checks for all three fixes.

## v1.8.0

- Fixed calibration profile storage after the Switch Vision rename.
- The custom component now uses only `.storage/switch_vision_calibrations`.
- Clean-install release: no legacy Cisco Vision storage import or compatibility fallback is included.

## v1.8.0

- Fixed standalone switches with retained Cisco member numbering (for example `Gi2/0/1`) generating the next sensor prefix (`sw5`) instead of their configured prefix (`sw4`).
- Standalone devices now always use the configured `sensor_prefix`; stack member prefix arithmetic remains stack-only.

## v1.8.0 — Release Candidate

- Completed the project-wide Switch Vision naming cutover.
- Added vendor/OID knowledge and normalized interface capability sidecar output.
- Added the `switch_vision` Home Assistant integration domain.
- Added the `custom:switch-vision-3650` dashboard card type.
- Moved shared output paths to `/share/switch_vision/`.
- Added a reproducible, version-aware build script.
- Added exact and wildcard `-v/--version` build enforcement.
- Added automatic patch increment after every successful build.
- Rebuilt the release as one all-in-one Switch Vision folder.
- Kept SNMP2MQTT core/add-on packaging separate from the main project.
- Rewrote requirements, installation, workflow, field-reference, and example documentation.
- Removed stale Cisco Vision product naming while retaining Cisco where it identifies the hardware vendor or Cisco-specific MIB logic.

## Historical baseline

Cisco Vision v1.8.0 was the final Gold baseline before the project became Switch Vision. Historical release notes remain relevant only when reviewing old builds.

## v1.1.0 - Support My Switch Stage 1

- Added the first testable Support My Switch bundle engine.
- Added an add-on option to archive the complete `/share/switch_vision/` data folder.
- Generates sequential contribution IDs such as `SV-2026-000001`.
- Adds a manifest, contribution ID, README, and sanitization status report.
- Excludes the contributions output folder to prevent recursive archives.
- Never modifies the live Switch Vision data folder.
- Stage 1 bundles are intentionally unsanitized and must be reviewed before sharing.
