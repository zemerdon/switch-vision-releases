# Switch Vision

Switch Vision is a Home Assistant platform for discovering managed network switches, generating SNMP2MQTT configuration, and displaying live switch activity on an interactive front-panel dashboard.

## Current release

- **Version:** v1.8.0 Gold
- **Status:** Gold / Stable
- **Primary workflow:** Discovery-generated native Home Assistant sidebar dashboard
- **Manual dashboard YAML:** Retained as a permanent fallback
- **Confirmed hardware:** Cisco Catalyst 3650 exact models listed in the supported-device registry
- **Experimental hardware:** All non-3650 models pending SFP/uplink validation
- **SNMP:** Read-only SNMP v2c

## What is included

- Switch Vision Discovery add-on with persistent Web UI
- Native Home Assistant **Switch Vision** sidebar dashboard
- Switch Vision Lovelace card
- Home Assistant custom component for the native panel, calibration storage, asset browsing, and integration options
- Exact-model supported-device registry
- Calibration profile import/export and faceplate recommendations
- Support My Switch contribution workflow
- Diagnostics, troubleshooting, installation, field-reference, and development documentation

The Switch Vision SNMP2MQTT add-on is maintained separately.

## Normal user workflow

```text
Install Switch Vision
→ Configure switches in Discovery
→ Run Discovery
→ Discovery generates and validates SNMP2MQTT YAML
→ Switch Vision starts or restarts the SNMP2MQTT add-on
→ Open Switch Vision from the Home Assistant sidebar
```

No dashboard YAML copying is required for the normal v1.8.0 Gold workflow.

## Quick start

1. Read `docs/REQUIREMENTS.md`.
2. Follow `docs/INSTALLATION.md` for a clean installation.
3. Configure the separate Switch Vision SNMP2MQTT add-on to import:
   ```text
   /share/switch_vision/generated-snmp2mqtt.yaml
   ```
4. Configure the switches in **Switch Vision Discovery**.
5. Run Discovery.
6. Open **Switch Vision** from the Home Assistant sidebar.
7. Use **Calibrate** only when a faceplate or layout adjustment is needed.

## Automatic native dashboard

The `switch_vision` custom component registers a native Home Assistant panel named **Switch Vision**. It reads:

```text
/share/switch_vision/generated-dashboard-card.yaml
```

and renders the generated live cards automatically.

The generated panel:

- does not write to Lovelace storage;
- does not modify unrelated dashboards;
- refreshes automatically when Discovery generates newer card YAML;
- uses versioned frontend URLs to reduce stale browser caching;
- retains the generated YAML as a manual fallback.

The panel header shows the card count, generation time, refresh action, and installed panel version on one compact line.

## Optional sidebar visibility

The native Switch Vision dashboard can be hidden without disabling Switch Vision.

Open:

```text
Settings → Devices & services → Switch Vision → Configure
```

Then change:

```text
Show Switch Vision dashboard in sidebar
```

Turning this off hides only the sidebar shortcut. Manual cards, generated YAML, Calibration, Discovery, Diagnostics, Support My Switch, and SNMP2MQTT continue to work.

The Discovery add-on has its own separate **Show in sidebar** setting on the add-on page.

## Discovery Web UI

The Discovery add-on starts into **Idle / Ready** and keeps its Web UI available before, during, and after a run.

Main areas:

- **Discovery** — run and monitor Discovery;
- **Devices** — view compact detected-device results;
- **Support My Switch** — create a privacy-processed support package;
- **Diagnostics** — inspect the installation and generated outputs.

Discovery provides:

- one-second live polling while work is active;
- five-second polling while idle;
- an elapsed timer that visibly ticks every second;
- pause while the browser tab is hidden;
- immediate refresh when the tab becomes active;
- a minimal status view by default;
- **Show Debug** for complete command and processing details.

The normal stages retain these exact labels:

```text
Running SNMP walks
Generating SNMP2MQTT YAML
Generating dashboard card YAML
```

SNMP communities remain masked in normal and debug output.

## SNMP2MQTT handoff

Discovery writes:

```text
/share/switch_vision/generated-snmp2mqtt.yaml
```

After a successful run, Switch Vision:

1. confirms that the current run produced a new file;
2. validates the YAML;
3. locates the installed Switch Vision SNMP2MQTT add-on through Supervisor;
4. restarts it when running or starts it when stopped;
5. reports the result in the Discovery status and Debug output.

The Discovery add-on uses Supervisor API access with the `manager` role. Failure to locate or control SNMP2MQTT produces a warning but does not fail Discovery.

## Manual dashboard fallback

The native dashboard is the recommended workflow, but this file remains available:

```text
/share/switch_vision/generated-dashboard-card.yaml
```

It may be copied into an existing Lovelace dashboard. The manual layout uses Layout Card and requires this HACS resource as a **JavaScript Module**:

```text
/hacsfiles/lovelace-layout-card/layout-card.js
```

Layout Card is not required by the native Switch Vision panel itself.

## Faceplates and calibration

The factory 48-port profile is:

```text
default_cisco_48_port
```

The dark faceplate is the current default and recommended 3650 visual:

```text
faceplates/sv-dark.png
```

The light faceplate remains available as an alternate:

```text
faceplates/sv-light.png
```

Both use the same 2048 × 448 calibration geometry.

Calibration features include:

- port add, duplicate, rename, and removal;
- bulk odd/even and range selection;
- downloadable and importable JSON profiles;
- schema and image-dimension validation;
- exact-model Recommended Setup suggestions;
- automatic save when **Done** is clicked;
- a separate **Save Profile** action for saving without closing.

Custom assets can be placed in:

```text
/config/www/switch-vision/logos/
/config/www/switch-vision/faceplates/
```

## Model detection and compatibility overrides

Switch Vision preserves the exact detected hardware SKU. Supported models are matched by exact model name.

Each Discovery switch row defaults to:

```text
Switch Model: Auto-detect
```

A registered model may be selected manually as an experimental compatibility override. Switch Vision retains and reports:

- detected model;
- selected override;
- effective mapping/visual model.

An override never changes the official support status of the detected hardware.

## Support My Switch

Support My Switch creates a reviewable contribution package from a temporary copy of `/share/switch_vision/`. The live data folder is not modified.

Credentials are always removed. Optional controls can mask:

- management IP addresses;
- MAC addresses;
- hostnames;
- VLAN names;
- interface descriptions.

Nothing is sent automatically. The workflow creates a ZIP, a prepared `.eml` email with the ZIP attached, and a local action page.

Support email:

```text
switch-vision@zemerdon.com
```

Community forum:

```text
https://switch-vision.zemerdon.com
```

## Support levels

- **Detected** — hardware identity was recognised.
- **Experimental** — generated support exists but validation is incomplete.
- **Community Validated** — a contributor has successfully tested the implementation.
- **Confirmed Supported** — support has strong repeatable validation.

## Documentation

- `docs/REQUIREMENTS.md`
- `docs/INSTALLATION.md`
- `docs/DISCOVERY_WORKFLOW.md`
- `docs/FIELD_REFERENCE.md`
- `docs/TROUBLESHOOTING.md`
- `docs/SUPPORT_MY_SWITCH.md`
- `docs/SUPPORTED_DEVICES.md`
- `docs/BUILDING.md`

### Integration display options

Under **Settings → Devices & services → Switch Vision → Configure**, users can independently show or hide the Switch Vision sidebar dashboard and the on-card Calibration buttons used by the automatic generated view.
