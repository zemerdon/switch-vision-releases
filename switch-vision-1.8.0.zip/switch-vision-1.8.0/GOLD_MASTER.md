# Switch Vision v1.8.0 Gold Master

**Status:** Gold / Stable  
**Gold baseline:** v1.8.0  
**Validated source baseline:** v1.7.53  
**Release date:** 27 July 2026

## Gold scope

Switch Vision v1.8.0 is the authoritative stable baseline for installation, documentation, support, and future development. It promotes the fully validated v1.7.53 codebase without changing its validated runtime behaviour.

Confirmed support remains limited to the exact Cisco Catalyst 3650 models listed in the supported-device registry. Cisco Catalyst 2960S/2960X and Juniper EX3300-48P entries remain Experimental until their outstanding uplink or Virtual Chassis validation is complete.

## Gold highlights

- Native Home Assistant sidebar dashboard with current show/hide behaviour
- Discovery-generated dashboard and SNMP2MQTT configuration workflow
- Calibration controls with independent Status Box 1, Status Box 2, and Port Status Box field controls
- Fixed-size title-free status boxes with IntelOne 16 px bold defaults
- Status Box 2 default fields: VENDOR and UPTIME
- Reset target and immediate Reset all visual-calibration controls
- Confirmed Cisco Catalyst 3650 standalone and stack behaviour
- Blue STACK LED for confirmed stack members and no stack indication for standalone switches
- Juniper EX3300-48P exact-model registry matching, copper-port mapping, PoE/system telemetry, and per-port VLAN membership display
- Support My Switch contribution workflow with explicit privacy-audit enforcement metadata
- Automatic semantic-version bump support in `build.py`
- Single authoritative version history in `CHANGELOG.md`
- Clean Gold archives with Python cache artefacts and historical release-note files excluded

## Support status

- **Confirmed:** Cisco Catalyst 3650 `WS-C3650-48PD-E` and `WS-C3650-48PD-L`
- **Experimental:** Registered Cisco 2960S/2960X and Juniper EX3300-48P models pending remaining physical validation

## Gold validation evidence

The v1.7.53 Support My Switch contribution bundle validated:

- all five registered test devices;
- Juniper registry enrichment and static Q-BRIDGE VLAN membership;
- explicit disabled-audit metadata using `enforced: false` and `remaining: null`;
- clean contribution reporting and device summaries.

## Packaging rule

Gold source and release archives must not contain `__pycache__/`, `.pytest_cache/`, `*.pyc`, `*.pyo`, or historical `RELEASE_NOTES*` files.
