Switch Vision bundled faceplates

Files:
- sv-dark.png — default dark Switch Vision faceplate
- sv-light.png — optional light Switch Vision faceplate

Home Assistant path:
/config/www/switch-vision/faceplates/

New profiles use sv-dark.png by default.
